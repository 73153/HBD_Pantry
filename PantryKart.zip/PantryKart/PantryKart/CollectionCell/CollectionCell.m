//
//  CollectionCell.m
//  CollectionView
//
//  Created by ushiostarfish on 2013/08/19.
//  Copyright (c) 2013年 Ushio. All rights reserved.
//

#import "CollectionCell.h"

@implementation CollectionCell

@end
