//
//  BeaverageCollectionViewCell.h
//  PantryKart
//
//  Created by vivek on 1/4/16.
//  Copyright © 2016 vivek. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BeaverageCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgItem;

@end
