//
//  DeliveryPreferneceTableViewCell.m
//  PantryKart
//
//  Created by Bhumesh on 02/03/16.
//  Copyright © 2016 vivek. All rights reserved.
//

#import "DeliveryPreferneceTableViewCell.h"

@implementation DeliveryPreferneceTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
