//
//  MyOrderTableViewCell.m
//  PantryKart
//
//  Created by vivek on 1/13/16.
//  Copyright © 2016 vivek. All rights reserved.
//

#import "MyOrderTableViewCell.h"

@implementation MyOrderTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
