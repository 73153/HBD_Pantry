//
//  PointsTableViewCell.h
//  PantryKart
//
//  Created by karishma on 4/12/16.
//  Copyright © 2016 vivek. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PointsTableViewCell : UITableViewCell

@property (nonatomic,strong) IBOutlet UILabel *lblCreditAmmount;
@property (nonatomic,strong) IBOutlet UILabel *lblTime;
@property (nonatomic,strong) IBOutlet UILabel *lblTransactionComment;
@property (nonatomic,strong) IBOutlet UIImageView *imgRefferal;
@property (nonatomic,strong) IBOutlet UILabel *lblType;
@property (nonatomic,strong) IBOutlet UILabel *lblStatus;
@property (nonatomic,strong) IBOutlet UILabel *lblmyreferrals;
@property (nonatomic,strong) IBOutlet UILabel *lblReferralCount;
@property (nonatomic,strong) IBOutlet UIButton *btnDelete;
@property (nonatomic,strong) IBOutlet UIButton *btnUpdate;
@property (weak, nonatomic) IBOutlet UILabel *lblSepComment;



@end
