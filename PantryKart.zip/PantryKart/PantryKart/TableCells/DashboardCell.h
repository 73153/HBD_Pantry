//
//  DashboardCell.h
//  DemoPantryCart
//
//  Created by karishma on 2/23/16.
//  Copyright © 2016 karishma. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DashboardCell : UITableViewCell

@property (nonatomic,strong) IBOutlet UIScrollView *scrollView;
@end
