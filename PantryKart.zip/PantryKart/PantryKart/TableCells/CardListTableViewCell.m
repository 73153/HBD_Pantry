//
//  CardListTableViewCell.m
//  PantryKart
//
//  Created by karishma on 3/21/16.
//  Copyright © 2016 vivek. All rights reserved.
//

#import "CardListTableViewCell.h"

@implementation CardListTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
