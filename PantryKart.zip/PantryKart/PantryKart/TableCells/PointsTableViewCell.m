//
//  PointsTableViewCell.m
//  PantryKart
//
//  Created by karishma on 4/12/16.
//  Copyright © 2016 vivek. All rights reserved.
//

#import "PointsTableViewCell.h"

@implementation PointsTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
