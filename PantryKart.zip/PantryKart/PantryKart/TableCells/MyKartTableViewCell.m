//
//  MyKartTableViewCell.m
//  PantryKart
//
//  Created by karishma on 1/27/16.
//  Copyright © 2016 vivek. All rights reserved.
//

#import "MyKartTableViewCell.h"

@implementation MyKartTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
