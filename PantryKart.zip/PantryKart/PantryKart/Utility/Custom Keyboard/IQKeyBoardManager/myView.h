//
//  myView.h
//  ProPad
//
//  Created by Bhumesh on 17/08/15.
//  Copyright (c) 2015 Zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface myView : UIView

@end
