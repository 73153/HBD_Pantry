//
// UIViewController+RESideMenu.m
// RESideMenu
//
// Copyright (c) 2013-2014 Roman Efimov (https://github.com/romaonthego)
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//

#import "UIViewController+RESideMenu.h"
#import "RESideMenu.h"
#import "SearchViewController.h"
#import "MyKartViewController.h"
#import "ProfileEditViewController.h"
#import "Constant.h"
#import "Globals.h"
#import "CommonPopUpView.h"
#import "UIView+Toast.h"
#import "DashboardViewController.h"


@implementation UIViewController (RESideMenu)

- (RESideMenu *)sideMenuViewController
{
    UIViewController *iter = self.parentViewController;
    while (iter) {
        if ([iter isKindOfClass:[RESideMenu class]]) {
            return (RESideMenu *)iter;
        } else if (iter.parentViewController && iter.parentViewController != iter) {
            iter = iter.parentViewController;
        } else {
            iter = nil;
        }
    }
    return nil;
}

#pragma mark -
#pragma mark IB Action Helper methods

- (IBAction)presentLeftMenuViewController:(id)sender
{
   UIButton *btnLeftmenu=(UIButton *)sender;
    [btnLeftmenu setBackgroundImage:[UIImage imageNamed:@"cal-active"] forState:UIControlStateHighlighted];
    [self.sideMenuViewController presentLeftMenuViewController];
}

- (IBAction)presentRightMenuViewController:(id)sender
{
   
[self.sideMenuViewController presentRightMenuViewController];
}

- (IBAction)DashboardViewController:(id)sender
{
    DashboardViewController *objDashboardViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"DashboardViewController"];
  // NSArray *controllers1 = [self.navigationController viewControllers];
    BOOL isIn=false;
     for (UIViewController *controller in self.navigationController.viewControllers) {
        //Do not forget to import AnOldViewController.h
        if ([controller isKindOfClass:[DashboardViewController class]]) {
            
            [self.navigationController popToViewController:controller animated:YES];
          
           
            isIn=true;
            break;
      }
    }
    if(!isIn)
  {
        [self.navigationController pushViewController:objDashboardViewController animated:YES];
    }
  //[self.navigationController popToRootViewControllerAnimated:TRUE];
}

- (IBAction)pushMyKartViewController:(id)sender
{
    
    UIStoryboard *storybord = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    MyKartViewController *objMessageVC=(MyKartViewController *)[storybord  instantiateViewControllerWithIdentifier:@"MyKartViewController"];
    UINavigationController *mainNavigation = (UINavigationController *) [self.sideMenuViewController contentViewController];
    
    [mainNavigation pushViewController:objMessageVC animated:YES];
    
    [self.sideMenuViewController hideMenuViewController];
    //   [self.sideMenuViewController.navigationController pushViewController:objMessageVC animated:YES];
    
}

- (IBAction)presentRightMenuSearchViewController:(id)sender
{
    UIStoryboard *storybord = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    SearchViewController *objMessageVC=(SearchViewController *)[storybord  instantiateViewControllerWithIdentifier:@"SearchViewController"];
    
    UINavigationController *mainNavigation = (UINavigationController *) [self.sideMenuViewController contentViewController];
    
    [mainNavigation pushViewController:objMessageVC animated:YES];
    
    [self.sideMenuViewController hideMenuViewController];
  
}

- (IBAction)showTheBrandListPopUp:(id)sender
{
    [self showPopUpBrandList];
//    
//    UIButton *btnMyCart=(UIButton *)sender;
//    [btnMyCart setImage:[UIImage imageNamed:@"search-active"] forState:UIControlStateHighlighted];
//    UIStoryboard *storybord = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//    
//    SearchViewController *objMessageVC=(SearchViewController *)[storybord  instantiateViewControllerWithIdentifier:@"SearchViewController"];
//    
//    [self.sideMenuViewController setContentViewController:[[UINavigationController alloc] initWithRootViewController:objMessageVC]
//                                                 animated:YES];
//    [self.sideMenuViewController hideMenuViewController];
}
-(IBAction)ProfileEditButtonClicked:(id)sender;
{
    @try{
        
        Globals *OBJGlobal;
        Users *objReferPoints;
        OBJGlobal = [Globals sharedManager];
        objReferPoints=OBJGlobal.user;
        OBJGlobal.isShareWishlist=true;
//
//        
//        if(GETBOOL(@"isUserHasLogin")==true){
//            
//            [APPDATA showLoader];
//            [objReferPoints checkoutRefferalPoints:^(NSDictionary *user, NSString *str, int status)
//             {
//                 if (status == 1) {
//                    
//            OBJGlobal.strEarnedPoints =[NSMutableString stringWithFormat:@"%@",[user objectForKey:@"maximum_allowed_points"]];
        
      [[NSNotificationCenter defaultCenter] postNotificationName:@"test"
                      object:self];
//                   //  _lblPoints.text=[NSString stringWithFormat:@"%@",[user valueForKey:@"reward_money"]];
//                  [APPDATA hideLoader];
//                     
//                     NSLog(@"success");
//                 }
//                 else {
//                  //   [self ProfileEditButtonClicked:sender];
//                  if([OBJGlobal isNotNull:[user objectForKey:@"msg"]])
//                        [self.view makeToast:[user objectForKey:@"msg"]];
//                     NSLog(@"Failed");
//                     [APPDATA hideLoader];
//                 }
//             }];
//        }
//        else
//        {
//            [self.view makeToast:@"Please login to view all address"];
//        }
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}


@end
