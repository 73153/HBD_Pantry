//
//  ShoppingList.m
//  PantryKart
//
//  Created by vivek on 12/25/15.
//  Copyright © 2015 vivek. All rights reserved.
//

#import "ShoppingListCell.h"

@implementation ShoppingListCell

@end
