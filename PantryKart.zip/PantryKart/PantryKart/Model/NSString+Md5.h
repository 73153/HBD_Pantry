//
//  NSString+Md5.h
//  PantryKart
//
//  Created by Bhumesh on 01/04/16.
//  Copyright © 2016 vivek. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Md5)

- (NSString *)MD5;
- (NSString *)md5 ;
@end
