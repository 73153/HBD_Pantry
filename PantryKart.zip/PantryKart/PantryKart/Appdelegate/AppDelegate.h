//
//  AppDelegate.h
//  PantryKart
//
//  Created by vivek on 12/25/15.
//  Copyright © 2015 vivek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIView+Toast.h"
#import "Constant.h"
#import "Users.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic,strong) NSString *databaseName;
@property (nonatomic,strong) NSString *databasePath;
@property (nonatomic, retain) NSString *token;
@property BOOL isRichComment,isNotification,isFromPaymentMethod,isAuth;
@property (nonatomic,strong) NSMutableDictionary *dictAppNewAddress;
@end

