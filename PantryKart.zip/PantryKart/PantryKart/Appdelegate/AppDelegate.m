//
//  AppDelegate.m
//  PantryKart
//
//  Created by vivek on 12/25/15.
//  Copyright © 2015 vivek. All rights reserved.
//

#import "AppDelegate.h"
#import "IQKeyboardManager.h"
#import "PayPalMobile.h"
#import "SDWebImageManager.h"
#import "Globals.h"
#import <Fabric/Fabric.h>
#import <Crashlytics/Crashlytics.h>
#import "Constant.h"
#import "LoginViewController.h"
#import "UIViewController+NavigationBar.h"
#import "DashboardViewController.h"
#import <AdSupport/AdSupport.h>

#define CLIENT_ID_FOR_SANDBOX_PAYPAL @"pantrykart-facilitator@gmail.com"
#define CLIENT_ID_FOR_PAYPAL  @"AdFAn5WzOQEs4QP6jjwi1NqTQk9arU54eqmGupTEo83Q5XpNpwmmai_CBsXD5V0UPbITom63XPFSQHqO"
#define CrashlyticsKit [Crashlytics sharedInstance]

@interface AppDelegate () <UIAlertViewDelegate>
{
    Globals *OBJGlobal;
    UIStoryboard *story;
    NSInteger badgeCount;
   
}

@end

@implementation AppDelegate

@synthesize databaseName,databasePath,token;
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    @try{
        
        
        OBJGlobal = [[Globals alloc]init];
        Globals *OBJGlobal = [Globals sharedManager];
            [self authenticationMethod];
        //Enabling keyboard manager
        [[IQKeyboardManager sharedManager] setEnable:YES];
        
        [[IQKeyboardManager sharedManager] setKeyboardDistanceFromTextField:15];
        //Enabling autoToolbar behaviour. If It is set to NO. You have to manually create UIToolbar for keyboard.
        [[IQKeyboardManager sharedManager] setEnableAutoToolbar:YES];
        
        //Setting toolbar behavious to IQAutoToolbarBySubviews. Set it to IQAutoToolbarByTag to manage previous/next according to UITextField's tag property in increasing order.
        [[IQKeyboardManager sharedManager] setToolbarManageBehaviour:IQAutoToolbarBySubviews];
        
        //Resign textField if touched outside of UITextField/UITextView.
        [[IQKeyboardManager sharedManager] setShouldResignOnTouchOutside:YES];
        
        //Giving permission to modify TextView's frame
        [[IQKeyboardManager sharedManager] setCanAdjustTextView:YES];
        [[IQKeyboardManager sharedManager] considerToolbarPreviousNextInViewClass:[myView class]];
        
        self.databaseName = @"PantryKart.sqlite";
        NSArray *documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentDir = [documentPaths objectAtIndex:0];
        self.databasePath = [documentDir stringByAppendingPathComponent:self.databaseName];
        NSLog(@"DB Path %@",self.databasePath);
        //  [Fabric with:@[CrashlyticsKit]];
        
        [self createAndCheckDatabase];
        [Crashlytics startWithAPIKey:@"dd490df3dd1259f449601a4cc887419ddf1e0f80"];
        [Fabric with:@[[Crashlytics class]]];
        // Crashlytics product key
        //        c3c15533b02539808875f7be0825861ebb187677811b1161be2d388d9ee88727
        
        [PayPalMobile initializeWithClientIdsForEnvironments:@{PayPalEnvironmentProduction : @"AdFAn5WzOQEs4QP6jjwi1NqTQk9arU54eqmGupTEo83Q5XpNpwmmai_CBsXD5V0UPbITom63XPFSQHqO",
                                                               PayPalEnvironmentSandbox : @"pantrykart-facilitator@gmail.com"}];
        
        
        SDWebImageManager.sharedManager.cacheKeyFilter = ^(NSURL *url) {
            url = [[NSURL alloc] initWithScheme:url.scheme host:url.host path:url.path];
            return [url absoluteString];
        };
        
        
        OBJGlobal.isfirstTimeDashBoardDataReceived=false;
        
        // appdelegate code....
        
        if ([application respondsToSelector:@selector(isRegisteredForRemoteNotifications)])
        {
            // iOS 8 Notifications
            [application registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeSound | UIUserNotificationTypeAlert | UIUserNotificationTypeBadge) categories:nil]];
            
            [application registerForRemoteNotifications];
        }
        else
        {  // iOS < 8 Notifications
            
        [application registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeSound | UIUserNotificationTypeAlert | UIUserNotificationTypeBadge) categories:nil]];
            
        }
    
        
        application.applicationIconBadgeNumber = 0;
        
        _isNotification = false;
        
        
        if (TARGET_OS_SIMULATOR)
        {
            [[NSUserDefaults standardUserDefaults]setObject:@"1234567894542154894521" forKey:@"device_token"];
            [[NSUserDefaults standardUserDefaults]synchronize];
        }
        else
        {
            if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
            {
                [[UIApplication sharedApplication] registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeSound | UIUserNotificationTypeAlert | UIUserNotificationTypeBadge) categories:nil]];
                [[UIApplication sharedApplication] registerForRemoteNotifications];
            }
            // This code will work in iOS 7.0 and below:
            else
            {
                [[UIApplication sharedApplication] registerForRemoteNotificationTypes: (UIRemoteNotificationTypeNewsstandContentAvailability| UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert)];
            }
            
        }
             
        // Override point for customization after application launch.
        return YES;
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    
    // Override point for customization after application launch.
    return YES;
}

-(void) createAndCheckDatabase
{
    BOOL success;
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    success = [fileManager fileExistsAtPath:databasePath];
    
    if(success) return;
    
    NSString *databasePathFromApp = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:self.databaseName];
    NSLog(@"Path %@",databasePathFromApp);
    
    [fileManager copyItemAtPath:databasePathFromApp toPath:databasePath error:nil];
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    
    badgeCount = badgeCount + 1;
    badgeCount = application.applicationIconBadgeNumber;
    // self.tabBarController.selectedIndex = 2;
    
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    if (_isNotification == YES) {
        [[NSNotificationCenter defaultCenter]postNotificationName:@"PushNotificationList" object:self];

    }
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


#pragma mark - Notification method
-(void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken{

    token = [[NSString alloc]init];
    token  = [[deviceToken description] stringByTrimmingCharactersInSet: [NSCharacterSet characterSetWithCharactersInString:@"<>"]];
    token  = [token  stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSLog(@"content---%@",token);
}

-(void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error
{
    
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult result))completionHandler
{
    _isNotification = YES;
    
}

-(void)authenticationMethod
{
    @try{
        NSString *strDeviceName=[[UIDevice currentDevice] name];
 
        Users *objAuth=[[Users alloc]init];
        objAuth.deviceType = [NSString stringWithFormat:@"ios"];
        
        objAuth.strAuth =[NSMutableString stringWithFormat:@"%@",([[[ASIdentifierManager sharedManager] advertisingIdentifier] UUIDString])];
        objAuth.strDeviceName = [NSMutableString stringWithFormat:@"%@",strDeviceName];
        [objAuth authentication:^(NSDictionary *user, NSString *str, int status)
         {
             
             if (status == 1) {
                 
                           NSString *strToken = [user valueForKey:@"isauth"];
                 NSString *stringWithoutSpaces = [strToken
                                                  stringByReplacingOccurrencesOfString:@"+" withString:@"%"];
                 UDSetObject(stringWithoutSpaces, @"AuthKey");
                        NSLog(@"success");
                 _isAuth=true;
             }
             else {
                 
                 NSLog(@"Failed");
                           }
         }];
        
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    
}

@end
