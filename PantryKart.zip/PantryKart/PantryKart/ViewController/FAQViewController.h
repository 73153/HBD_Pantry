//
//  FAQViewController.h
//  PantryKart
//
//  Created by karishma on 1/22/16.
//  Copyright © 2016 vivek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Globals.h"
#import "CommonPopUpView.h"

@interface FAQViewController : UIViewController
{
    NSString *strHtml;
}
@property NSString *strCms;
@property (nonatomic,strong) IBOutlet UIWebView *webFaq;

@end
