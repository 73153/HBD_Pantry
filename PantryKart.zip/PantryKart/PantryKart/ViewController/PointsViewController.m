//
//  PointsViewController.m
//  PantryKart
//
//  Created by karishma on 1/18/16.
//  Copyright © 2016 vivek. All rights reserved.
//

#import "PointsViewController.h"
#import "UIViewController+NavigationBar.h"
#import "Constant.h"
#import "Globals.h"
#import "CommonPopUpView.h"
#import "UIView+Toast.h"
#import "ReferInviteFriendViewController.h"
#import "PointsTableViewCell.h"

@interface PointsViewController ()
{
    Globals *OBJGlobal;
    UIButton *btnBadgeCount;
    Users *objReferPoints;
    BOOL UseMaxPoints;
    NSArray *aryRedeemPoints;
}
@end

@implementation PointsViewController
@synthesize tableView,lblNoAddress,viewEarnedPoints;

- (void)viewDidLoad {
    @try{
        [super viewDidLoad];
        
        OBJGlobal = [Globals sharedManager];
        
        objReferPoints=OBJGlobal.user;
        
        [self setUpImageBackButton:@"left-arrow"];
        [self referPointsMethod];
        [self transactionHistoryMethod];
           [self.viewEarnedPoints setHidden:YES];
        UseMaxPoints =false;
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

-(void)setUpContentData
{
    @try{
        UINib * mainView = [UINib nibWithNibName:@"CommonPopUpView" bundle:nil];
        OBJGlobal.objMainPopUp = (CommonPopUpView *)[mainView instantiateWithOwner:self options:nil][0];
        if(IS_IPHONE_6_PLUS)
        {
            OBJGlobal.objMainPopUp.frame=CGRectMake(10, 10, self.view.frame.size.width-20, self.view.frame.size.height-20);
        }else
            OBJGlobal.objMainPopUp.frame=CGRectMake(0, 5, self.view.frame.size.width, OBJGlobal.objMainPopUp.frame.size.height+60);
        [self.view addSubview:OBJGlobal.objMainPopUp];
        
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    @try{
        [OBJGlobal setNavigationTitleAndBGImageName:@"header" navigationController:self.navigationController];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 44, 44)];
        label.textAlignment = NSTextAlignmentCenter;
        label.lineBreakMode=NSLineBreakByWordWrapping;
        label.numberOfLines =0;
        label.font = [UIFont fontWithName:@"Avenir-Black" size:18];
        label.text = @"Points";
        label.textColor = [UIColor whiteColor];
        self.navigationItem.titleView = label;
        _txtPoints.delegate=self;
        
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

- (IBAction)btnEarnedPointPressed:(id)sender {
    [self earnedpoints];
}

- (IBAction)btnInvitefriendPressed:(id)sender {
    @try{
        ReferInviteFriendViewController *objReferInviteFriendViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ReferInviteFriendViewController"];
        objReferInviteFriendViewController.strReferBalance=_lblbalance.text;
        [self.navigationController pushViewController:objReferInviteFriendViewController animated:NO];
         }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    
}



-(void)referPointsMethod
{
    @try{
        if(GETBOOL(@"isUserHasLogin")==true){
            
            [APPDATA showLoader];
            [objReferPoints referPoints:^(NSDictionary *user, NSString *str, int status)
             {
                 if (status == 1) {
                     
                     aryPoints =[user objectForKey:@"data"];
                     
                     _lblPoints.text=[NSString stringWithFormat:@"$%.2f",[[user valueForKey:@"reward_money"]floatValue]];
                   
                     [APPDATA hideLoader];
                     
                     NSLog(@"success");
                 }
                 else {
                     if([OBJGlobal isNotNull:[user objectForKey:@"msg"]])
                         [self.view makeToast:[NSString stringWithFormat:@"%@",[user objectForKey:@"msg"]]];
                     NSLog(@"Failed");
                     [APPDATA hideLoader];
                 }
             }];
        }
        else
        {
            [self.view makeToast:@"Please login to view all address"];
        }
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

-(void)transactionHistoryMethod
{
    @try{
        if(GETBOOL(@"isUserHasLogin")==true){
            
            [APPDATA showLoader];
            [objReferPoints transactionHistory:^(NSDictionary *user, NSString *str, int status)
             {
                 if (status == 1) {
                     
                     
                     if([OBJGlobal isNotNull:[user objectForKey:@"history"]]){
                         
                         aryTransactionHistory =[user objectForKey:@"history"];
                     }
                     if([OBJGlobal isNotNull:[user objectForKey:@"balance"]])
                     {
                         _lblbalance.text=[NSString stringWithFormat:@"$%.2f",[[user objectForKey:@"balance"]floatValue]];
                     }
                     
                     if([OBJGlobal isNotNull:[user objectForKey:@"used_balance"]])
                     {
                         _lblused_balance.text=[NSString stringWithFormat:@"$%.2f",[[user objectForKey:@"used_balance"]floatValue]];
                         
                     }
                     if([OBJGlobal isNotNull:[user objectForKey:@"earned"]])
                     {
                         _lblearned.text=[NSString stringWithFormat:@"$%.2f",[[user objectForKey:@"earned"]floatValue]];
                     }
                     if([OBJGlobal isNotNull:[user objectForKey:@"referral_count"]])
                     {
                         _lblrefferalPoint.text=[NSString stringWithFormat:@"%@",[user objectForKey:@"referral_count"]];
                     }
                    [tableView reloadData];
                     [APPDATA hideLoader];
                     
                     NSLog(@"success");
                 }
                 else {
                     if([OBJGlobal isNotNull:[user objectForKey:@"msg"]])
                         [self.view makeToast:[NSString stringWithFormat:@"%@",[user objectForKey:@"msg"]]];
                     NSLog(@"Failed");
                     [APPDATA hideLoader];
                 }
             }];
        }
        else
        {
            [self.view makeToast:@"Please login to view all address"];
        }
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}




#pragma mark - tableView Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{
    return [aryTransactionHistory count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;

{
    @try
    {
        static NSString *CellIdentifier = @"PointsTableViewCell";
        
        PointsTableViewCell *cell =[self.tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
        if (cell == nil)
        {
            cell = [[PointsTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            
        }
        cell.selectionStyle= UITableViewCellSelectionStyleNone;
        
        NSDictionary *dict = [[NSDictionary alloc] init];
        self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        
        dict = [aryTransactionHistory objectAtIndex:indexPath.row];
        
        cell.lblTransactionComment.numberOfLines=3;
        cell.lblTransactionComment.lineBreakMode=NSLineBreakByWordWrapping;
        cell.lblSepComment.numberOfLines=2;
        cell.lblSepComment.lineBreakMode=NSLineBreakByTruncatingTail;
        if([OBJGlobal isNotNull:[dict valueForKey:@"transaction_comment"]]){
            
            NSString *strtemp=[dict valueForKey: @"transaction_comment"];
            NSArray* foo = [strtemp componentsSeparatedByString: @"\\n"];
            NSString* firstline;
            NSString* secondline;
            if (foo.count >= 2) {
              firstline = [foo objectAtIndex: 0];
              secondline = [foo objectAtIndex: 1];
            }
            else
                firstline = [foo objectAtIndex: 0];

            if ([OBJGlobal isNotNull:firstline]) {
                 cell.lblTransactionComment.text=firstline;
            }
             if ([OBJGlobal isNotNull:secondline])
            {
                cell.lblSepComment.text=secondline;
            }
        }
        if([OBJGlobal isNotNull:[dict valueForKey:@"transaction_status"]]){
            cell.lblType.text=[NSString stringWithFormat:@"%@",[dict valueForKey:@"transaction_status"]];
        }
        NSString *strtype=[[NSString alloc]init];
        
        if([OBJGlobal isNotNull:[dict valueForKey:@"type_of_transaction"]]){
            strtype=[NSString stringWithFormat:@"%@",[dict valueForKey:@"type_of_transaction"]];
        }
        if([OBJGlobal isNotNull:[dict valueForKey:@"amount"]]){
            if([strtype isEqualToString:@"Credit"])
            {
                cell.lblCreditAmmount.text=[NSString stringWithFormat:@"+%@",[dict valueForKey:@"amount"]];
            }
            else{
                cell.lblCreditAmmount.text=[NSString stringWithFormat:@"-%@",[dict valueForKey:@"amount"]];
            }
        }
        if([OBJGlobal isNotNull:[dict valueForKey:@"transaction_time"]]){
          
             NSString *strTemp = [NSString stringWithFormat:@"%@",[dict valueForKey:@"transaction_time"]];
                NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
                [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
                NSDate *date = [dateFormatter dateFromString:strTemp];
                
                NSTimeZone *tz = [NSTimeZone defaultTimeZone];
                NSInteger seconds = [tz secondsFromGMTForDate: date];
                date =  [NSDate dateWithTimeInterval: seconds sinceDate: date];
                
                NSLog(@"Date:%@", date);
                [dateFormatter setDateFormat:@"MMMM dd, YYYY hh:mm a"];
                NSString *strFinal = [dateFormatter stringFromDate:date];
                NSLog(@"Final:%@", strFinal);
               cell.lblTime.text = strFinal;
            }
        
        return cell;
        
        
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 130;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView;
{
    return 1;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
}



-(IBAction)btnClosePopupPressed:(id)sender;
{
    @try{
        [self.viewEarnedPoints setHidden:YES];
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    
}


- (IBAction)btnSubmitEarnedPoints:(id)sender {
    @try{
        [self.view endEditing:TRUE];
        [self.viewEarnedPoints setHidden:NO];
        OBJGlobal.strRedeemPoints = _txtPoints.text;
        [self CheckoutRedeemPointsMethod];
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

- (IBAction)btnRadio:(id)sender {
    @try{
        [self.view endEditing:TRUE];
        _btnRadio.selected = !_btnRadio.selected;
        UseMaxPoints =TRUE;
        if(_btnRadio.selected)
        {
            _btnRadio.selected=YES;
        }
        else
        {     UseMaxPoints =false;
            _btnRadio.selected=NO;
            if ( UseMaxPoints ==false) {
                _txtPoints.text=0;
            }
            
        }
        
        if ( UseMaxPoints ==TRUE) {
            _txtPoints.text=OBJGlobal.strEarnedPoints;
        }
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    
}

-(void)CheckoutRedeemPointsMethod
{
    @try{
        
        NSString *strTemp = _txtPoints.text;
        if ([OBJGlobal.strEarnedPoints intValue] < [strTemp intValue] ){
            [self.view makeToast:[NSString stringWithFormat:@"You can use maximum %@ points",OBJGlobal.strEarnedPoints]];
            
        }
        else{
            
            
            if(GETBOOL(@"isUserHasLogin")==true){
                [self.view endEditing:TRUE];
                Users *objRedeemPoints = OBJGlobal.user;
                objRedeemPoints.Points=[_txtPoints.text mutableCopy];
                
                [APPDATA showLoader];
                [objRedeemPoints checkoutRedeemPoints:^(NSDictionary *user, NSString *str, int status)
                 {
                     if (status == 1) {
                        [self transactionHistoryMethod];
                         
                         aryRedeemPoints =[user objectForKey:@"data"];
                       
                         [self.viewEarnedPoints setHidden:YES];
                         NSLog(@"success");
                     }
                     else {
                         if([OBJGlobal isNotNull:[user objectForKey:@"msg"]])
                             [self.view makeToast:[NSString stringWithFormat:@"%@",[user objectForKey:@"msg"]]];
                         NSLog(@"Failed");
                         [APPDATA hideLoader];
                     }
                 }];
            }
            else
            {
                [self.view makeToast:@"Please login to view all address"];
            }
        }
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

-(void)earnedpoints
{
       @try{
            Users *objearnedPoints = OBJGlobal.user;
           
            if(GETBOOL(@"isUserHasLogin")==true){
                
                [APPDATA showLoader];
                [objearnedPoints checkoutRefferalPoints:^(NSDictionary *user, NSString *str, int status)
                 {
                     if (status == 1) {
                         
                         OBJGlobal.strEarnedPoints =[NSMutableString stringWithFormat:@"%@",[user objectForKey:@"maximum_allowed_points"]];
                         
                         _lblEarnedPoints.text =[NSMutableString stringWithFormat:@"Use maximum (%@ points)",OBJGlobal.strEarnedPoints];
                    
                         if ([OBJGlobal isNotNull:OBJGlobal.strRedeemPoints]) {
                             _txtPoints.text = OBJGlobal.strRedeemPoints;
                         }
                         [self.viewEarnedPoints setHidden:NO];
                         
                         
                         [APPDATA hideLoader];
                         
                         NSLog(@"success");
                     }
                     else {
                        [self.view makeToast:@"Sorry,you have no points to redeem."];
                         NSLog(@"Failed");
                         [APPDATA hideLoader];
                     }
                 }];
            }
            else
            {
                [self.view makeToast:@"Please login to view all address"];
            }
        } @catch (NSException *exception) {
            NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
        }

}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if([string isEqualToString:@" "])
    {
        
        return NO;
    }
    else
    {
        return YES;
    }
  }

@end
