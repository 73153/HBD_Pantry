//
//  ReferInviteFriendViewController.h
//  PantryKart
//
//  Created by vivek on 4/11/16.
//  Copyright © 2016 vivek. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReferInviteFriendViewController : UIViewController<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UITextField *txtEmail;
@property (weak, nonatomic) IBOutlet UITextField *txtFriendsEmail;
@property (weak, nonatomic) IBOutlet UITextView *txtComment;
@property (weak, nonatomic) IBOutlet UILabel *lblReferBalance;
@property (strong,nonatomic)NSString *strReferBalance;

- (IBAction)btnSendEmailPressed:(id)sender;

-(void)referralMethod;


@end
