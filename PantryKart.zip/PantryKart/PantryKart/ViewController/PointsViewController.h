//
//  PointsViewController.h
//  PantryKart
//
//  Created by karishma on 1/18/16.
//  Copyright © 2016 vivek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Globals.h"
#import "CommonPopUpView.h"

@interface PointsViewController : UIViewController <UITextFieldDelegate>
{
    NSMutableArray *aryPoints;
    NSMutableArray *aryRefferalData;
     NSMutableArray *aryTransactionHistory;
}

@property (weak, nonatomic) IBOutlet UILabel *lblPoints;
@property (weak, nonatomic) IBOutlet UILabel *lblbalance;
@property (weak, nonatomic) IBOutlet UILabel *lblused_balance;
@property (weak, nonatomic) IBOutlet UILabel *lblearned;
@property (weak, nonatomic) IBOutlet UILabel *lblrefferalPoint;
@property(strong,nonatomic)IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UILabel *lblNoAddress;
@property (weak, nonatomic) IBOutlet UIView *viewEarnedPoints;
@property (weak, nonatomic) IBOutlet UILabel *lblEarnedPoints;
@property (weak, nonatomic) IBOutlet UITextField *txtPoints;
@property (weak, nonatomic) IBOutlet UIButton *btnSumbitEarnedPoints;
@property (weak, nonatomic) IBOutlet UIButton *btnEarnedPoints;

- (IBAction)btnEarnedPointPressed:(id)sender;

- (IBAction)btnInvitefriendPressed:(id)sender;
- (IBAction)btnSubmitEarnedPoints:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btnRadio;

- (IBAction)btnRadio:(id)sender;

-(void)referPointsMethod;

@end
