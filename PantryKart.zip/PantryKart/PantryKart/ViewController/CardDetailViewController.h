//
//  CardDetailViewController.h
//  PantryKart
//
//  Created by karishma on 3/11/16.
//  Copyright © 2016 vivek. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CardDetailViewController : UIViewController <UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate>
{
    NSMutableArray *aryCardDetailList;
    NSString *strcard_Delete;
    
    
}

@property (weak, nonatomic) IBOutlet UILabel *lblNoCard;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIButton *btnNewCardPressed;
@property (weak, nonatomic) IBOutlet UIView *viewPayment;
@property (nonatomic,strong) IBOutlet UITextField *txtCvv;
@property (weak, nonatomic) IBOutlet UIButton *btnContinue;

-(IBAction)btnCancelPressed:(id)sender;
-(IBAction)btnContinuePressed:(id)sender;
-(IBAction)btnProceedPayment:(id)sender;
-(IBAction)btnNewCardPressed:(id)sender;

-(void)cardListMethod;
-(void)cardListMethodDeleteMethod:(NSInteger)index;
-(void)paymentProceedCard;

@end
