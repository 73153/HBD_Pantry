//
//  ShoppingListViewController.h
//  PantryKart
//
//  Created by vivek on 1/22/16.
//  Copyright © 2016 vivek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIPlaceHolderTextView.h"

@interface ShoppingListViewController : UIViewController
{
    NSMutableArray *aryViewShopping,*aryShareWishlist;
}

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UILabel *lblNoShippingData;
@property (weak, nonatomic) IBOutlet UITextField *txtEmail;
@property (weak, nonatomic) IBOutlet UITextView *txtMessage;
@property (weak, nonatomic) IBOutlet UIView *viewShopping;
@property (weak, nonatomic) IBOutlet UIPlaceHolderTextView *txtviewMessage;
-(IBAction)cancelViewTapped:(UIButton*)sender;
-(IBAction)continueShopingTapped:(UIButton*)sender;
- (IBAction)btnAddAllToKart:(id)sender;
- (IBAction)btnSubmitPressed:(id)sender;
-(void)ShowShareWishlist;
@end
