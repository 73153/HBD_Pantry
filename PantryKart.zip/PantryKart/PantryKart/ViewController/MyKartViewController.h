//
//  MyKartViewController.h
//  PantryKart
//
//  Created by vivek on 1/12/16.
//  Copyright © 2016 vivek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Globals.h"
#import "CommonPopUpView.h"
#import "UIViewController+RESideMenu.h"

@interface MyKartViewController : UIViewController

@property (nonatomic,strong) IBOutlet UIButton *btnApplyCoupon;
@property (nonatomic,strong) IBOutlet UIButton *btnPayFromWallet;
@property (nonatomic,strong) IBOutlet UIButton *btnCheckOut;
@property (weak, nonatomic) IBOutlet UITableView *tblView;
@property (weak, nonatomic) IBOutlet UILabel *lblCouponPoints;
@property (weak, nonatomic) IBOutlet UILabel *lblShipping;
@property (weak, nonatomic) IBOutlet UILabel *lblPriceTotal;
@property (weak, nonatomic) IBOutlet UILabel *lblTotalPoints;
@property (weak, nonatomic) IBOutlet UILabel *lblNoKartData;
@property (weak, nonatomic) IBOutlet UILabel *lblPayableTotalAmount;
@property (weak, nonatomic) IBOutlet UILabel *lblAddMore;
@property (nonatomic,strong) IBOutlet UIView *viewEarnedPoints;
@property (nonatomic,strong) IBOutlet UIButton *btnSubmitEarnedPoint;
@property (nonatomic,strong) IBOutlet UIButton *btnClosePopup;
@property (nonatomic,strong) IBOutlet UITextField *txtPoints;
@property (nonatomic,strong) IBOutlet UIButton *btnRadioPoints;
@property (weak, nonatomic) IBOutlet UILabel *lblUsedPoints;
@property (nonatomic,strong) IBOutlet UIButton *btnPlaceOrder;
@property NSMutableArray * aryCardList;
@property NSMutableString * strCvv;
// payment detail parameter

@property NSMutableString * strcardType;
@property NSMutableString * strcardNumber;
@property NSMutableString * strcardOwnerName;
@property NSMutableString * strCvvPayment;
@property NSMutableString * strexpiryMonth;
@property NSMutableString * strexpiryYear;
@property BOOL strstoreCard;








- (IBAction)btnPlaceOrderPressed:(id)sender;
- (IBAction)btnPayFromWalletPressed:(id)sender;
- (IBAction)btnApplyCouponPressed:(id)sender;
- (IBAction)btnCheckOutPressed:(id)sender;
- (IBAction)btnClosePopupPressed:(id)sender;
- (IBAction)btnProccedEarnedPointPressed:(id)sender;
- (IBAction)btnRadioPointsPressed:(id)sender;

-(void)myCartMethod;
-(void)btnMinusPressed:(id)sender;
-(void)btnPlusPressed:(id)sender;
-(void)btnDeletePressed:(id)sender;

@end
