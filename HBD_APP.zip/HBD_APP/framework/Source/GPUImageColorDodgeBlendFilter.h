#import "GPUImageTwoInputFilter.h"

/** Applies a color dodge blend of two images
 */
@interface GPUImageColorDodgeBlendFilter : GPUImageTwoInputFilter
{
}

@end
