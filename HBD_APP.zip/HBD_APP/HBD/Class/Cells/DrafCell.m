//
//  DrafCell.m
//  HBD
//
//  Created by HoanVu on 11/6/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import "DrafCell.h"

@implementation DrafCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
