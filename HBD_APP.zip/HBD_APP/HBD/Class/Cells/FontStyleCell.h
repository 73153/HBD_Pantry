//
//  FontStyleCell.h
//  HBD
//
//  Created by Tuan Le on 10/30/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FontStyleCell : UITableViewCell
@property(nonatomic,retain) IBOutlet UIImageView *imgcheck;
@property(nonatomic,retain) IBOutlet UILabel *lbfont;
@end
