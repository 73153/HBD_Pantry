//
//  FBTagFriendCell.h
//  HBD
//
//  Created by HoanVu on 10/8/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FBTagFriendCell : UITableViewCell
{
}
@property (weak, nonatomic) IBOutlet UILabel *nameLblLeft;
@property (weak, nonatomic) IBOutlet UIButton *deleteBtnLeft;
@property (weak, nonatomic) IBOutlet UILabel *nameLblRight;
@property (weak, nonatomic) IBOutlet UIButton *deleteBtnRight;
@property (weak, nonatomic) IBOutlet UIView *viewleft;
@property (weak, nonatomic) IBOutlet UIView *viewright;

@end
