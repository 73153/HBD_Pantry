//
//  imgSearchCVC.h
//  HBD
//
//  Created by pradip.r on 5/6/16.
//  Copyright © 2016 HungHT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AsyncImageView.h"

@interface imgSearchCVC : UICollectionViewCell
@property (strong, nonatomic) IBOutlet UIImageView *imageSearch;
//@property (strong, nonatomic) IBOutlet AsyncImageView *imageSearch;
@end
