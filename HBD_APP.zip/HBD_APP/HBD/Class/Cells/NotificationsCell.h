//
//  NotificationsCell.h
//  HBD
//
//  Created by HoanVu on 8/22/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NotificationsCell : UITableViewCell
{}
@property (weak, nonatomic) IBOutlet UIButton *deleteIcon;
@property (weak, nonatomic) IBOutlet UIImageView *avaSenderImageView;

@property (weak, nonatomic) IBOutlet UIButton *checkBtn;
@property (weak, nonatomic) IBOutlet UILabel *contentLbl;
@property (weak, nonatomic) IBOutlet UIButton *readNtfBtn;
@property (strong, nonatomic) IBOutlet UIView *contentView;
@property (strong,nonatomic) IBOutlet UILabel *lblTimeStamp;

@end
