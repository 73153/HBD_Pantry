//
//  FeedCell.m
//  HBD
//
//  Created by HoanVu on 9/10/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import "FeedCell.h"
#import "TTTAttributedLabel.h"

@implementation FeedCell

- (void)awakeFromNib
{
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)attributedLabel:(TTTAttributedLabel *)label didSelectLinkWithURL:(NSURL *)url
{
    
 //   NSLog(@"%ld",(long)label.tag);
    
    
    if ([[url scheme] hasPrefix:@"action"]) {
        if ([[url host] hasPrefix:@"show-help"])
        {
            
            /* load help screen */
        } else if ([[url host] hasPrefix:@"show-settings"]) {
            /* load settings screen */
        }
    } else {
        /* deal with http links here */
    }}

@end
