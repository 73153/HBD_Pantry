//
//  ColorCell.h
//  HBD
//
//  Created by HoanVu on 9/5/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ColorCell : UITableViewCell
{
}
@property (weak, nonatomic) IBOutlet UILabel *nameColorLbl;
@property (weak, nonatomic) IBOutlet UIView *valueColorView;
@property (weak, nonatomic) IBOutlet UIImageView *imgcheck;
@end
