//
//  UserWishlistCell.h
//  HBD
//
//  Created by HoanVu on 12/13/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserWishlistCell : UITableViewCell
{
}
@property (weak, nonatomic) NSMutableArray *aryUserDetail;
@property (weak, nonatomic) IBOutlet UIView *viewleft;
@property (weak, nonatomic) IBOutlet UITextView *textView1;
@property (weak, nonatomic) IBOutlet UIButton *btn1;

@property (weak, nonatomic) IBOutlet UIView *viewright;
@property (weak, nonatomic) IBOutlet UITextView *textView2;
@property (weak, nonatomic) IBOutlet UIButton *btn2;

@end