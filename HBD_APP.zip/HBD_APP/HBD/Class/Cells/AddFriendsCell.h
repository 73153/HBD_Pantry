//
//  AddFriendsCell.h
//  HBD
//
//  Created by Bhumesh on 15/04/16.
//  Copyright © 2016 HungHT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "addFriendButton.h"
@interface AddFriendsCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIButton *ProfieImg;
@property (strong, nonatomic) IBOutlet UILabel *Name;
@property (strong, nonatomic) IBOutlet UILabel *dob;
@property (strong, nonatomic) IBOutlet addFriendButton *btnConnect;
@property (strong, nonatomic) IBOutlet UIView *viewGender;

- (IBAction)btnConnectTapped:(id)sender;
@property (strong, nonatomic) IBOutlet UIImageView *imgProfile;


@end
