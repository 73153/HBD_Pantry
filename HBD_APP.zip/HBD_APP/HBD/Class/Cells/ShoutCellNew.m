//
//  ShoutCellNew.m
//  HBD
//
//  Created by arpit on 4/12/16.
//  Copyright © 2016 HungHT. All rights reserved.
//

#import "ShoutCellNew.h"

@implementation ShoutCellNew

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (IBAction)OnBtnPlayVideoTapped:(id)sender {
}
@end
