//
//  FBFriendCell.h
//  HBD
//
//  Created by HoanVu on 10/8/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FBFriendCell : UITableViewCell
{
}
@property (weak, nonatomic) IBOutlet UILabel *nameLbl;
@property (weak, nonatomic) IBOutlet UIButton *selectBtn;


@end
