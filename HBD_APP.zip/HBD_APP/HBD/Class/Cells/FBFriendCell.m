//
//  FBFriendCell.m
//  HBD
//
//  Created by HoanVu on 10/8/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import "FBFriendCell.h"

@implementation FBFriendCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
