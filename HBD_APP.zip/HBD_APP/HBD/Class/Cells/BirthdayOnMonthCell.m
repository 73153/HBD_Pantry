//
//  BirthdayOnMonthCell.m
//  HBD
//
//  Created by HoanVu on 8/19/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import "BirthdayOnMonthCell.h"
#import "WishListVC.h"

@implementation BirthdayOnMonthCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)onbtnWishList:(id)sender
{
    UIButton *btn=(UIButton *)sender;
    NSInteger tagId=btn.tag;
    NSString *str=[NSString stringWithFormat:@"%ld",(long)tagId ];
    delegate = (AppDelegate*) [[UIApplication sharedApplication] delegate];
    _singleton = [MySingleton getInstance];
//    delegate.tabbarController.selectedIndex = 4;
//    _singleton.selectShouted = 0;
//    _singleton.selectDrafts = 0;
//    _singleton.selectWishList = 1;
//    _singleton.tagRecordVideo = 0;
//    _singleton.tagSetting = 0;
    _singleton.isFromFriendCell = YES;
    _singleton.friendId = btn.tag;
//
//    delegate.tabbarController.selectedIndex = 4;
//    
//    
//    WishListVC *objSettingViewController = [[WishListVC alloc] initWithNibName:@"WishListVC" bundle:[NSBundle mainBundle]];
//    UINavigationController *navcon = (UINavigationController*)delegate.tabbarController.selectedViewController;
//    navcon.tabBarItem.tag = 4 ;
//    navcon.navigationBarHidden = YES ;
//    [navcon pushViewController:objSettingViewController animated:false];
//    
    
   
    
    [delegate goToWishList:str];
}
@end
