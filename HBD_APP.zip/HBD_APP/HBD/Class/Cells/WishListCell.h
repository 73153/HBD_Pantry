//
//  WishListCell.h
//  HBD
//
//  Created by HoanVu on 8/21/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WishListCell : UITableViewCell
{
}
@property (weak, nonatomic) IBOutlet UIButton *deleteBtn1;
@property (weak, nonatomic) IBOutlet UIButton *deleteBtn1Cover;
@property (weak, nonatomic) IBOutlet UITextView *itemName1;
@property (weak, nonatomic) IBOutlet UIButton *goVenderBtn1;

@property (weak, nonatomic) IBOutlet UIButton *deleteBtn2;
@property (weak, nonatomic) IBOutlet UIButton *deleteBtn2Cover;
@property (weak, nonatomic) IBOutlet UITextView *itemName2;
@property (weak, nonatomic) IBOutlet UIButton *goVenderBtn2;

@property (weak, nonatomic) IBOutlet UIView *viewleft;
@property (weak, nonatomic) IBOutlet UIView *viewright;

@end
