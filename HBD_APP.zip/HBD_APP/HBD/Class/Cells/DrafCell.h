//
//  DrafCell.h
//  HBD
//
//  Created by HoanVu on 11/6/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DrafCell : UITableViewCell
{
}
@property (weak, nonatomic) IBOutlet UIImageView *imageDraf1;
@property (weak, nonatomic) IBOutlet UIImageView *imageDraf2;
@property (weak, nonatomic) IBOutlet UIImageView *imageDraf3;
@property (weak, nonatomic) IBOutlet UIButton *playDraftBtn1;
@property (weak, nonatomic) IBOutlet UIButton *playDraftBtn2;
@property (weak, nonatomic) IBOutlet UIButton *playDraftBtn3;


@end
