//
//  FriendCell.m
//  HBD
//
//  Created by HungHT on 8/9/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import "FriendCell.h"
#import "WishListCell.h"
#import "WishListVC.h"
#import "AppDelegate.h"

@implementation FriendCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)onbtnWishList:(id)sender
{
    UIButton *btn=(UIButton *)sender ;
    NSString *strId=[NSString stringWithFormat:@"%ld",(long)btn.tag];
    _delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
     _singleton = [MySingleton getInstance];
    
    if (_singleton.isFriendCellFromHome) {
        _singleton.isFriendCellFromHome=NO;
    }else{
    [_delegate goRight];
    }
    NSString *my =[NSString stringWithFormat:@"%@",_singleton.myId];
    if (![strId isEqualToString:my]) {
        _singleton.isFromFriendCell = YES;
        _singleton.friendId = btn.tag ;
    }
    
//    _delegate.tabbarController.selectedIndex = 4;
    
//    _singleton.selectShouted = 0;
//    _singleton.selectDrafts = 0;
//    _singleton.selectWishList = 1;
//    _singleton.tagRecordVideo = 0;
//    _singleton.tagSetting = 0;
//    
//    WishListVC *objSettingViewController = [[WishListVC alloc] initWithNibName:@"WishListVC" bundle:[NSBundle mainBundle]];
//    UINavigationController *navcon = (UINavigationController*)_delegate.tabbarController.selectedViewController;
//    navcon.tabBarItem.tag = 4 ;
//    navcon.navigationBarHidden = YES ;
//    [navcon pushViewController:objSettingViewController animated:false];
    
     _delegate.tabbarController.selectedIndex = 4;
    [_delegate goToWishList:strId];
}
@end
