//
//  DeleteCell.h
//  HBD
//
//  Created by HoanVu on 12/15/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeleteCell : UITableViewCell
{
}
@property (weak, nonatomic) IBOutlet UIButton *deleteBtn;


@end
