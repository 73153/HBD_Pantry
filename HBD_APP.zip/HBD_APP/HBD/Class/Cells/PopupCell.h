//
//  PopupCell.h
//  HBD
//
//  Created by Tuan Le on 10/27/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PopupCell : UITableViewCell
@property (nonatomic,retain) IBOutlet UIImageView *imgspecial;
@property (nonatomic,retain) IBOutlet UIImageView *imgstar;
@property (nonatomic,retain) IBOutlet UIButton *sendShout;
@property (nonatomic,retain) IBOutlet UIButton *viewWhishList;
@property (nonatomic,retain) IBOutlet UILabel *lblname;
@property (weak, nonatomic) IBOutlet UIButton *viewZodaicBtn;

@end
