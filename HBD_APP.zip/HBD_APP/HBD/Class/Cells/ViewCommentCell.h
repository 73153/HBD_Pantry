//
//  ViewCommentCell.h
//  HBD
//
//  Created by HoanVu on 11/6/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TTTAttributedLabel.h"

@interface ViewCommentCell : UITableViewCell<TTTAttributedLabelDelegate>
{
}
@property (weak, nonatomic) IBOutlet UIImageView *avaSenderBtn;
@property (weak, nonatomic) IBOutlet UILabel *senderNameLbl;
@property (weak, nonatomic) IBOutlet UITextView *cmtTextView;
@property (weak, nonatomic) IBOutlet UIButton *visitProfile3;
@property (strong, nonatomic) IBOutlet TTTAttributedLabel *commentLabel;
//@property (strong, nonatomic) IBOutlet UILabel *commentLbl;
- (void)attributedLabel:(TTTAttributedLabel *)label didSelectLinkWithURL:(NSURL *)url;
@end
