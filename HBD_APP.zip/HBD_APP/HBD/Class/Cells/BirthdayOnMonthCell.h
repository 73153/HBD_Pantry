//
//  BirthdayOnMonthCell.h
//  HBD
//
//  Created by HoanVu on 8/19/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "MySingleton.h"

@interface BirthdayOnMonthCell : UITableViewCell
{
    AppDelegate *delegate;
}
@property(nonatomic, strong) MySingleton *singleton;
@property (weak, nonatomic) IBOutlet UILabel *notificationBirthdayLbl;
@property (weak, nonatomic) IBOutlet UIButton *coverCellBtn;

@property (weak, nonatomic) IBOutlet UIImageView *zodiacImageView;
@property (weak, nonatomic) IBOutlet UIImageView *specialImageView;
@property (strong, nonatomic) IBOutlet UIImageView *profileIamgeView;
@property (strong, nonatomic) IBOutlet UILabel *lblDate;
- (IBAction)onbtnWishList:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *btnwishList;
@end
