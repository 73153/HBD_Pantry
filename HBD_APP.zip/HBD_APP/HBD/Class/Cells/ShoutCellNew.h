//
//  ShoutCellNew.h
//  HBD
//
//  Created by arpit on 4/12/16.
//  Copyright © 2016 HungHT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShoutCellNew : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgThumb;
@property (weak, nonatomic) IBOutlet UIButton *btnPlayVideo;
- (IBAction)OnBtnPlayVideoTapped:(id)sender;

@end
