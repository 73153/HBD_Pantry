//
//  SettingCell.h
//  HBD
//
//  Created by HoanVu on 9/30/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingCell : UITableViewCell
{
}
@property (weak, nonatomic) IBOutlet UIView *contentSubView;
@property (weak, nonatomic) IBOutlet UIImageView *imageBtn;
@property (weak, nonatomic) IBOutlet UIButton *clickBtn;
@property (weak, nonatomic) IBOutlet UIButton *imageItemBtn;


@end
