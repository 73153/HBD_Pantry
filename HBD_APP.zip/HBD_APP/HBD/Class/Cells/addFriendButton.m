//
//  addFriendButton.m
//  HBD
//
//  Created by tusharpatel on 21/04/16.
//  Copyright © 2016 HungHT. All rights reserved.
//

#import "addFriendButton.h"

@implementation addFriendButton

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
