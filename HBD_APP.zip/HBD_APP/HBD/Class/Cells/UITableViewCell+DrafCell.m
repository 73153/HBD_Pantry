//
//  UITableViewCell+DrafCell.m
//  HBD
//
//  Created by HoanVu on 11/6/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import "UITableViewCell+DrafCell.h"

@implementation UITableViewCell (DrafCell)

@end
