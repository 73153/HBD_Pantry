//
//  FontStyleCell.m
//  HBD
//
//  Created by Tuan Le on 10/30/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import "FontStyleCell.h"

@implementation FontStyleCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
