//
//  FeedCell.h
//  HBD
//
//  Created by HoanVu on 9/10/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TTTAttributedLabel.h"

@interface FeedCell : UITableViewCell<UITextFieldDelegate,TTTAttributedLabelDelegate>
{
}

@property (weak, nonatomic) IBOutlet UIImageView *avatarImageView;
@property (weak, nonatomic) IBOutlet UITextView *contentShoutTextView;
@property (weak, nonatomic) IBOutlet UILabel *timeCreateLbl;
@property (weak, nonatomic) IBOutlet UIButton *privateLbl;
@property (weak, nonatomic) IBOutlet UIButton *visitReceiver;
@property (weak, nonatomic) IBOutlet UIButton *visitProfile;
@property (weak, nonatomic) IBOutlet UIButton *visitProfile2;
@property (weak, nonatomic) IBOutlet UILabel *titleHBDLbl;
@property (weak, nonatomic) IBOutlet UIImageView *frameImageView;
@property (weak, nonatomic) IBOutlet UIImageView *thumbnailImageView;
@property (weak, nonatomic) IBOutlet UIImageView *filterImageView;
@property (weak, nonatomic) IBOutlet UITextView *messageBirthdayTextView;
@property (weak, nonatomic) IBOutlet UIButton *playVideoBtn;
@property (weak, nonatomic) IBOutlet UIButton *likeBtn;
@property (weak, nonatomic) IBOutlet UIView *view1;
@property (weak, nonatomic) IBOutlet UIView *view2;
#pragma mark - User Comment View
@property (weak, nonatomic) IBOutlet UIView *userCmtView;
@property (weak, nonatomic) IBOutlet UIImageView *avatarReceiver;
@property (weak, nonatomic) IBOutlet UILabel *titleCmtLbl;
//@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@property (strong, nonatomic) IBOutlet TTTAttributedLabel *contentCommentlbl;

#pragma mark - Input Comment View
@property (weak, nonatomic) IBOutlet UIButton *likeUnlikeBtn;
@property (weak, nonatomic) IBOutlet UIButton *likeUnlikeBtn1;
@property (weak, nonatomic) IBOutlet UIImageView *likedImage;
@property (weak, nonatomic) IBOutlet UIImageView *likedImage1;

@property (weak, nonatomic) IBOutlet UIView *inputCmtView;
@property (weak, nonatomic) IBOutlet UIButton *viewOtherCmtBtn1;
@property (weak, nonatomic) IBOutlet UIButton *viewOtherCmtBtn2;

@property (weak, nonatomic) IBOutlet UILabel *countLikeLbl;
@property (weak, nonatomic) IBOutlet UILabel *countLikeLbl1;



@property (weak, nonatomic) IBOutlet UIButton *editCmtBtn;
@property (weak, nonatomic) IBOutlet UIButton *editCmtBtn1;

@property (weak, nonatomic) IBOutlet UITextField *commentInputTextFied;
@property (weak, nonatomic) IBOutlet UITextField *commentInputTextFied1;
@property (weak, nonatomic) IBOutlet UIButton *shareCmtBtn;
@property (weak, nonatomic) IBOutlet UIButton *shareCmtBtnCover;
@property (weak, nonatomic) IBOutlet UIButton *shareCmtBtn1;
@property (weak, nonatomic) IBOutlet UIButton *shareCmtBtn1Cover;
@property (weak, nonatomic) IBOutlet UIButton *removeMyCmtBtn;
@property (weak, nonatomic) IBOutlet UIButton *flagPostButton;
- (void)attributedLabel:(TTTAttributedLabel *)label didSelectLinkWithURL:(NSURL *)url;
@property (strong, nonatomic) IBOutlet TTTAttributedLabel *titleLabel;

@end
