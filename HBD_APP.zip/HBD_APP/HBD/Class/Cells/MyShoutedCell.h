//
//  MyShoutedCell.h
//  HBD
//
//  Created by HoanVu on 9/23/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyShoutedCell : UITableViewCell
{
}
@property (weak, nonatomic) IBOutlet UIView *contentView;
@property (weak, nonatomic) IBOutlet UIImageView *imageView1;
@property (weak, nonatomic) IBOutlet UIImageView *imageView2;
@property (weak, nonatomic) IBOutlet UIImageView *imageView3;
@property (weak, nonatomic) IBOutlet UIButton *playBtn1;
@property (weak, nonatomic) IBOutlet UIButton *playBtn2;
@property (weak, nonatomic) IBOutlet UIButton *playBtn3;


@end
