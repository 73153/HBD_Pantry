 //
//  PopupCell.m
//  HBD
//
//  Created by Tuan Le on 10/27/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import "PopupCell.h"

@implementation PopupCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
