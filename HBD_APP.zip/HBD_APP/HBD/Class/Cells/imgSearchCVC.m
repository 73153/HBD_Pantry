//
//  imgSearchCVC.m
//  HBD
//
//  Created by pradip.r on 5/6/16.
//  Copyright © 2016 HungHT. All rights reserved.
//

#import "imgSearchCVC.h"

@implementation imgSearchCVC

- (void)awakeFromNib {
    [super awakeFromNib];
   }

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}
@end
