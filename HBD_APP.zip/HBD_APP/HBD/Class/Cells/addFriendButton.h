//
//  addFriendButton.h
//  HBD
//
//  Created by tusharpatel on 21/04/16.
//  Copyright © 2016 HungHT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface addFriendButton : UIButton
@property NSDictionary *param;
@end
