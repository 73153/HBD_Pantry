//
//  FriendCell.h
//  HBD
//
//  Created by HungHT on 8/9/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "MySingleton.h"

@interface FriendCell : UITableViewCell
{
}
@property(nonatomic, strong) MySingleton *singleton;
@property (weak, nonatomic) IBOutlet UIButton *hbdBtn;
@property (weak, nonatomic) IBOutlet UILabel *lblDOB;

@property (weak, nonatomic) IBOutlet UIButton *facebookBtn;
@property (weak, nonatomic) IBOutlet UILabel *nameFriendLbl;
@property (weak, nonatomic) IBOutlet UIImageView *isSpecialImage;
@property (weak, nonatomic) IBOutlet UIView *viewGender;
@property (nonatomic,strong) IBOutlet UIButton *btnWishList;
- (IBAction)onbtnWishList:(id)sender;
@property (nonatomic, strong) AppDelegate *delegate;
@property (strong, nonatomic) IBOutlet UIImageView *imgZodiac;

@end
