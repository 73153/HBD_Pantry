//
//  SearchUserCell.h
//  HBD
//
//  Created by HoanVu on 12/18/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchUserCell : UITableViewCell
{}
@property (weak, nonatomic) IBOutlet UIImageView *avaImageView;
@property (weak, nonatomic) IBOutlet UILabel *userNameLbl;

@end
