//
//  AddFriendsCell.m
//  HBD
//
//  Created by Bhumesh on 15/04/16.
//  Copyright © 2016 HungHT. All rights reserved.
//

#import "AddFriendsCell.h"

@implementation AddFriendsCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)btnConnectTapped:(id)sender {
    UIButton *btn=sender;
    btn.selected=!btn.selected;
}
@end
