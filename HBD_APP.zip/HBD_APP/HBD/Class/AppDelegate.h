//
//  AppDelegate.h
//  HBD
//
//  Created by HungHT on 7/31/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//
#import <UIKit/UIKit.h>
#import "MMDrawerController.h"
#import "MainViewController.h"
#import "ShareDelegateController.h"
#import "MySingleton.h"
#import "User.h"
#import "Setting.h"
#import "Refresh.h"
#import "Supper.h"
#import "SocialLogin.h"
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>


@class  MainViewController;
//@interface AppDelegate : UIResponder <UIApplicationDelegate, UITabBarControllerDelegate,FBRequestDelegate>
@interface AppDelegate : UIResponder <UIApplicationDelegate, UITabBarControllerDelegate,CLLocationManagerDelegate>
{
    NSString *token;
    long countNTFNow;
}

#pragma mark - Core Data
@property (nonatomic, retain) CLLocationManager *locationManager;
@property (strong,nonatomic) SocialLogin *social;
@property (retain, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (retain, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (retain, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;
@property(nonatomic) BOOL isFromSettings;
@property(nonatomic) BOOL isToSettings;
@property BOOL isFirstTime;
@property(nonatomic) BOOL isNotificationByDefault;

- (NSURL *)applicationDocumentsDirectory;
#pragma mark - SaveToCoreDataWhenLoginComplete
- (void) saveToCoreData :(NSString *)idUser :(NSString *)email :(NSString *)firstName :(NSString *)lastName :(NSString *)myAva :(int)tagLoginFB;
#pragma mark - SaveDraftVideoToCoreData
- (void) saveDraftVideoToCoreData :(NSString *)urlDrafrVideo :(NSDictionary *)videoDict :(NSData *)frameData :(NSData *)filterData :(NSString *)nameFrameImage;
#pragma mark - Clear In Core Data - User Info
- (void) clearCoreData;
#pragma mark - /////
@property  BOOL wishlistFromFriendCell;
@property (strong, nonatomic) IBOutlet UIWindow *window;
@property (strong, nonatomic) IBOutlet UITabBarController *tabbarController;
@property (strong, nonatomic) NSDictionary *refererAppLink;
@property (strong, nonatomic) NSString *tokenDevice;
@property (strong, nonatomic) MMDrawerController * drawerController;
@property (strong, nonatomic) MainViewController * mainViewController;
@property (strong, nonatomic) ShareDelegateController * shareMethod;
@property(nonatomic, strong) MySingleton *singleton;
@property(nonatomic, strong) Supper *supper;
@property (strong, nonatomic) UILabel * badgeNtf;
@property (strong, nonatomic) NSUserDefaults *defaults;
@property (strong, nonatomic) NSMutableArray *aryUnseenItems;
@property (strong, nonatomic) NSMutableArray *aryUnseenItems1;
@property (strong, nonatomic) NSMutableArray *aryNotificationItems;
@property (strong, nonatomic) NSMutableArray *selectTagArray;
@property (strong, nonatomic) NSMutableArray *selectTagNameArray;

-(void)displayHIW ;
- (void) displayTos ;
-(void) setHomeRootController:(long)count;
- (void) activateSettings;
-(void) goLeft;
-(void) goRight;
- (void) activateAddFriend;
- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event;
- (void) touchStatusBar;
- (void) refreshCalendar;
#pragma mark - badgeNtf Update Frame
- (void) badgeNtfUpdateFrame :(int) y;
#pragma mark - Count Notifications
- (long) countNotification;
- (void) updateCountNotifications:(long) countNtf;
#pragma mark - Set MainView
- (void) setMainView;
- (void) setMainViewLoginFacebook;

#pragma mark - Get List Fried
- (void) GetListFriend;
- (void) changeAvatarMethod :(NSData *)_avaNewData;
- (NSArray *) getDataUserArray;
- (void) goToHomeScreen:(long)count;
-(void)resetNotificationCount;
-(void) goToWishList:(NSString *)tag ;
//-(void) goToSetting ;
-(void) goToProfile ;

@end
