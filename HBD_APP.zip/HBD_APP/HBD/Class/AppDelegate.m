 //
//  AppDelegate.m
//  HBD
//
//  Created by HungHT on 7/31/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import "AppDelegate.h"
#import <CoreData/CoreData.h>
#import "AFNetworking.h"
#import "MainViewController.h"
#import "DraftVideo.h"
#import "HomeViewController.h"
#import "CalendarViewController.h"
#import "NotificationViewController.h"
#import "LeftViewController.h"
#import "MMExampleDrawerVisualStateManager.h"
#import "RecordVideoViewController.h"
#import "MapViewController.h"
#import "UIViewController+MMDrawerController.h"
#import "ShoutOutSeCondController.h"
#import "ShoutOutFirstController.h"
#import "ShareVideoController.h"
#import "RightViewController.h"
#import "TosViewController.h"
#import "Commons.h"
#import "Social.h"
#import "Constants.h"
#import "selectUploadVideoOptionVC.h"
#import "SettingViewController.h"
#import "WishListVC.h"
#import "Constants.h"
#import "HowItWorksVC.h"
#import <FBSDKShareKit/FBSDKShareKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <AddressBook/AddressBook.h>
#import "RecordVideoViewController.h"
#import <MediaPlayer/MediaPlayer.h>


@implementation NSNull (IntValue)
-(int)intValue { return 0 ; }
@end

@implementation AppDelegate
{
    ABAddressBookRef addressBook;
    int badge_value;
    NSDictionary* jsonDict ;
    NSMutableDictionary *listNotificationDic;
    NSMutableArray *aryallfriends;
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    
    NSError *error1 = nil;
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:&error1];
    [[AVAudioSession sharedInstance] setActive:YES error:&error1];
    
    _isFirstTime = TRUE;
    CFErrorRef *error = NULL;
    addressBook = ABAddressBookCreateWithOptions(NULL,error );
    if (ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusNotDetermined) {
        ABAddressBookRequestAccessWithCompletion(addressBook, ^(bool granted, CFErrorRef error) {
            if (granted) {
               // First time access has been granted, add the contact
              //  [self _addContactToAddressBook];
             //[self.tableView reloadData];
            //  [self viewDidLoad];
            } else {
                // User denied access
                // Display an alert telling user the contact could not be added
            }
        });
    }
    self.locationManager = [[CLLocationManager alloc] init];
    self.locationManager.delegate = self;
    if(IS_OS_8_OR_LATER) {
        [self.locationManager requestWhenInUseAuthorization];
        [self.locationManager requestAlwaysAuthorization];
    }
     application.idleTimerDisabled = YES; 
    _badgeNtf.text = @" ";
        APPDATA.arrHBDUserList = [[NSMutableArray alloc] init];
//    tabBar.backgroundColor = [UIColor colorWithRed:83.0/255.0 green:147.0/255.0 blue:201.0/255.0 alpha:1];
//        [[UITabBar appearance] setBackgroundColor:[UIColor colorWithRed:83.0/255.0 green:147.0/255.0 blue:201.0/255.0 alpha:1]];
//    UIImage* tabBarBackground = [UIImage imageNamed:@"footer-bg"];
//    [[UITabBar appearance] setBackgroundImage:tabBarBackground];
    
    
   // [FBLoginView class];
  //  [FBSession class];
    if ([[UIApplication sharedApplication] respondsToSelector:@selector(registerUserNotificationSettings:)])
    {
        
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
        {
            [[UIApplication sharedApplication] registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeSound | UIUserNotificationTypeAlert | UIUserNotificationTypeBadge) categories:nil]];
            [[UIApplication sharedApplication] registerForRemoteNotifications];
        }
        else
        {
            [[UIApplication sharedApplication] registerForRemoteNotificationTypes:
             (UIUserNotificationTypeBadge | UIUserNotificationTypeSound | UIUserNotificationTypeAlert)];
            UIRemoteNotificationType types = [[UIApplication sharedApplication] enabledRemoteNotificationTypes];
        }

//        [[UIApplication sharedApplication] registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeSound | UIUserNotificationTypeAlert | UIUserNotificationTypeBadge) categories:nil]];
//        
    }
    else
    {
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:
         (UIUserNotificationTypeBadge | UIUserNotificationTypeSound | UIUserNotificationTypeAlert)];
    }
    
    
    
    _defaults = [NSUserDefaults standardUserDefaults];
    _managedObjectContext = [self managedObjectContext];
  //  NSLog(@"Bundel: %@",[[NSBundle mainBundle] bundleIdentifier]);
    _mainViewController = [[MainViewController alloc] init];
    _singleton = [MySingleton getInstance];
    _singleton.deviceToken = @"";
    _shareMethod = [[ShareDelegateController alloc] init];
    
    [self getSettingFromCoreData];
    NSArray *userArr = [self getDataUserArray];
    int countUserArr = (int)userArr.count;
    if (countUserArr == 0) {
        [self setMainView];
    }
    else if (countUserArr == 1) {
        NSLog(@"Go Home");
        if ([[userArr objectAtIndex:0] valueForKey:@"idUser"] || [[userArr objectAtIndex:0] valueForKey:@"idUser"] || [[userArr objectAtIndex:0] valueForKey:@"email"]) {
            _singleton.myToken = [[userArr objectAtIndex:0] valueForKey:@"token"];
            _singleton.myId = [[userArr objectAtIndex:0] valueForKey:@"idUser"];
            _singleton.myEmail = [[userArr objectAtIndex:0] valueForKey:@"email"];
            _singleton.firstName = UDDecode([[userArr objectAtIndex:0] valueForKey:@"firstName"]);
            _singleton.lastName = UDDecode([[userArr objectAtIndex:0] valueForKey:@"lastName"]);
            _singleton.myUsername = [NSString stringWithFormat:@"%@ %@",_singleton.firstName, _singleton.lastName];
            _singleton.myAvatar = [[userArr objectAtIndex:0] valueForKey:@"avatar"];
            [self GetListFriend];
            [self setHomeRootController:[self countNotification]];
        }else{
             [_defaults setBool:true forKey:@"agreeTos"];
            [self setMainView];
        }
            //[self setHomeRootController:_singleton.newResponseCount];
    }
    if (UDGetBool(ISFacebookLogin)) {
        if(_singleton.isFromRight) {
            // [FBSession openActiveSessionWithReadPermissions:@[@"email",@"public_profile",@"user_birthday",@"publish_actions",@"user_friends"] allowLoginUI:YES completionHandler:^(FBSession *session, FBSessionState status, NSError *error) {
            //     NSLog(@"session %@\n status %u",session,status);
            //  }];
        }
    }
  
    
 
 
 //   NSLog(@"IS REGISTERED: %d", [self pushNotificationOnOrOff]);
    return [[FBSDKApplicationDelegate sharedInstance] application:application
                                    didFinishLaunchingWithOptions:launchOptions];
}

- (BOOL) pushNotificationOnOrOff
{
    if ([UIApplication instancesRespondToSelector:@selector(isRegisteredForRemoteNotifications)]) {
        return ([[UIApplication sharedApplication] isRegisteredForRemoteNotifications]);
    } else {
        UIRemoteNotificationType types = [[UIApplication sharedApplication] enabledRemoteNotificationTypes];
        return (types & UIRemoteNotificationTypeAlert);
    }
 
}

#ifdef __IPHONE_8_0
- (void)application:(UIApplication *)application   didRegisterUserNotificationSettings:   (UIUserNotificationSettings *)notificationSettings
{
    //register to receive notifications
    [application registerForRemoteNotifications];
}

- (void)application:(UIApplication *)application handleActionWithIdentifier:(NSString   *)identifier forRemoteNotification:(NSDictionary *)userInfo completionHandler:(void(^)())completionHandler
{
    //handle the actions
    if ([identifier isEqualToString:@"declineAction"]){
    }
    else if ([identifier isEqualToString:@"answerAction"]){
    }
}
#endif
							
- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    [UIApplication sharedApplication].applicationIconBadgeNumber =[self countNotification];
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
   // [FBAppEvents activateApp];
    [FBSDKAppEvents activateApp];
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

#pragma mark - Facebook
- (BOOL)application:(UIApplication *)application
            openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication
         annotation:(id)annotation {
    //return [FBAppCall handleOpenURL:url sourceApplication:sourceApplication];
    return [[FBSDKApplicationDelegate sharedInstance] application:application
                                                          openURL:url sourceApplication:sourceApplication
                                                       annotation:annotation];
}

- (void) displayTos
{
    TosViewController *tosViewController = [[TosViewController alloc] init];
    self.window.rootViewController = tosViewController;
}

-(void)displayHIW
{
    IntroductionViewController *viewController = [[IntroductionViewController alloc] initWithNibName:@"IntroductionViewController" bundle:nil];
          self.window.rootViewController = viewController;
}

#pragma mark - setHomeRootController
-(void) setHomeRootController:(long)count
{
    if (![_defaults boolForKey:@"agreeTos"]) {
        [self displayTos];
    } else {
        [self goToHomeScreen:count];
    }
}

- (void) goToHomeScreen:(long)count
{
    _badgeNtf.text=@"";

  //  NSLog(@"setHomeRootController");
    HomeViewController *homeController = [[HomeViewController alloc] init];
    UINavigationController * navhomeController = [[UINavigationController alloc] initWithRootViewController:homeController];

    CalendarViewController *calenderViewController = [[CalendarViewController alloc] init];
    UINavigationController * navcalenderViewController = [[UINavigationController alloc] initWithRootViewController:calenderViewController];

    ProfileViewController *profileViewController = [[ProfileViewController alloc] init];
    UINavigationController * navprofileViewController = [[UINavigationController alloc] initWithRootViewController:profileViewController];
    
    
    NotificationViewController *notificationViewController = [[NotificationViewController alloc] init];
    UINavigationController * navnotificationViewController = [[UINavigationController alloc] initWithRootViewController:notificationViewController];

   // selectUploadVideoOptionVC *objselectUploadVideoOptionVC=[[selectUploadVideoOptionVC alloc]init];
    WishListVC *wishListController = [[WishListVC alloc] init];
    UINavigationController * navwishListController = [[UINavigationController alloc] initWithRootViewController:wishListController];

//    SettingViewController *settingController = [[SettingViewController alloc] init];
//    UINavigationController * navsettingController = [[UINavigationController alloc] initWithRootViewController:settingController];

    

    homeController.tabBarItem.tag = 1;
    navhomeController.tabBarItem.tag = 1 ;
    profileViewController.tabBarItem.tag = 2;
    navprofileViewController.tabBarItem.tag =2 ;
   //  objselectUploadVideoOptionVC.tabBarItem.tag = 2;
    navnotificationViewController.tabBarItem.tag =3 ;
    notificationViewController.tabBarItem.tag = 3;
   // objselectUploadVideoOptionVC.tabBarItem.tag=3;
    wishListController.tabBarItem.tag = 4;
    navwishListController.tabBarItem.tag = 4;
   // settingController.tabBarItem.tag = 6;

    [homeController setType: 1];
    _tabbarController.viewControllers = @[navhomeController, navcalenderViewController, navprofileViewController , navnotificationViewController, navwishListController];
//    _tabbarController.viewControllers = @[homeController, calenderViewController, objselectUploadVideoOptionVC , notificationViewController, myFeedController];
    _tabbarController.delegate = self;
    LeftViewController *leftViewController = [[LeftViewController alloc] init];

    RightViewController *rightViewController = [[RightViewController alloc] init];
    self.drawerController = [[MMDrawerController alloc]
                             initWithCenterViewController:_tabbarController
                             leftDrawerViewController:leftViewController
                             rightDrawerViewController:rightViewController];
    //[self.drawerController setMaximumRightDrawerWidth:[[UIScreen mainScreen] bounds].size.width ];
    [self.drawerController setOpenDrawerGestureModeMask:MMOpenDrawerGestureModeAll];
    [self.drawerController setCloseDrawerGestureModeMask:MMCloseDrawerGestureModeAll];
    [self.drawerController
     setDrawerVisualStateBlock:^(MMDrawerController *drawerController, MMDrawerSide drawerSide, CGFloat percentVisible) {
         MMDrawerControllerDrawerVisualStateBlock block;
         block = [[MMExampleDrawerVisualStateManager sharedManager]
                  drawerVisualStateBlockForDrawerSide:drawerSide];
         if(block){
             block(drawerController, drawerSide, percentVisible);
         }
     }];
    UITabBar *tabBar =_tabbarController.tabBar;

    
    UITabBarItem *item0 = [tabBar.items objectAtIndex:0];
    UITabBarItem *item1 = [tabBar.items objectAtIndex:1];
    UITabBarItem *item2 = [tabBar.items objectAtIndex:2];
    UITabBarItem *item3 = [tabBar.items objectAtIndex:3];
    UITabBarItem *item4 = [tabBar.items objectAtIndex:4];
    item0.selectedImage = [[UIImage imageNamed:@"home-selected"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal ];
    item0.image = [[UIImage imageNamed:@"footer-home-icon.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal ];
    
    item1.selectedImage = [[UIImage imageNamed:@"cal-selected"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal ];
    item1.image = [[UIImage imageNamed:@"footer-calendar-icon.png"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal ];
    
    item2.selectedImage = [[UIImage imageNamed:@"video-selected"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal ];
    item2.image = [[UIImage imageNamed:@"footer-recoder-icon.png"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal ];
    
    item3.selectedImage = [[UIImage imageNamed:@"chat-selected"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal ];
    item3.image = [[UIImage imageNamed:@"footer-notification-icon"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal ];
    
    item4.selectedImage = [[UIImage imageNamed:@"gift-selected"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal ];
    item4.image = [[UIImage imageNamed:@"footer-wishlist-icon.png"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal ];
    
    tabBar.barStyle = UIBarStyleBlackOpaque;
  //  [[UITabBar appearance] setBackgroundImage:[[UIImage alloc] init]];
   // [[UITabBar appearance] setShadowImage:[[UIImage alloc] init]];
    _badgeNtf =[[UILabel alloc]init];
    if (count>0) {
        [self updateCountNotifications:count];
    }
//    [[self.tabbarController.tabBar.items objectAtIndex:3] setTitle:NSLocalizedString(@"LabelInfo", @"comment")];

    _badgeNtf.textAlignment=NSTextAlignmentCenter;
    _badgeNtf.font=[UIFont fontWithName:@"" size:4];
    
    if (IS_IPHONE_4 || IS_IPHONE_5 ) {
        _badgeNtf.frame=CGRectMake(210, 7, 30, 20);
    }
    
    else if ( IS_IPHONE_6)
    {
        _badgeNtf.frame=CGRectMake(248, 7, 30, 20);

    }
    
    else if (IS_IPHONE_6_PLUS)
    {
     _badgeNtf.frame=CGRectMake(274, 7, 30, 20);

    }
    else
    {
    _badgeNtf.frame=CGRectMake(300, 7, 30, 20);

    }
  
     _badgeNtf.layer.cornerRadius=10;
    _badgeNtf.textColor=[UIColor whiteColor];
    
    [_tabbarController.tabBar addSubview:_badgeNtf];
    
   // [self.drawerController setMaximumRightDrawerWidth:250];
    [self.window setRootViewController:self.drawerController];
    _tabbarController.selectedIndex = 0;
    UIImage *tabbarbackground = [UIImage imageNamed:@"footer-bg"];
    [[UITabBar appearance] setBackgroundImage:tabbarbackground];
    [_tabbarController.tabBar setBackgroundImage:tabbarbackground];
}


#pragma mark - Set MainView
- (void) setMainView
{
    _mainViewController = [[MainViewController alloc] init];
    self.window.rootViewController = _mainViewController;
}

#pragma mark - Set MainView
- (void) setMainViewLoginFacebook
{
if (_singleton.isFromRight) {
        [_mainViewController startLoginFacebook];
    }
    else {
    _mainViewController = [[MainViewController alloc] init];
    self.window.rootViewController = _mainViewController;
    [_mainViewController startLoginFacebook];
    }
}

- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [super touchesBegan:touches withEvent:event];
    CGPoint location = [[[event allTouches] anyObject] locationInView:[self window]];
    if(location.y > 0 && location.y < 20) {
        [self touchStatusBar];
    }
}

- (void) touchStatusBar
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"touchStatusBarClick" object:nil];
}

#pragma mark - Count Notifications
- (long) countNotification
{
    //_isNotificationByDefault = YES ;
    long countSeen = 0;
    //     jsonDict = [Commons getRequest:[NSString stringWithFormat:@"%@/notifications?limit=%i&offset=%i&token=%@",SERVER,1000000,0,_singleton.myToken]];
    jsonDict = [Commons getRequest:[NSString stringWithFormat:@"%@/countseen?token=%@",SERVER,_singleton.myToken]];
            if (![jsonDict isEqual:[NSNull null]]) {
        if ([[jsonDict objectForKey:@"status_code"] intValue] == 1) {
            
            if ([jsonDict objectForKey:@"data"]) {
                 countSeen = [[jsonDict objectForKey:@"data"] intValue];
            }
//            NSArray *dataArr = [jsonDict objectForKey:@"data"];
//            for (long i = 0; i < dataArr.count; i ++) {
//                if ([[[dataArr objectAtIndex:i] valueForKey:@"isSeen"] intValue] == 0) {
//                    countSeen++;
//                }
//            }
        }
    }
    return countSeen;
}

#pragma mark - Get Count of Notification not review
- (void) updateCountNotifications:(long) countNtf
{
    countNTFNow = countNtf;
    [self performSelector:@selector(updateNTF) withObject:_badgeNtf afterDelay:0];
 }

-(void) updateNTF{
    dispatch_async(dispatch_get_main_queue(), ^{
        _badgeNtf.text = @" ";
        if (countNTFNow > 0)
        {
            _badgeNtf.text = [NSString stringWithFormat:@"%ld",countNTFNow];
 //           NSLog(@"%f",_badgeNtf.font.pointSize);
            if (_badgeNtf.text.length>2) {
                _badgeNtf.font=[UIFont fontWithName:_badgeNtf.font.fontName size:_badgeNtf.font.pointSize-4];
            }
            
        }
    });
    //_isNotificationByDefault = NO;
}

#pragma mark - Get List Fried
- (void) GetListFriend
{
    _singleton.listHbdFriend = [Social getFriendList:10000 withOffset:0 byName:YES];
}

- (void) activateSettings {
    [(LeftViewController *)self.drawerController.leftDrawerViewController displaySettings];
    [self.drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}

- (void) activateAddFriend {
    [(RightViewController *)self.drawerController.rightDrawerViewController displayAddFriend];
    [self.drawerController toggleDrawerSide:MMDrawerSideRight animated:YES completion:nil];
}

#pragma mark - Go left , right View
-(void) goLeft
{
    [self.drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}

-(void) goRight
{
    [self.drawerController toggleDrawerSide:MMDrawerSideRight animated:YES completion:nil];
}


-(void) goToWishList:(NSString *)tag
{
//    _singleton.isFromFriendCell = YES;
    //_singleton.friendId = tag ;
    self.tabbarController.selectedIndex =3;
    WishListVC *wishListController = [[WishListVC alloc] init];
    UINavigationController * navwishListController = [[UINavigationController alloc] initWithRootViewController:wishListController];
    wishListController.tabBarItem.tag = 4;
    navwishListController.tabBarItem.tag = 4 ;
    self.tabbarController.selectedIndex = 4;
    [self tabBarController:self.tabbarController didSelectViewController:navwishListController];
}


-(void) goToProfile
{
    self.tabbarController.selectedIndex =3;
    ProfileViewController *profileViewController = [[ProfileViewController alloc] init];
    UINavigationController * navprofileViewController = [[UINavigationController alloc] initWithRootViewController:profileViewController];
    profileViewController.tabBarItem.tag = 2;
            navprofileViewController.tabBarItem.tag = 2 ;
    self.tabbarController.selectedIndex = 2;
    [self tabBarController:self.tabbarController didSelectViewController:navprofileViewController];
 }


//-(void) goToSetting
//{
//    _singleton.selectShouted = 0;
//    _singleton.selectDrafts = 0;
//    _singleton.selectWishList = 1;
//    _singleton.tagRecordVideo = 0;
//    _tabbarController.selectedIndex = 6;
//    
//    //    UIViewController *controller=[[_delegate.tabBarController viewControllers]lastObject];
//    
//    
//    SettingViewController *objSettingViewController = [[SettingViewController alloc] initWithNibName:@"SettingViewController" bundle:[NSBundle mainBundle]];
//    UINavigationController *navcon = (UINavigationController*)_tabbarController.selectedViewController;
//    navcon.tabBarItem.tag = 6 ;
//    navcon.navigationBarHidden = YES ;
//    [navcon pushViewController:objSettingViewController animated:false];
//}

- (void) refreshCalendar
{
    if ([self.tabbarController.selectedViewController isKindOfClass:[CalendarViewController class]]) {
        [(CalendarViewController *)self.tabbarController.selectedViewController refreshCalendarScreen];
    }
}

#pragma mark - tabBarController Delegate - Push Record Video View
- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController
{
    //Zaptech Solutions
    [_badgeNtf setTextColor:[UIColor whiteColor]];
    if (viewController.tabBarItem.tag == 3)
    {
        long countSeen = [self countNotification] ;
        [self updateCountNotifications:countSeen];
        [_badgeNtf setNeedsDisplay];
    }else
    {
        [self resetNotificationCount1];
    }
   
//         countNTFNow = [self countNotification];
//            _badgeNtf.text = @" ";
//            if (countNTFNow > 0) {
//                _badgeNtf.text = [NSString stringWithFormat:@"%ld",countNTFNow];
//            }

    if(_singleton.changedAvatar == YES && viewController.tabBarItem.tag == 1) {
        _singleton.isFromFriendCell=NO;
//        [(HomeViewController *)[[tabBarController viewControllers] objectAtIndex:0] reloadVideos];
//        //[(HomeViewController *)[[tabBarController viewControllers] objectAtIndex:4] reloadVideos];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"realoadVideo" object:self];
        _singleton.changedAvatar = NO;
    }
    if (viewController.tabBarItem.tag == 2)
    {
   
        _singleton.isForRecord=YES;
        _singleton.tagRecordVideo=1;
       _singleton.isFromFriendCell=NO;
      
    
//         [[NSNotificationCenter defaultCenter] postNotificationName:@"checkToOpenProfileOrRecord" object:self];
       // isRecordScreen = YES ;
        //        _viewWhite.hidden=NO;
        //        selectUploadVideoOptionVC *objselectUploadVideoOptionVC = [[selectUploadVideoOptionVC alloc] init];
        //        [self presentViewController:objselectUploadVideoOptionVC animated:NO completion:^{
        //            tagRecordVideo = 0;
        //        }]; 
        
    
//    UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:[[ProfileViewController alloc] initWithNibName:@"ProfileViewController" bundle:nil]];
//        [self.window makeKeyAndVisible];
//        self.window.rootViewController =navigation;
//    _tabbarController.selectedIndex = 3;
        _tabbarController.selectedIndex = 2;
    }
    if (viewController.tabBarItem.tag == 3)
    {
        _singleton.isFromFriendCell=NO;
        _singleton.tagSetting = 0;
        _singleton.isFromtabNotification=YES;
//      _singleton.newResponseCount=0;
//      NSUserDefaults *userDeafults=[NSUserDefaults standardUserDefaults];
//        [userDeafults setBool:YES forKey:@"isView"];
//      [self badgeNtfUpdateFrame:7];
        [_badgeNtf setTextColor:[UIColor blackColor]];
    }
    if(viewController.tabBarItem.tag == 5)
    {
//        viewController.tabBarItem.tag = 4;
//        WishListVC *objWishListVC = [[WishListVC alloc] initWithNibName:@"WishListVC" bundle:[NSBundle mainBundle]];
//        UINavigationController *navcon = (UINavigationController*)viewController.tabBarController.selectedViewController;
//        [navcon pushViewController:objWishListVC animated:false];
    }
    if (viewController.tabBarItem.tag == 4)
    {
        
//        HowItWorksVC *objHowItWorksVC = [[HowItWorksVC alloc] initWithNibName:@"HowItWorksVC" bundle:[NSBundle mainBundle]];
//           UINavigationController *navHowItWorksVC =[[UINavigationController alloc] initWithRootViewController:objHowItWorksVC];
//        if (viewController == navHowItWorksVC) {
//            NSLog(@"sdfgdsfgsdfg");
//        }
        
        
//        //        _singleton.newResponseCount=0;
//        //        NSUserDefaults *userDeafults=[NSUserDefaults standardUserDefaults];
//        //        [userDeafults setBool:YES forKey:@"isView"];
//        [self badgeNtfUpdateFrame:7];
//        [_badgeNtf setTextColor:[UIColor blackColor]];
        //_delegate.tabbarController.selectedIndex = 4;
    }
    else{
        //[self badgeNtfUpdateFrame:10];
        [_badgeNtf setTextColor:[UIColor whiteColor]];
    }
    static UIViewController *previousController = nil;
    if (previousController == viewController)
    { // the same tab was tapped a second time
        if(viewController.tabBarItem.tag == 1)
        {
            _singleton.isFromFriendCell=NO;
            [[NSNotificationCenter defaultCenter] postNotificationName:@"ScrollToTop" object:self];
          //  [(HomeViewController *)viewController statusBarHit];
        }
        //else if (viewController.tabBarItem.tag == 5)
           // [(WishMainVC *)viewController statusBarHit];
        if (viewController.tabBarItem.tag == 2)
        {
            _singleton.isFromFriendCell=NO;
            [viewController viewWillAppear:YES];
        }   
    }
    previousController = viewController;
      
}


#pragma mark - badgeNtf Update Frame
- (void) badgeNtfUpdateFrame :(int) y
{
    _badgeNtf.frame = CGRectMake(215, y, 25, 20);
}

#pragma mark - Remote Notifications
- (void)application:(UIApplication *)app didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    
    self.tokenDevice = [[[[deviceToken description]
                          stringByReplacingOccurrencesOfString: @"<" withString: @""]
                         stringByReplacingOccurrencesOfString: @">" withString: @""]
                        stringByReplacingOccurrencesOfString: @" " withString: @""];
    NSLog(@"My device token is: %@", self.tokenDevice);
    if (self.tokenDevice != nil) {
        _singleton.deviceToken = self.tokenDevice;
    }
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:self.tokenDevice forKey:@"tokenDevice"];
    [defaults synchronize];
}

- (void)application:(UIApplication *)app didFailToRegisterForRemoteNotificationsWithError:(NSError *)err {
    
    NSString *str = [NSString stringWithFormat: @"Error: %@", err];
  //  NSLog(@"%@",str);
 //   NSLog(@"Error Error Error Error.....");
}

#pragma mark - Receive notification
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
    //[UIApplication sharedApplication].applicationIconBadgeNumber =[self countNotification];
    NSLog(@"userinfo %@",[userInfo objectForKey:@"badge"]);
    listNotificationDic = [[NSMutableDictionary alloc]init];
    UIApplicationState state = [UIApplication sharedApplication].applicationState;
    if (state == UIApplicationStateActive)
    {
//        if (!_isNotificationByDefault)
//        {
            listNotificationDic =[NSMutableDictionary dictionaryWithDictionary:userInfo] ;
            NSString *alertMsg=UDDecode([[userInfo objectForKey:@"aps"] valueForKey:@"alert"]);
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"HBD" message:alertMsg delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Ok", nil];
            alert.tag = 5 ;
            [alert show];
      //  }
  //      NSLog(@"userInfo:%@",userInfo);
    }else
    {
  //    NSLog(@"userInfo:%@",userInfo);
        listNotificationDic =[NSMutableDictionary dictionaryWithDictionary:userInfo] ;
         NSString *typeNTF =[[[userInfo objectForKey:@"key"] objectForKey:@"data"] valueForKey:@"type"];
 //       NSLog(@"typeNTF:%@",typeNTF);
        
        if([typeNTF isEqualToString:@"purchase"])
        {
            NSDictionary *userInfo1=[[NSMutableDictionary alloc]init];
           userInfo1 = [Social findFriendFromEmail:[[[[userInfo objectForKey:@"key"] objectForKey:@"data"] objectForKey:@"from"] valueForKey:@"email"]];
            if (userInfo1)
            {
                  _singleton.isFromFriendCell = YES;
                NSInteger frndId = [[[userInfo1 objectForKey:@"data"] valueForKey:@"referToUserId"] integerValue];
                  _singleton.friendId = frndId ;
            }else
            {
              [self goToWishList:@""];
            }
    //        NSLog(@"userInfo1:%@",userInfo1);
        }if([typeNTF isEqualToString:@"sendVideo"] || [typeNTF isEqualToString:@"likeVideo"])
        {
            _singleton.isFromPushNotification = YES ;
            NSArray *subArr =[[userInfo objectForKey:@"key"] objectForKey:@"data"];
            PreviewVideoController *previewVideoController = [[PreviewVideoController alloc] init];
            previewVideoController.video = [Commons setNotifVideoData:subArr];
             self.window.rootViewController = previewVideoController;
        }
        if ([typeNTF isEqualToString:@"friendRequest"])
        {
            NSDictionary *userInfo1=[[NSMutableDictionary alloc]init];
            userInfo1 =  [Commons getRequest:[NSString stringWithFormat:@"%@/users/%@?token=%@",SERVER,[[[[userInfo objectForKey:@"key"] objectForKey:@"data"] objectForKey:@"from"] valueForKey:@"id"],_singleton.myToken]];
            if(userInfo1)
            {
            [Social viewProfileWithArray:[userInfo1 objectForKey:@"data"] controller:self.window.rootViewController withDelegate:NO];
            }
        }
          if ([typeNTF isEqualToString:@"birthdateAlert"])
        {
           [self goToProfile] ;
        }if ([typeNTF isEqualToString:@"birthdateAlert"]) {
            self.tabbarController.selectedIndex =3;
            WishListVC *wishListController = [[WishListVC alloc] init];
            UINavigationController * navwishListController = [[UINavigationController alloc] initWithRootViewController:wishListController];
            wishListController.tabBarItem.tag = 4;
            navwishListController.tabBarItem.tag = 4 ;
            self.tabbarController.selectedIndex = 4;
            [self tabBarController:self.tabbarController didSelectViewController:navwishListController];
        }
        if ([typeNTF isEqualToString:@"commentVideo"]) {
            NSString *videoId =[NSString stringWithFormat:@"%@",[[[[listNotificationDic objectForKey:@"key"] objectForKey:@"data"] objectForKey:@"object"] valueForKey:@"id"]];
            _singleton.isFromNotiCommentTag=YES ;
            _singleton.strCommentTagVideoId =videoId ;

            HomeViewController *homeview = [[HomeViewController alloc] init];
            homeview.delegate = self ;
            homeview.tabBarItem.tag = 1;
            self.tabbarController.selectedIndex = 3;
            UINavigationController * navController = [[UINavigationController alloc] initWithRootViewController:homeview];
            homeview.tabBarItem.tag = 0;
            navController.tabBarItem.tag = 0 ;
            self.tabbarController.selectedIndex = 0;
            [self tabBarController:self.tabbarController didSelectViewController:navController];
        }

//        if ([typeNTF isEqualToString:@"video"] || [typeNTF isEqualToString:@"tag"] || [typeNTF isEqualToString:@"like"] || [typeNTF isEqualToString:@"comment"])
//        {
//            
//            NSArray *subArr =[[[userInfo objectForKey:@"key"] objectForKey:@"data"]valueForKey:@"object"];
//            
//            PreviewVideoController *previewVideoController = [[PreviewVideoController alloc] init];
//            
//            previewVideoController.video = [Commons setVideoData:subArr];
//            
//            
//     //       [self presentViewController:previewVideoController animated:YES completion:nil];
//            
//        }
//        
//        if ([typeNTF isEqualToString:@"wishlist"]) {
//            
//     //       NSArray *subArr = [_listNotification objectAtIndex:indexBtn];
//            
//            NSString *urlStrItem = [[userInfo valueForKey:@"wishlist"] valueForKey:@"vendorUrl"];
//            
//            urlStrItem = [urlStrItem stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
//            
//            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlStrItem]];
//            
//        }
    }
    
    
  //  NSLog(@"userInfo:%@",userInfo);
    
   // badge_value+=[[[userInfo objectForKey:@"aps"] objectForKey:@"badge"]intValue];
 //   NSLog(@"Totoal badge Value:%d",badge_value);
    
    for (id key in userInfo) {
  //      NSLog(@"key: %@, value: %@", key, [userInfo objectForKey:key]);
  
 //   [UIApplication sharedApplication].applicationIconBadgeNumber = badge_value;
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"notification" object:nil userInfo:userInfo];
    }
}

#pragma mark - Core Data stack
- (NSManagedObjectContext *)managedObjectContext
{
    if (_managedObjectContext != nil) {
        return _managedObjectContext;
    }
    NSPersistentStoreCoordinator *coordinator = [self persistentStoreCoordinator];
    if (coordinator != nil) {
        _managedObjectContext = [[NSManagedObjectContext alloc] init];
        [_managedObjectContext setPersistentStoreCoordinator:coordinator];
    }
    return _managedObjectContext;
}

- (NSManagedObjectModel *)managedObjectModel
{
    if (_managedObjectModel != nil) {
        return _managedObjectModel;
    }
    NSURL *modelURL = [[NSBundle mainBundle] URLForResource:@"Data" withExtension:@"momd"];
    _managedObjectModel = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    return _managedObjectModel;
}

- (NSPersistentStoreCoordinator *)persistentStoreCoordinator
{
    if (_persistentStoreCoordinator != nil) {
        return _persistentStoreCoordinator;
    }
    NSURL *storeURL = [[self applicationDocumentsDirectory] URLByAppendingPathComponent:@"SampleCoredata.sqlite"];
    NSError *error = nil;
    _persistentStoreCoordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:[self managedObjectModel]];
    if (![_persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:nil error:&error]) {
   //     NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        abort();
    }
    return _persistentStoreCoordinator;
}

#pragma mark - Application's Documents directory
- (NSURL *)applicationDocumentsDirectory
{
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
}

#pragma matk - Get Info of user from core data
- (NSArray *) getDataUserArray
{
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    [request setEntity:[NSEntityDescription entityForName:@"User" inManagedObjectContext:_managedObjectContext]];
    NSError *error;
    NSArray *events = [_managedObjectContext executeFetchRequest:request error:&error];
//    NSLog(@"%@",events);
    return events;
}

#pragma mark - Change Avatar When SignUpFacebook
- (void) changeAvatarMethod :(NSData *)_avaNewData
{
    NSString *urlStr =  [NSString stringWithFormat:@"%@/users/avatar?token=%@",SERVER,_singleton.myToken];
    AFHTTPRequestOperationManager *manager = [Commons getManager];
    [manager POST:urlStr
       parameters:nil
    constructingBodyWithBlock:^(id<AFMultipartFormData> formData){
        [formData appendPartWithFileData:_avaNewData name:@"avatar" fileName:@"avatar.jpg" mimeType:@"image"];
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
  //      NSLog(@"OK");
 //       NSLog(@"responseObject change Ava: %@",responseObject);
        _singleton.changedAvatar = YES;
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
 //       NSLog(@"Error: %@", error);
    }];
}

#pragma mark - SaveToCoreDataWhenLoginComplete And Affter change Profile
- (void) saveToCoreData :(NSString *)idUser :(NSString *)email :(NSString *)firstName :(NSString *)lastName :(NSString *)myAva :(int)tagLoginFB
{
    [self clearCoreData];
    User *userInfo;
    userInfo = [NSEntityDescription insertNewObjectForEntityForName:@"User" inManagedObjectContext:_managedObjectContext];
    userInfo.token = _singleton.myToken;
    if (idUser != nil) {
        userInfo.idUser = [NSString stringWithFormat:@"%@",idUser];
    }
    if (email != nil) {
       userInfo.email = email;
    }
    if (firstName != nil) {
       userInfo.firstName = firstName;
    }
    if (lastName != nil) {
        userInfo.lastName = lastName;
    }
    if (myAva != nil) {
       userInfo.avatar = [NSString stringWithFormat:@"%@",myAva];
}
    userInfo.tagLoginFb = tagLoginFB;
    NSError *error;
    if (![_managedObjectContext save:&error]) {
 //       NSLog(@"Error");
    }else
    {
//        NSLog(@"Save Complete");
    }
}

#pragma mark - Clear User In Core Data - User Info
- (void) clearCoreData
{
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:@"User"];
    [fetchRequest setIncludesPropertyValues:NO]; //only fetch the managedObjectID
    NSError *error;
    NSArray *fetchedObjects = [_managedObjectContext executeFetchRequest:fetchRequest error:&error];
    for (NSManagedObject *object in fetchedObjects)
    {
        [_managedObjectContext deleteObject:object];
    }
    error = nil;
    [_managedObjectContext save:&error];
}

#pragma mark - SaveDraftVideoToCoreData
- (void) saveDraftVideoToCoreData :(NSString *)urlDrafrVideo :(NSDictionary *)videoDict :(NSData *)frameData :(NSData *)filterData :(NSString *)nameFrameImage
{
     DraftVideo *draftInfo;
     draftInfo = [NSEntityDescription insertNewObjectForEntityForName:@"DraftVideo" inManagedObjectContext:_managedObjectContext];
     draftInfo.urlVideo = urlDrafrVideo;
     draftInfo.dataVideo = videoDict;
     draftInfo.filterImage = filterData;
     draftInfo.frameImage = frameData;
     draftInfo.nameFrameImage = nameFrameImage;
}

#pragma mark - Get Setting From Core Data
- (void) getSettingFromCoreData
{
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    [request setEntity:[NSEntityDescription entityForName:@"Setting" inManagedObjectContext:_managedObjectContext]];
    NSError *error;
    NSArray *settingArr = [_managedObjectContext executeFetchRequest:request error:&error];
 //   NSLog(@"events.count = %ld",(unsigned long)settingArr.count);
//    NSLog(@"settingArr = %@",settingArr);
}

#pragma mark - Reset notification count

-(void)resetNotificationCount{
    for (int i =0;i<_aryUnseenItems.count;i++) {
           NSString * idNotificationCurrent = [_aryUnseenItems objectAtIndex:i];
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
                @synchronized(self) {
                    [self changeSeenNotification:idNotificationCurrent];
                }
            });
        }
}
    
-(void)resetNotificationCount1
{
    if(_aryUnseenItems1.count > 0)
    {
        for (int i =0;i<_aryUnseenItems1.count;i++) {
            NSString * idNotificationCurrent = [_aryUnseenItems1 objectAtIndex:i];
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
                @synchronized(self) {
                    [self changeSeenNotification:idNotificationCurrent];
                      dispatch_async(dispatch_get_main_queue(), ^{
                        long countSeen = [self countNotification];
                        [self updateCountNotifications:countSeen];
                        [_badgeNtf setNeedsDisplay];
                          });
                }
            });
        }
    }else
    {
        long countSeen = [self countNotification];
        [self updateCountNotifications:countSeen];
        [_badgeNtf setNeedsDisplay];
    }
    [_aryUnseenItems1 removeAllObjects];
}

-(void) changeSeenNotification:(NSString *) idNFT
{
    NSString *urlStr =  [NSString stringWithFormat:@"%@/notifications/%@/seen?token=%@",SERVER,idNFT,_singleton.myToken];
    NSArray *paramsTitle = @[@"id"];
    NSArray *paramsValue = @[idNFT];
    [Commons postRequest:urlStr paramsTitle:paramsTitle paramsValue:paramsValue];
}

#pragma mark - UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 5) {
        if (buttonIndex == 1) {
            
            NSString *typeNTF =[[[listNotificationDic objectForKey:@"key"] objectForKey:@"data"] valueForKey:@"type"];
      //      NSLog(@"typeNTF:%@",typeNTF);
            
            if([typeNTF isEqualToString:@"purchase"])
            {
                NSDictionary *userInfo1=[[NSMutableDictionary alloc]init];
                userInfo1 = [Social findFriendFromEmail:[[[[listNotificationDic objectForKey:@"key"] objectForKey:@"data"] objectForKey:@"from"] valueForKey:@"email"]];
                if (userInfo1) {
                    _singleton.isFromFriendCell = YES;
                    NSInteger frndId = [[[userInfo1 objectForKey:@"data"] valueForKey:@"referToUserId"] integerValue];
                    _singleton.friendId = frndId ;
                }else
                {
                    [self goToWishList:@""];
                }
      //          NSLog(@"userInfo1:%@",userInfo1);
            }if([typeNTF isEqualToString:@"sendVideo"]|| [typeNTF isEqualToString:@"likeVideo"])
            {
                _singleton.isFromPushNotification = YES ;
                NSArray *subArr =[[listNotificationDic objectForKey:@"key"] objectForKey:@"data"];
                
                PreviewVideoController *previewVideoController = [[PreviewVideoController alloc] init];
                previewVideoController.video = [Commons setNotifVideoData:subArr];
                self.window.rootViewController = previewVideoController;
            }
            if ([typeNTF isEqualToString:@"friendRequest"])
            {
                 NSDictionary *userInfo1=[[NSMutableDictionary alloc]init];
              userInfo1 =  [Commons getRequest:[NSString stringWithFormat:@"%@/users/%@?token=%@",SERVER,[[[[listNotificationDic objectForKey:@"key"] objectForKey:@"data"] objectForKey:@"from"] valueForKey:@"id"],_singleton.myToken]];
                
                NSMutableDictionary *dic=[[NSMutableDictionary alloc]init];
                [dic setObject:@"" forKey:@"avatar"];
                [dic setObject:[APPDATA isNullOrEmpty:[[[[listNotificationDic objectForKey:@"key"] objectForKey:@"data"] objectForKey:@"from"] valueForKey:@"email"]] forKey:@"email"];
                [dic setObject:@"" forKey:@"facebookId"];
                [dic setObject:[APPDATA isNullOrEmpty:UDDecode([[[[listNotificationDic objectForKey:@"key"] objectForKey:@"data"] objectForKey:@"from"] valueForKey:@"firstName"])] forKey:@"firstName"];
                [dic setObject:[[[[listNotificationDic objectForKey:@"key"] objectForKey:@"data"] objectForKey:@"from"] valueForKey:@"id"] forKey:@"id"];
                [dic setObject:[APPDATA isNullOrEmpty:UDDecode([[[[listNotificationDic objectForKey:@"key"] objectForKey:@"data"] objectForKey:@"from"] valueForKey:@"lastName"])] forKey:@"lastName"];
                
                
                [dic setObject:[[[[listNotificationDic objectForKey:@"key"] objectForKey:@"data"] objectForKey:@"object"] valueForKey:@"createdAt"] forKey:@"createdAt"];
                [dic setObject:[[[[listNotificationDic objectForKey:@"key"] objectForKey:@"data"] objectForKey:@"object"] valueForKey:@"id"] forKey:@"id"];
                [dic setObject:@"1" forKey:@"isSeen"];
                [dic setObject:[[[[listNotificationDic objectForKey:@"key"] objectForKey:@"data"] objectForKey:@"object"] valueForKey:@"id"] forKey:@"itemId"];
                [dic setObject:[[[[listNotificationDic objectForKey:@"key"] objectForKey:@"data"] objectForKey:@"object"] valueForKey:@"requestTo"] forKey:@"ownerId"];
                [dic setObject:[[[[listNotificationDic objectForKey:@"key"] objectForKey:@"data"] objectForKey:@"object"] valueForKey:@"status"] forKey:@"status"];
                [dic setObject:@"friend-req" forKey:@"type"];
                [dic setObject:[[[[listNotificationDic objectForKey:@"key"] objectForKey:@"data"] objectForKey:@"object"] valueForKey:@"updatedAt"] forKey:@"updatedAt"];
                [dic setObject:dic forKey:@"user"];
                [dic setObject:[[[[listNotificationDic objectForKey:@"key"] objectForKey:@"data"] objectForKey:@"object"] valueForKey:@"requestFrom"] forKey:@"userId"];
                             
                if (userInfo1 != nil)
                {
                    [Social viewProfileWithArray:[userInfo1 objectForKey:@"data"] controller:self.window.rootViewController withDelegate:NO];
                }
                else
                {
                    [Social viewProfileWithArrayNotify:dic controller:self.window.rootViewController withDelegate:NO];
                }
            } if ([typeNTF isEqualToString:@"birthdateAlert"]) {
                [self goToProfile] ;
            }if([typeNTF isEqualToString:@"commentVideo"])
            {
                NSString *videoId =[NSString stringWithFormat:@"%@",[[[[listNotificationDic objectForKey:@"key"] objectForKey:@"data"] objectForKey:@"object"] valueForKey:@"id"]];
                _singleton.isFromNotiCommentTag=YES ;
                _singleton.strCommentTagVideoId =videoId ;

                HomeViewController *homeview = [[HomeViewController alloc] init];
                homeview.delegate = self ;
                _singleton.strCommentTagVideoId =videoId ;
                 self.tabbarController.selectedIndex =1;
                UINavigationController * navController = [[UINavigationController alloc] initWithRootViewController:homeview];
            homeview.tabBarItem.tag = 0;
                navController.tabBarItem.tag = 0 ;
                self.tabbarController.selectedIndex = 0;
                [self tabBarController:self.tabbarController didSelectViewController:navController];
            }

        }
    }
}
@end
