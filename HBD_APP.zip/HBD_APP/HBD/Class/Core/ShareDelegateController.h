//
//  ShareDelegateController.h
//  HBD
//
//  Created by HungHT on 8/1/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MySingleton.h"

@interface ShareDelegateController : UIViewController

@property(nonatomic, strong) MySingleton *singleton;
@property(nonatomic, strong) NSData *responseData;

- (NSData *) getDataFromUrl:(NSURL *)url;
- (NSData *) postDataTo: (NSURL *)url :(NSArray *)paramsTitle :(NSArray *)paramsValue;
- (NSData *) putDataTo: (NSURL *)url :(NSArray *)paramsTitle :(NSArray *)paramsValue;
- (NSData *) deleteFromUrl:(NSURL *)url;

@end
