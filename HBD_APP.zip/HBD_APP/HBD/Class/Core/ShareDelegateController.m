//
//  ShareDelegateController.m
//  HBD
//
//  Created by HungHT on 8/1/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import "ShareDelegateController.h"

@interface ShareDelegateController ()

@end

@implementation ShareDelegateController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - GET Method
- (NSData *) getDataFromUrl:(NSURL *)url{
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setHTTPMethod:@"GET"];
    [request setTimeoutInterval:15];
    [request setURL:url];
    
 
    NSError *error = [[NSError alloc] init];
    NSHTTPURLResponse *responseCode = nil;
    NSData *oResponseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&responseCode error:&error];
     NSLog(@"responseCode statusCode: %li",(long)[responseCode statusCode]);
    NSLog(@"responseCode description: %@",[responseCode description]);
    if([responseCode statusCode] != 200){
        NSLog(@"Error getting %@, HTTP status code %li", url, (long)[responseCode statusCode]);
        //NSLog(@"Error:%@",[error description]);
        return nil;
    }
    return oResponseData;
}

#pragma mark - POST Method
- (NSData *) postDataTo: (NSURL *)url :(NSArray *)paramsTitle :(NSArray *)paramsValue
{
    NSLog(@"urlF = %@",url);
    
//    NSString *uniText = [NSString stringWithUTF8String:[textview.text UTF8String]];
//    NSData *msgData = [uniText dataUsingEncoding:NSNonLossyASCIIStringEncoding];
//    NSString *goodMsg = [[NSString alloc] initWithData:msgData encoding:NSUTF8StringEncoding] ;
    
    NSString *post = @"";
    for (int i = 0; i < paramsTitle.count; i++) {
        NSString *sub = [NSString stringWithFormat:@"&%@=%@",[paramsTitle objectAtIndex:i],[paramsValue objectAtIndex:i]];
        post = [post stringByAppendingString:sub];
    }
    NSLog(@"post: %@",post);
    NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    NSString *postLength = [NSString stringWithFormat:@"%lu",(unsigned long)[postData length]];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:url];
    [request setHTTPMethod:@"POST"];
    [request setTimeoutInterval:20];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
   // [request setValue:@"application/json; charset=UTF-8" forHTTPHeaderField:@"Content-Type"];
    
    [request setHTTPBody:postData];
    NSHTTPURLResponse *responseCode = nil;
    NSError *error;
    NSData *oResponseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&responseCode error:&error];
    NSLog(@"responseCode statusCode: %li",(long)[responseCode statusCode]);
    NSLog(@"responseCode description: %@",[responseCode description]);
    if([responseCode statusCode] != 200){
        NSLog(@"Error getting %@, HTTP status code %li", url, (long)[responseCode statusCode]);
        return nil;
    }
    return oResponseData;
}

#pragma mark - PUT Method
- (NSData *) putDataTo: (NSURL *)url :(NSArray *)paramsTitle :(NSArray *)paramsValue
{
    NSLog(@"urlF = %@",url);
    NSString *post = @"";
    for (int i = 0; i < paramsTitle.count; i++) {
        NSString *sub = [NSString stringWithFormat:@"&%@=%@",[paramsTitle objectAtIndex:i],[paramsValue objectAtIndex:i]];
        post = [post stringByAppendingString:sub];
    }
    NSLog(@"put: %@",post);
    NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    NSString *postLength = [NSString stringWithFormat:@"%lu",(unsigned long)[postData length]];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:url];
    [request setHTTPMethod:@"PUT"];
    [request setTimeoutInterval:20];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:postData];
    NSHTTPURLResponse *responseCode = nil;
    NSError *error;
    NSData *oResponseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&responseCode error:&error];
    NSLog(@"responseCode statusCode: %li",(long)[responseCode statusCode]);
    NSLog(@"responseCode description: %@",[responseCode description]);
    if([responseCode statusCode] != 200){
        NSLog(@"Error getting %@, HTTP status code %li", url, (long)[responseCode statusCode]);
        return nil;
    }
    return oResponseData;
}
#pragma mark - DELETE Method
- (NSData *) deleteFromUrl:(NSURL *)url
{
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setHTTPMethod:@"DELETE"];
    [request setTimeoutInterval:20];
    [request setURL:url];
    NSError *error = [[NSError alloc] init];
    NSHTTPURLResponse *responseCode = nil;
    NSData *oResponseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&responseCode error:&error];
    NSLog(@"responseCode statusCode: %li",(long)[responseCode statusCode]);
    NSLog(@"responseCode description: %@",[responseCode description]);
    if([responseCode statusCode] != 200){
        NSLog(@"Error getting %@, HTTP status code %li", url, (long)[responseCode statusCode]);
        return nil;
    }
    return oResponseData;
}

@end
