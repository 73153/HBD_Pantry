//
//  Video.h
//  HBD
//
//  Created by Tuan Le on 11/3/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Video : NSObject
@property(nonatomic) int idVideo;
@property(nonatomic) int user_id;
@property(nonatomic) NSString *firstname_sender;
@property(nonatomic) NSString *lastname_sender;
@property(nonatomic) NSString *avatar_sender;
@property(nonatomic) int receiver;
@property(nonatomic) NSString *firstname_receiver;
@property(nonatomic) NSString *lastname_receiver;
@property(nonatomic,retain) NSString *title;
@property(nonatomic,retain) NSString *descriptions;
@property(nonatomic,retain) NSString *descriptionStyle;
@property(nonatomic,retain) NSString *descriptionColor;
@property(nonatomic,retain) NSString *titleColor;
@property(nonatomic,retain) NSString *titleStyle;
@property(nonatomic,retain) NSString *longitude;
@property(nonatomic,retain) NSString *latitude;
@property(nonatomic,retain) NSString *location;
@property(nonatomic,retain) NSMutableArray *taggedFriends;
@property(nonatomic,retain) NSString *listTags;
@property(nonatomic,retain) NSArray *arrayListTags;
@property(nonatomic) int totalLikes;
@property(nonatomic) int liked;
@property(nonatomic) int totalComments;
@property(nonatomic,retain) NSArray *latestComment;
@property(nonatomic) int isShareFacebook;
@property(nonatomic) int isShareTwitter;
@property(nonatomic) int isPublic;
@property(nonatomic) int tagFriend;
@property(nonatomic,retain) NSString *frame;
@property(nonatomic,retain) NSString *filter;
@property(nonatomic,retain) NSString *status;
@property(nonatomic,retain) NSString *createdAt;
@property(nonatomic,retain) NSString *updatedAt;
@property(nonatomic,retain) NSString *url;
@property(nonatomic,retain) NSString *firstname_comment;
@property(nonatomic,retain) NSString *lastname_comment;
@property(nonatomic,retain) NSString *avatar_comment;
@property(nonatomic,retain) NSString *content_comment;
@property(nonatomic,retain) NSString *tagedInComment;


@end
