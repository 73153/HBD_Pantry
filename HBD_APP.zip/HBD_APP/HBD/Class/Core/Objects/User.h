//
//  User.h
//  HBD
//
//  Created by HoanVu on 11/25/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface User : NSManagedObject

@property (nonatomic, retain) NSString * idUser;
@property (nonatomic, retain) NSString * email;
@property (nonatomic, retain) NSString * token;
@property (nonatomic, retain) NSString * password;
@property (nonatomic, retain) NSString * firstName;
@property (nonatomic, retain) NSString * lastName;
@property (nonatomic, retain) NSString * avatar;
@property (assign) int tagLoginFb;



@end
