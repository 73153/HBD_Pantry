//
//  MySingleton.h
//  MB360
//
//  Created by Tuan Le on 2/11/14.
//  Copyright (c) 2014 Tuan Le. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MySingleton : NSObject
+(MySingleton*) getInstance;
@property BOOL Update,UpdateRight, updateMyShout, updateListFriend , changedAvatar,isFromRight;
@property(nonatomic,retain) NSMutableArray *listHbdFriend;
@property(nonatomic,retain) NSMutableArray *listbirthday;
@property(nonatomic,retain) NSMutableArray *aryAllComment;
@property(nonatomic,retain) NSMutableArray *aryImages;
@property(nonatomic,retain) NSArray *zodiacImageF;
@property(nonatomic,retain) NSArray *zodiacImageM;
@property(nonatomic,retain) NSArray *zodiacName;

@property(strong, nonatomic) NSString *strBadge,*strUpcmingBday,*strFriendName,*strReferID;
@property BOOL isFromShoutOrNot;
@property BOOL isFriendCellFromHome;
@property BOOL isForRecord;
@property BOOL isFromHIW;
@property BOOL hasAudio;
@property BOOL isFromPushNotification;
@property BOOL IsAddButoonClicked;
@property(assign) NSInteger strCountLbl;


@property(strong, nonatomic) NSString *strWebCurrentURL;
@property(strong, nonatomic) NSString *myToken;
@property(strong, nonatomic) NSString *deviceToken;
@property(strong, nonatomic) NSString *myId;
@property(strong, nonatomic) NSString *myEmail;
@property(strong, nonatomic) NSString *firstName;
@property(strong, nonatomic) NSString *lastName;
@property(strong, nonatomic) NSString *myUsername;
@property(strong, nonatomic) NSString *myAvatar;
@property(strong, nonatomic) NSString *strComment;
@property(strong, nonatomic) NSURL *strUploadVideo;
@property(nonatomic) BOOL *isFromSelectVC;
@property(strong, nonatomic) NSURL *strVideoURL;

@property(nonatomic) float strTotalSection;
@property (nonatomic, strong) NSMutableArray *aryGetUrlGallery;
@property (nonatomic, strong) NSMutableArray *aryLongSection;
@property(assign) int selectShouted;
@property(assign) int selectDrafts;
@property(assign) int selectWishList;
@property(assign) int tagRecordVideo;
@property(assign) int tagSetting;
@property(assign) int timeLastRecord;

#pragma mark - Update my setting
@property(assign) int ntfWishlistUpdate;
@property(assign) int ntfShoutCmt;
@property(assign) int ntfShoutLike;
@property(assign) int ntfShoutTag;
@property(assign) int timeUpcoming;
@property(assign) int sentToEmail;
@property(assign) int sentToFacebook;
@property(assign) int sentToTwitter;
@property(assign) int isPublic;
@property(assign) long notificationCOunt;
@property(assign) long ResponseCount;
@property(assign) long newResponseCount;

@property(assign) BOOL isRecordScreen;
@property(assign) BOOL isFromtabNotification;
@property(assign) BOOL isFromFriendCell;
@property(assign) BOOL isFromAmazon;
@property(assign) BOOL isFromGoogle;
@property(assign) BOOL isFromBestbuy;
@property(assign) BOOL isFrom1800Flower;
@property(assign) BOOL isFromModellsSportingGoods;
@property(assign) BOOL isFromWallMart;
@property(assign) BOOL isFromBloomingdales;
@property(assign) BOOL isFromChocolate;
@property(assign) BOOL isFromDogIsGood;
@property(assign) BOOL isFromFye;
@property(assign) BOOL isFromMelissaAndDoug;
@property(assign) BOOL isFromLOccitaneUK;
@property(assign) BOOL isFromNikeBR;
@property(assign) BOOL isFromPerfumeCom;
@property(assign) BOOL isFromSephoraBR;
@property(assign) BOOL isFromTateBakeShop;
@property(assign) BOOL isFromThePopcornFactory;
@property(assign) BOOL isFromGameStop;
@property(assign) BOOL isFromMacys;
@property(assign) BOOL isFromMicrosoft;
@property(assign) BOOL isFromNORDSTROM;
@property(assign) BOOL isFromSamClub;
@property(assign) BOOL isFromWine;
@property(assign) BOOL isFromWEIBeauty;
@property(assign) BOOL isFromYogaOutlet;
@property(assign) BOOL isFromTechArmor;

@property(assign) BOOL isFromNotiCommentTag;
@property(strong, nonatomic) NSString *strCommentTagVideoId;
@property(assign) BOOL isFromTapToRecord;
@property(assign) NSInteger friendId;
@property(assign) BOOL isPresentingView;
@end
