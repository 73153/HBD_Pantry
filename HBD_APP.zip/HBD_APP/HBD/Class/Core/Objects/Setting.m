//
//  Setting.m
//  HBD
//
//  Created by HoanVu on 12/17/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import "Setting.h"


@implementation Setting

@dynamic timeUpcoming;
@dynamic ntfWishlistUpdate;
@dynamic ntfShoutCmt;
@dynamic ntfShoutLike;
@dynamic ntfShoutTag;
@dynamic sentToEmail;
@dynamic sentToFacebook;
@dynamic sentToTwitter;
@dynamic isPublic;
@dynamic lastIdUser;

@end
