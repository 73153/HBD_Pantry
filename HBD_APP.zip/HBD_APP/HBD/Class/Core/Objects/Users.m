//
//  Users.m
//  Rover
//
//  Created by Aadil Keshwani on 3/17/15.
//  Copyright (c) 2015 Aadil Keshwani. All rights reserved.
//

#import "Users.h"
#import "APICall.h"
#import "Constant.h"
#import "ApplicationData.h"

@implementation Users
@synthesize username,password,userid,accountid,firstname,lastname,pin,key,page,profileid,aryMyProfileImage,nextPageUrl,gId,otherProfileid,postid,comment,followedby,aryAddCommentPost,aryProfileAddFollowers,lastPage;
@synthesize strTextfildStreet,StrTextViewDescription,strtxtfildCity,strtxtFildCurrntpwd,strTxtFildRetypNewPwd,strtxtFildStreet2,strtxtfildZip,strTxtFildNewPwd,strTxtfildPhonenom,strSMS,strAccPrivate;
-(instancetype)init
{
    self = [super init];
    if(self) {
        self.username=[[NSMutableString alloc]init];
        self.email=[[NSMutableString alloc]init];
        self.password=[[NSMutableString alloc]init];
        self.currentPassword=[[NSMutableString alloc]init];
        self.firstname=[[NSMutableString alloc]init];
        self.lastname=[[NSMutableString alloc]init];
        self.imgPath=[[NSMutableString alloc] init];
        self.deviceToken=[[NSString alloc] init];
        self.accountid=0;
        self.userid= [[NSMutableString alloc] init];
        self.pin=0;
        self.fbid=[[NSMutableString alloc]init];
    	 self.gId=[[NSMutableString alloc]init];
        lastPage = 0;
        self.profileid=[[NSMutableString alloc]init];
        self.nextPageUrl = [[NSMutableString alloc]init];
        profileid=[[NSMutableString alloc]init];
        key=[[NSMutableString alloc]init];
        comment=[[NSMutableString alloc]init];
        postid=[[NSMutableString alloc]init];
        aryMyProfileImage=[[NSMutableArray alloc]init];
        aryAddCommentPost=[[NSMutableArray alloc]init];
        followedby=[[NSMutableString alloc]init];
        aryProfileAddFollowers=[[NSMutableArray alloc]init];
        //
        strtxtfildZip=[[NSMutableString alloc]init];
        strtxtFildStreet2=[[NSMutableString alloc]init];
       strTxtFildRetypNewPwd=[[NSMutableString alloc]init];
       strtxtFildCurrntpwd=[[NSMutableString alloc]init];
        strTextfildStreet=[[NSMutableString alloc]init];
        StrTextViewDescription=[[NSMutableString alloc]init];
       strtxtfildCity =[[NSMutableString alloc] init];
        strTxtFildNewPwd=[[NSMutableString alloc] init];
        strTxtfildPhonenom=[[NSMutableString alloc] init];
        strSMS=[[NSMutableString alloc] init];
        strAccPrivate=[[NSMutableString alloc] init];
    }
    return self;
}
-(void)registerUser:(user_completion_block)completion{
    @try {
       
        if ([self.deviceToken length]<1)
        {
            self.deviceToken=@" ";
        }
   
    NSDictionary *parameters = @{@"email":self.email,@"fname": self.firstname,@"lname":self.lastname, @"password":self.password,@"sDeviceToken":self.deviceToken,@"username":self.username,@"status":@"0"};
    NSString *url_String = [NSString stringWithFormat:@"%@", API_USER];
    
    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* user, NSError*error, long code){
        if(error)
        {
            if(completion)
            {
                completion(@"OOPS Seems like something is wrong with server",-1);
            }
            [[[error userInfo] objectForKey:AFNetworkingOperationFailingURLResponseErrorKey] statusCode];
        }
        else{
            if(completion)
            {
                
                if([[user valueForKey:@"error"]integerValue]==0)
                {
                    completion(@"User account registered successfully ",1);
                    
                }
                else if([[user valueForKey:@"error"]integerValue]==1)
                {
                    completion(@"User name already exists",0);
                }
                else
                {
                    completion(@"Error From server ",0);
                }
            }
        }
    }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}
-(void)socialRegistrUser:(user_completion_block)completion
{
   // username,email,social_id,social_site,fname,lname,password
    @try
    {

    if(!self.email)
    {
        self.email=[@"newemail@gmail.com" mutableCopy];
    }
        
    NSDictionary *parameters = @{@"username":self.username,@"email":self.email,@"fname": self.firstname,@"lname":self.lastname, @"password":@"123456",@"social_id":self.fbid,@"social_site":self.socialType,@"sDeviceToken":self.deviceToken};
    NSString *url_String = [NSString stringWithFormat:@"%@", API_SOCIAL_LOGIN_NEW];
        
    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* user, NSError*error, long code)
        {
        if(error)
        {
            NSLog(@"%ld",code);
            
            if(completion)
            {
                completion(@"OOPS Seems like something is wrong with server",-1);
            }
            
            [[[error userInfo] objectForKey:AFNetworkingOperationFailingURLResponseErrorKey] statusCode];
        }
        else
        {
            if(completion)
            {
                if([[user valueForKey:@"error"]intValue]==0)
                {
                    APPDATA.user.userid = [[user valueForKey: @"data"] valueForKey:@"user_id"];
                    APPDATA.user.profileid = [[user valueForKey: @"data"] valueForKey:@"profile_id"];
                    APPDATA.user.username = [[user valueForKey:@"data"] valueForKey:@"username"];
                    completion(@"User account registered successfully ",1);
                }
                else if([[user valueForKey:@"error"]intValue]==0)
                {
                    completion(@"Email id is already registered ",0);
                    
                }
            }
        }
    }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}
-(void)verifyUser{
    @try {
    NSString *url_String = [NSString stringWithFormat:@"%@/%@/verify?pin=%i", API_USER,self.userid,self.pin];
    [APICall callPostWebService:url_String andDictionary:nil completion:^(NSDictionary* user, NSError*error, long code){
        if(error)
        {
            //NSLog(@"Error");
        }
        else{
           // NSLog(@"Success");
        }
    }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}

-(void)loginUser:(user_completion_block)completion{
    @try {
    NSString *url_String = [NSString stringWithFormat:@"%@", API_USER_LOGIN];
    
    NSDictionary *parameters = @{@"email":self.email,@"password":self.password,@"sDeviceToken":self.deviceToken
                                 };
    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* user, NSError*error, long code){
        if(error)
        {
            if(completion)
            {
                completion(@"There was some error, please try again later",-1);
            }
        }
        else{
            if(completion)
            {
                if([[user valueForKey:@"error"]integerValue]==0)
                {
                    self.userid  =[[[user objectForKey:@"data"] objectAtIndex:0] objectForKey:@"id"];
                    
                    
                    self.username=[[[user objectForKey:@"data"] objectAtIndex:0] objectForKey:@"username"];
                    self.firstname=[[[user objectForKey:@"data"] objectAtIndex:0] objectForKey:@"username"];
                    self.profileid=[[[user objectForKey:@"data"] objectAtIndex:0] objectForKey:@"profile_id"];
         
                    
                     UDSetObject(self.userid, @"id");
                    
                    
                    completion(@"Login success",1);
                }
                else{
                    completion([user valueForKey:@"message"],-1);
                }
            }
        }
    }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}
-(void)checkEmail:(user_completion_block)completion {
    @try {
    NSString *url_String = [NSString stringWithFormat:@"%@", API_CHECKEMAIL];
    NSDictionary *parameters = @{@"email":self.email,@"sDeviceToken":self.deviceToken};
    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* user, NSError*error, long code){
        if(error)
        {
            if(completion)
            {
                completion(@"There was some error, please try again later",-1);
            }
        }
        else{
            if(completion)
            {
                if([[user valueForKey:@"error"]integerValue]==0)
                {
                    
                    completion(@"success",1);
                }
                else{
                    completion([user valueForKey:@"message"],-1);
                }
            }
        }
    }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}
-(void)checkSocialId:(user_completion_block)completion {
    @try {
    NSString *url_String = [NSString stringWithFormat:@"%@&social_id=%@", API_CHECKSOCIALID,self.userid];
   // NSDictionary *parameters = @{@"social_id":self.userid,@"sDeviceToken":self.deviceToken};
     NSDictionary *parameters = nil;
    [APICall callGetWebService:url_String andDictionary:parameters completion:^(NSMutableDictionary *user, NSError *error, long code){
    if(error)
     {
         if(completion)
         {
             completion(@"There was some error, please try again later",-1);
         }
     }
     else{
         if(completion)
         {
             if([[user valueForKey:@"error"] intValue ] == 0)
             {
                 completion(@"success",1);
             }
             else if([[user  objectForKey:@"code"]valueForKey:@"email"] ){
                 completion(@"success",0);
             }
             else{
                 completion([user valueForKey:@"message"],-1);
             }
         }
     }
     }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}

-(void)CheakExistingEmail:(user_completion_block)completion {
    @try {
 NSString *url_String = [NSString stringWithFormat:@"%@", API_CHECKEMAILEXISTING];
        // NSDictionary *parameters = @{@"social_id":self.userid,@"sDeviceToken":self.deviceToken};
        NSDictionary *parameters = @{@"email":self.emailCheak};
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* user, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[user valueForKey:@"error"]integerValue]==0)
                    {
                        
                        
                        completion(@"success",1);
                    }
                    else{
                        completion([user valueForKey:@"message"],-1);
                    }
                }
            }
        }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}





-(void)profileUpdate:(NSMutableDictionary *) dictParam:(user_completion_block)completion{
    @try {
        
    NSString *url_String = [NSString stringWithFormat:@"%@", API_PROFILE_UPDATE];
    
   
    [APICall callPostWebService:url_String andDictionary:dictParam completion:^(NSDictionary* user, NSError*error, long code){
        if(error)
        {
            if(completion)
            {
                completion(@"There was some error, please try again later",-1);
            }
        }
        else{
            if(completion)
            {
                if([[user valueForKey:@"error"]integerValue]==0)
                {
                   
                    
                    completion(@"Login success",1);
                }
                else{
                    completion([user valueForKey:@"message"],-1);
                }
            }
        }
    }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}


+ (void)updateProfile:(NSDictionary *)dictParam successed:(void (^)(id responseObject_))success_ failure:(void (^)(NSError* error_))failure_
{
    
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    [dict addEntriesFromDictionary:dictParam];
    
    
    
    //[[NetAPIClient sharedClient] sendToemailValidation:dict success:success_ failure:failure_];
}
-(void)getmyprofileImage:(user_completion_block)completion{

    @try {
    NSString *url_String = [NSString stringWithFormat:@"%@", API_PROFILELIST];
    
    NSDictionary *parameters = @{@"key":self.key,@"page":self.page,@"profile_id":APPDATA.user.profileid};
    
    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* profile, NSError*error, long code){
        if(error)
        {
            if(completion)
            {
                completion(@"There was some error, please try again later",-1);
            }
        }
        else{
            if(completion)
            {
                if([[profile valueForKey:@"error"]integerValue]==0)
                {
                    
                    NSMutableArray *arrProfileData = [[profile valueForKey:@"data"]objectForKey:@"data"];
                    [arrProfileData enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                        [APPDATA.user.aryMyProfileImage addObject:obj];
                    }];
                     //APPDATA.user.aryMyProfileImage= [[profile valueForKey:@"data"]objectForKey:@"data"];
                     APPDATA.user.nextPageUrl = [[profile valueForKey:@"data"] valueForKey:@"next_page_url"];
                    APPDATA.user.lastPage = [[[profile valueForKey:@"data"] valueForKey:@"last_page"] intValue];
                    
                    completion(@"Login success",1);
                }
                else{
                    completion([profile valueForKey:@"message"],-1);
                }
            }
        }
    }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
     
}

-(void)ADDCommentOnPost:(user_completion_block)completion{
    @try {
    NSString *url_String = [NSString stringWithFormat:@"%@", API_ADDCOMMENTONPOST];
    
    NSDictionary *parameters =[[NSDictionary alloc]initWithObjectsAndKeys:self.key,@"key",appDelegate.profilid_AppStr,@"profile_id",self.comment,@"comment",self.postid,@"post_id",nil];
    
    
    //    @{@"key":self.key,@"profile_id":self.profileid,@"comment":self.comment,@"postid":self.postid};
    
    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary *result, NSError*error, long code){
        if(error)
        {
            if(completion)
            {
                completion(@"There was some error, please try again later",-1);
            }
        }
        else{
            if(completion)
            {
                if([[result valueForKey:@"error"]integerValue]==0)
                {
                    APPDATA.user.aryAddCommentPost= [[result valueForKey:@"data"]objectForKey:@"data"];
                    APPDATA.user.nextPageUrl = [[result valueForKey:@"data"] valueForKey:@"next_page_url"];
                    APPDATA.user.profileid=[[result valueForKey:@"data"] valueForKey:@"profile_id"];
                                                          
                    completion(@"Login success",1);
                }
                else{
                    completion([result valueForKey:@"message"],-1);
                }
            }
        }
    }];
    
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}
-(void)addFollow:(user_completion_block)completion{
    @try {
     NSString *url_String = [NSString stringWithFormat:@"%@", API_ADDFOLLOWERS];
    NSDictionary *parameters = @{@"key":self.key,@"profile_id":self.profileid,@"followed_by":APPDATA.user.profileid};
    
    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* profile, NSError*error, long code){
        if(error)
        {
            if(completion)
            {
                completion(@"There was some error, please try again later",-1);
            }
        }
        else{
            if(completion)
            {
                if([[profile valueForKey:@"error"]integerValue]==0)
                {
  
                    
                   completion([profile valueForKey:@"data"],1);
                }
                else{
                    completion([profile valueForKey:@"message"],-1);
                }
            }
        }
    }];
    
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}





//-(void)fbloginUser:(user_completion_block)completion{
//    NSString *url_String = [NSString stringWithFormat:@"%@", API_USER_FB_LOGIN];
//    if(!self.fbid)
//    {
//        completion(@"There was some error, please try again later",-1);
//        return;
//    }
//    if(!self.username)
//    {
//        completion(@"Unable to get Email Permission from Facebook, Try with Developer account",-1);
//        return;
//    }
//    NSDictionary *parameters = @{@"sEmail":self.username,@"sFBID":self.fbid,@"sDeviceToken":self.deviceToken};
//    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* user, NSError*error, long code){
//        if(error)
//        {
//            if(completion)
//            {
//                completion(@"There was some error, please try again later",-1);
//            }
//        }
//        else{
//            if(completion)
//            {
//                if([[user valueForKey:@"status"]integerValue]==1)
//                {
//                    
//                    self.firstname=[[user objectForKey:@"userdetails"] valueForKey:@"sFirstName"];
//                    self.lastname=[[user  objectForKey:@"userdetails"] valueForKey:@"sLastName"];
////                    self.userid=[[[user  objectForKey:@"userdetails"] valueForKey:@"nUserId"] intValue];
//                    self.fbid=[[user  objectForKey:@"userdetails"] valueForKey:@"sFBID"];
//                    self.imgPath=[[user  objectForKey:@"userdetails"] valueForKey:@"sImage"];
//                    completion(@"Login success",0);
//                }
//                else if([[user valueForKey:@"status"]integerValue]==-2){
//                    completion(@"Facebook Account is not registered with us. Register with Facebook",-1);
//                }
//                else if([[user valueForKey:@"status"]integerValue]==-1){
//                    completion(@"Provide valid email id and facebook id",-1);
//                }
//                else{
//                    
//                }
//            }
//        }
//    }];
//}
//-(void)updateProfile:(user_completion_block)completion{
//    NSString *url_String = [NSString stringWithFormat:@"%@", API_USER_UPDATE];
//    NSDictionary *parameters = @{@"sFirstName":self.firstname,@"sLastName":self.lastname,@"nUserId":[NSString stringWithFormat:@"%@",self.userid]};
//    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* user, NSError*error, long code){
//        if(error)
//        {
//            if(completion)
//            {
//                completion(@"There was some error in updating your profile. Try again",-1);
//            }
//        }
//        else{
//            if(completion)
//            {
//                if([[user valueForKey:@"status"]integerValue]==1)
//                {
//                    completion(@"Update Profile success",0);
//                }
//                else{
//                    completion(@"There was some error in updating your profile. Try again",-1);
//                }
//            }
//        }
//    }];
//}
//-(void)changePassword:(user_completion_block)completion{
//    NSString *url_String = [NSString stringWithFormat:@"%@", API_USER_CHANGE_PASSWORD];
//    NSDictionary *parameters = @{@"sCurrPassword":self.currentPassword,@"sPassword":self.password,@"nUserId":[NSString stringWithFormat:@"%@",self.userid]};
//    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* user, NSError*error, long code){
//        if(error)
//        {
//            if(completion)
//            {
//                completion(@"There was some error in changing password. Try again",-1);
//            }
//        }
//        else{
//            if(completion)
//            {
//                if([[user valueForKey:@"status"]integerValue]==1)
//                {
//                    completion(@"Password changed successfully",0);
//                }
//                else{
//                    completion(@"Current password is incorrect. Try again",-1);
//                }
//            }
//        }
//    }];
//}
//-(void)forgotPassword:(user_completion_block)completion{
//    NSString *url_String = [NSString stringWithFormat:@"%@", API_USER_FORGOT];
//    NSDictionary *parameters = @{@"sEmail":self.username};
//    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* user, NSError*error, long code){
//        if(error)
//        {
//            if(completion)
//            {
//                completion(@"There was some error. Try again",-1);
//            }
//        }
//        else{
//            if(completion)
//            {
//                if([[user valueForKey:@"status"]integerValue]==1)
//                {
//                    completion(@"Check your email id for further instructions",0);
//                }
//                else{
//                    completion(@"This email id is not registered with us",-1);
//                }
//            }
//        }
//    }];
//}
//-(void)uploadPicture:(user_completion_block)completion{
//    NSString *url_String = [NSString stringWithFormat:@"%@", API_USER_PROFILE];
//    NSDictionary *parameters = @{@"nUserId":[NSString stringWithFormat:@"%@", self.userid ]};
//    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* user, NSError*error, long code){
//        if(error)
//        {
//            if(completion)
//            {
//                completion(@"There was some error. Try again",-1);
//            }
//        }
//        else{
//            if(completion)
//            {
//                if([[user valueForKey:@"status"]integerValue]==1)
//                {
//                    completion(@"Check your email id for further instructions",0);
//                }
//                else{
//                    completion(@"This email id is not registered with us",-1);
//                }
//            }
//        }
//    }];
//}
//
//-(void)logOut:(user_completion_block)completion{
//    NSString *url_String = [NSString stringWithFormat:@"%@", API_USER_LOGOUT];
//    NSDictionary *parameters = @{@"nUserId":[NSString stringWithFormat:@"%@",self.userid ]};
//    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* user, NSError*error, long code){
//        if(error)
//        {
//            if(completion)
//            {
//                completion(@"There was some error, please try again later",-1);
//            }
//        }
//        else{
//            if(completion)
//            {
//                if([[user valueForKey:@"status"]integerValue]==1)
//                {
//                    completion(@"Logout success",0);
//                }
//                else{
//                    completion(@"There was some error, please try again later",-1);
//                }
//            }
//        }
//    }];
//}

@end
