//
//  Setting.h
//  HBD
//
//  Created by HoanVu on 12/17/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Setting : NSManagedObject

@property (nonatomic, retain) NSNumber * timeUpcoming;
@property (nonatomic, retain) NSNumber * ntfWishlistUpdate;
@property (nonatomic, retain) NSNumber * ntfShoutCmt;
@property (nonatomic, retain) NSNumber * ntfShoutLike;
@property (nonatomic, retain) NSNumber * ntfShoutTag;
@property (nonatomic, retain) NSNumber * sentToEmail;
@property (nonatomic, retain) NSNumber * sentToFacebook;
@property (nonatomic, retain) NSNumber * sentToTwitter;
@property (nonatomic, retain) NSNumber * isPublic;
@property (nonatomic, retain) NSNumber * lastIdUser;

@end
