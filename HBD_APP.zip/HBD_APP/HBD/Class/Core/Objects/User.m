//
//  User.m
//  HBD//
//
//  Created by HoanVu on 11/25/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import "User.h"


@implementation User

@dynamic idUser;
@dynamic email;
@dynamic token;
@dynamic password;
@dynamic firstName;
@dynamic lastName;
@dynamic avatar;
@dynamic tagLoginFb;

@end
