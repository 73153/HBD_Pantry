//
//  MySingleton.m
//  MB360
//
//  Created by Tuan Le on 2/11/14.
//  Copyright (c) 2014 Tuan Le. All rights reserved.
//

#import "MySingleton.h"
@implementation MySingleton
@synthesize Update,listbirthday, updateMyShout;

-(id)init{
    self = [super init];
    if(self)
    {
        _aryAllComment=[[NSMutableArray alloc]init];
        _aryImages=[[NSMutableArray alloc]init];
        _aryGetUrlGallery=[[NSMutableArray alloc]init];
        _aryLongSection = [[NSMutableArray alloc]init];
        _zodiacImageF = [NSArray arrayWithObjects: @"aquarius-f", @"pisces-f", @"aries-f", @"sagittarius-f", @"gemini-f", @"cancer-f", @"leo-f", @"virgo-f", @"libra-f", @"scorpio-f", @"sagittarius-f", @"capricorn-f", nil];
        _zodiacImageM = [NSArray arrayWithObjects: @"aquarius-m", @"pisces-m", @"aries-m", @"sagittarius-m", @"gemini-m", @"cancer-m", @"leo-m", @"virgo-m", @"libra-m", @"scorpio-m", @"sagittarius-m", @"capricorn-m", nil];
         _zodiacName = [NSArray arrayWithObjects: @"Aquarius", @"Pisces", @"Aries", @"Taurus", @"Gemini", @"Cancer", @"Leo", @"Virgo", @"Libra", @"Scorpio", @"Sagittarius", @"Capricorn", nil];
        _hasAudio = TRUE;
    }
    return self;
}

static MySingleton *singletonInstance;
+ (MySingleton*)getInstance{
    
    if (singletonInstance == nil) {
        singletonInstance = [[super alloc] init];
       // _aSingleton.aryAllComment=[[NSMutableArray alloc]init];

        
    }
    return singletonInstance;
}


@end
