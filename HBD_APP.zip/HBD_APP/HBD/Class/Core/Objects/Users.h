//
//  Users.h
//  Rover
//
//  Created by Aadil Keshwani on 3/17/15.
//  Copyright (c) 2015 Aadil Keshwani. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Users : NSObject
@property int pin, accountid,lastPage;
typedef void(^user_completion_block)(NSString *, int status);
@property NSMutableString  *userid,*username,*firstname,*lastname,*password,*currentPassword,*fbid,*imgPath,*email,*socialType,*profileid,*key,*page,*nextPageUrl,*gId,*otherProfileid,*postid,*comment,*followedby, *emailCheak;
@property NSString *deviceToken;
@property NSMutableArray *aryMyProfileImage,*aryAddCommentPost,*aryProfileAddFollowers;
//

@property NSMutableString *StrTextViewDescription,*strTxtfildPhonenom,*strTextfildStreet,*strtxtFildStreet2,*strtxtfildCity,*strtxtfildZip,*strtxtFildCurrntpwd,*strTxtFildRetypNewPwd,*strTxtFildNewPwd,*strSMS,*strAccPrivate;

-(void)registerUser:(user_completion_block)completion;
-(void)verifyUser;
-(void)loginUser:(user_completion_block)completion;
-(void)updateProfile:(user_completion_block)completion;
-(void)changePassword:(user_completion_block)completion;
-(void)logOut:(user_completion_block)completion;
-(void)fbloginUser:(user_completion_block)completion;
-(void)socialRegistrUser:(user_completion_block)completion;
-(void)forgotPassword:(user_completion_block)completion;
-(void)uploadPicture:(user_completion_block)completion;
-(void)checkEmail:(user_completion_block)completion;
-(void)checkSocialId:(user_completion_block)completion;
-(void)CheakExistingEmail:(user_completion_block)completion;
-(void)profileUpdate:(NSMutableDictionary *) dictParam:(user_completion_block)completion;
-(void)getmyprofileImage:(user_completion_block)completion;
-(void)ADDCommentOnPost:(user_completion_block)completion;
-(void)addFollow:(user_completion_block)completion;


@end
