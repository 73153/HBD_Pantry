//
//  Video.m
//  HBD
//
//  Created by Tuan Le on 11/3/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import "Video.h"

@implementation Video
@synthesize idVideo,user_id,receiver,title,descriptions,descriptionStyle,descriptionColor,
titleColor,titleStyle,totalLikes,totalComments,isShareFacebook,isShareTwitter,frame,filter,
status,createdAt,updatedAt,url,isPublic,location,longitude,latitude,tagFriend;
@end
