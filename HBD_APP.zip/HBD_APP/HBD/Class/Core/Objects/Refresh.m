//
//  Refresh.m
//  HBD
//
//  Created by HoanVu on 12/23/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import "Refresh.h"


@implementation Refresh

@dynamic timeUpdateHome;
@dynamic timeUpdateFeed;

@end
