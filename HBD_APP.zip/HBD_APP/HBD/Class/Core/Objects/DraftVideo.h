//
//  DraftVideo.h
//  HBD
//
//  Created by HoanVu on 12/20/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface DraftVideo : NSManagedObject

@property (nonatomic, retain) NSString * urlVideo;
@property (nonatomic, retain) NSDictionary * dataVideo;
@property (nonatomic, retain) NSData * filterImage;
@property (nonatomic, retain) NSData * frameImage;
@property (nonatomic, retain) NSString * nameFrameImage;

@end
