//
//  Sharer.h
//  HBD
//
//  Created by Max Stein on 1/22/15.
//  Copyright (c) 2015 HungHT. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <FacebookSDK/FacebookSDK.h>
#import <Twitter/Twitter.h>
#import <Social/Social.h>
#import "ShareDelegateController.h"
#import "FriendCell.h"
#import "AddFriendsCell.h"
#import "MySingleton.h"
#import "AppDelegate.h"
#import "MMDrawerController.h"
#import "ApplicationData.h"
#import "SocialLogin.h"

@class SLComposeServiceViewController;

#ifndef HBD_Sharer_h
#define HBD_Sharer_h

#endif
@interface Social : NSObject
+ (void) shareToFacebook:(NSString *)url title:(NSString *)title description:(NSString *)description controller:(UIViewController*)controller;
+ (void) sendRequestFriend:(NSString*)idReceive email:(NSString*)email;
+ (void) viewProfileOf:(NSString *)userId controller:(UIViewController*)controller;
+ (NSMutableArray *) getUserShouted:(NSString *)idUser limit:(int)limit offset:(int)offset;
+(NSMutableArray *) getUserShoutedToYou:(NSString *)idUser limit:(int)limit offset:(int)offset;
+ (NSDictionary *) findFriendFromEmail:(NSString *)email;
+ (NSDictionary *) updateSpecialValue:(NSString *)email withValue:(int)special;
+ (void) viewProfileWithArray:(NSArray *)userInfo controller:(UIViewController*)controller withDelegate:(BOOL)hasDelegate;
+ (NSDictionary *) findFriendFromId:(NSString *)idUser;
+ (int) startFriendRequest:(NSString *)firstName lastName:(NSString *)lastName email:(NSString *)email birthday:(NSString *)birthday isSpecial:(NSString *)isSpecial;
+ (SLComposeViewController *) shareToTwitter:(int)videoId title:(NSString *)title description:(NSString *)description;
+ (FriendCell *) getFriendCell:(NSMutableArray *)friendInfo atRow:(NSInteger)atRow tableView:(UITableView *)tableView;
+ (NSMutableArray *) getFriendList:(long)limit withOffset:(long)offset byName:(BOOL)byName;
+ (AddFriendsCell *) getAddFriendCell:(NSMutableArray *)friendInfo atRow:(NSInteger)atRow tableView:(UITableView *)tableView;
- (void)checkButtonTapped:(id)sender event:(id)event;
-(void)onbtnWishListAction:(UIButton *) btn;
@property (nonatomic, strong) AppDelegate *delegate;
@property (nonatomic,strong) ApplicationData *appData;
+ (void) viewProfileWithArrayNotify:(NSDictionary *)userInfo controller:(UIViewController*)controller withDelegate:(BOOL)hasDelegate ;


@end