//
//  Supper.h
//  HBD
//
//  Created by HoanVu on 11/29/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import "MySingleton.h"
#import "ShareDelegateController.h"


@interface Supper : UIViewController

@property(nonatomic, strong) MySingleton *aSingleton;
@property(nonatomic, strong) ShareDelegateController *aShareMethod;
@property (strong, nonatomic) MPMoviePlayerController *theMovie;
@property (nonatomic, strong) NSUserDefaults *userD;
@property (nonatomic, strong) NSDictionary *userDict;
#pragma mark - Get all comment of Video
-(NSArray *) getAllCommentOfVideo:(NSString *)videoId :(int) limit :(int) offset;
-(BOOL) postCommentAVideo:(int) idOfVideo :(NSString *) contentCmt tagedId:(NSString *)tagedId;
#pragma mark - Play Video With Url
-(void) playVideoWithUrl:(NSURL *) url;
#pragma mark - USER - FRIEND
-(NSArray *) getDataUser:(NSString *)idUser;
-(NSDictionary *) getMyData;
#pragma mark - Response Request Friend
-(BOOL) acceptRequestFriend:(NSString *)idPartner;
-(int) checkFriendStatus:(NSString *)idPartner;
#pragma mark - Send link video to friend's email
-(void) sendLinkVideoToFriendEmail: (NSString *)email : (NSString *)idVideo;
#pragma mark - COLOR - FONT
#pragma mark - giveColorfromStringColor
-(UIColor *)giveColorfromStringColor:(NSString *)colorname;
- (void) checkNewPass:(UITextField *)pass reNewPass:(UITextField *)reNewPass;
-(NSString *) parseANotification:(NSMutableArray *)notificationList;
- (BOOL) checkConnection;
@end

