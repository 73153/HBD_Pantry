//
//  Commons.h
//  HBD
//
//  Created by Max Stein on 1/26/15.
//  Copyright (c) 2015 HungHT. All rights reserved.
//

#ifndef HBD_Commons_h
#define HBD_Commons_h
#import <UIKit/UIKit.h>
#import "AFNetworking.h"
#import "Video.h"
#import "MyShoutedCell.h"
#import "ProfileViewController.h"

#endif

@interface Commons : UIViewController

+ (void) addViewLoading:(UIViewController *)controller;
+ (UIColor *) colorWithHexString:(NSString*)hex;
+ (NSString *) getShortMonthString :(NSInteger) month;
+ (NSString *) getMonthString :(NSInteger) month;
+ (NSString *) formatDate:(int) day;
+ (void) addViewLoadingWithContent:(UIViewController*)controller str:(NSString *)contentStr;
+ (NSString *) GetDayFormatFromDate:(NSString *) aDate;
+ (int) getZodiacTag:(long)month day:(long)day;
+ (BOOL) loginMethod:(UITextField *)emailTextField passWordTextField:(UITextField *)passwordTextField;
+ (void) setCheckBackgroundImage:(UIButton *)button type:(int)type;
+ (int) switchValue:(int)value;
+ (void) showViewLoadingMBProgressHUB:(UIViewController *) controller contentStr:(NSString *)contentStr;
+ (void) roundCorners:(NSArray *)layers;
+ (NSString *) getFontStyle;
+ (NSString *) getFontWithSize:(NSString *)fontSize;
+ (NSArray *) getUsersWishlist:(NSString *)userId;
+ (void) setUpButton:(UIButton *)buttonName tagValue:(NSInteger)tagValue withSelector:(SEL)selectorName withController:(UIViewController *)controller;
+ (NSDictionary *) getRequest:(NSString *)urlString;
+ (NSDictionary *) deleteRequest:(NSString *)urlString;
+ (NSDictionary *) postRequest:(NSString *)urlString paramsTitle:(NSArray *)paramsTitle paramsValue:(NSArray *)paramsValue;
+ (void) checkCantConnect:(NSDictionary *)jsonDict;
+ (void) setSingletonOnLogin:(int)isFacebook withDict:(NSDictionary *)loginDict;
+ (AFHTTPRequestOperationManager *) getManager;
+ (void) showAlert:(NSString *)alertText;
+ (Video *) setVideoData:(NSArray *)videoData;
+ (void) setThumbnail:(UIImageView *)imageName withArray:(NSMutableArray *)shoutArray isDraft:(BOOL)isDraft;
+ (UITableViewCell *) getProfileVideos:(MyShoutedCell *) aShoutedCell tableView:(UITableView *)tableView indexPath:(NSIndexPath *)indexPath shoutArray:(NSMutableArray *)shoutArray lastRowShouted:(long)lastRowShouted fromTarget:(UIViewController *)fromTarget isDraft:(BOOL)isDraft;
+ (NSString *) formatBirthdayString:(int)day month:(int)month year:(int)year;
+ (void) updateSingleton: (NSDictionary *) infoDict;
+ (void) registerData: (NSDictionary *) infoDict;
+ (void) removeAllViewLoading:(UIViewController *) controller;
+ (void) loadVideoPreview:(NSArray *)detailsVideoArr playVideoButton:(UIButton *)playVideoButton videoId:(long)videoId frameImageView:(UIImageView *)frameImageView filterImageView:(UIImageView *)filterImageView videoTitle:(UILabel *)videoTitle controller:(UIViewController *)controller videoPlayerView:(UIView *)videoPlayerView birthdayMessageView:(UITextView *)birthdayMessageView;
+ (NSString *) firstLastNameToString:(NSString *)firstName lastName:(NSString *)lastName;
+(float)getMaxHeightOfText:(NSString *)string font:(UIFont *)aFont width:(float)width;
+(NSString *)isNullOrEmpty:(NSString *)inString;
+ (Video *) setNotifVideoData:(NSArray *)videoData ;

@end