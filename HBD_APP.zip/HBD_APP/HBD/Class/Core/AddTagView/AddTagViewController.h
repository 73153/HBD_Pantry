//
//  AddTagViewController.h
//  photobug
//
//  Created by Bhushan on 2/10/16.
//  Copyright © 2016 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface AddTagViewController : UIViewController

- (IBAction)btnOk:(id)sender;

-(void)AllTagMethod;
@property (strong, nonatomic) AppDelegate *delegate;

@property (strong, nonatomic) IBOutlet UITableView *tblTag;
@property (strong, nonatomic) IBOutlet UITextField *txtNewtag;


@end
