//
//  AddTagTableViewCell.m
//  photobug
//
//  Created by Bhushan on 2/10/16.
//  Copyright © 2016 com.zaptechsolution. All rights reserved.
//

#import "AddTagTableViewCell.h"

@implementation AddTagTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
