//
//  AddTagTableViewCell.h
//  photobug
//
//  Created by Bhushan on 2/10/16.
//  Copyright © 2016 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddTagTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *Name;

@end