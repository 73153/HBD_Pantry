//
//  AddTagViewController.m
//  photobug
//
//  Created by Bhushan on 2/10/16.
//  Copyright © 2016 com.zaptechsolution. All rights reserved.
//

#import "AddTagViewController.h"
#import "AddTagTableViewCell.h"
#import "AppDelegate.h"
#import "Social.h"
#import "Constants.h"

@interface AddTagViewController ()
{
    NSArray *arrTagData;
    
    NSMutableArray *checkMarkArray;
    
    NSMutableArray *SelectArray;
}
@end

@implementation AddTagViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _delegate = (AppDelegate*) [[UIApplication sharedApplication] delegate];
    _delegate.selectTagArray = [[NSMutableArray alloc] init];
  _delegate. selectTagNameArray=[[NSMutableArray alloc]init];
    
    [self AllTagMethod];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



-(void)AllTagMethod{
    
      //  [APPDATA showLoader];
    arrTagData =  [Social getFriendList:1000 withOffset:0 byName:YES];
          checkMarkArray=[[NSMutableArray alloc]init];
        _delegate.selectTagArray=[[NSMutableArray alloc]init];
         _delegate. selectTagNameArray=[[NSMutableArray alloc]init];
        
    
        [_tblTag reloadData];
             for (int i=0; i<arrTagData.count; i++)
        {
            [checkMarkArray addObject:@"0"];
        }
    }

#pragma mark table view delegate
-(NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return arrTagData.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableId=@"AddTagTableViewCell";
    AddTagTableViewCell *cell=(AddTagTableViewCell*)[_tblTag dequeueReusableCellWithIdentifier:simpleTableId];
    if (cell == nil) {
        cell = [[AddTagTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableId];
    }
    
   // NSLog(@"%@",[NSString stringWithFormat:@"%@",UDDecode([[arrTagData objectAtIndex:indexPath.row] valueForKey:@"firstName"])]);
    
    cell.Name.text=[NSString stringWithFormat:@"%@", UDDecode([[arrTagData objectAtIndex:indexPath.row] valueForKey:@"firstName"])];
    
    
  //  NSString *checkStr=[NSString stringWithFormat:@"%@",[checkMarkArray objectAtIndex:indexPath.row]];
    
    
   
    
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    
    NSString *checkStr=[NSString stringWithFormat:@"%@",[checkMarkArray objectAtIndex:indexPath.row]];
    
    
    if ([checkStr isEqualToString:@"0"])
    {
        
        
       [checkMarkArray replaceObjectAtIndex: indexPath.row withObject: @"1"];
        
    }else{
        
       [checkMarkArray replaceObjectAtIndex: indexPath.row withObject: @"0"];
    }
    
    
    [_tblTag reloadData];
    
}

- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
   // UITouch *touch = [[event allTouches] anyObject];
    
    //   CGPoint location = [touch locationInView:self.view];
    
    
    
    [self.view removeFromSuperview];
    
    
}



- (IBAction)btnOk:(id)sender {
    
    
    for (int i=0; i<checkMarkArray.count; i++)
    {
        NSString *checkStr=[NSString stringWithFormat:@"%@",[checkMarkArray objectAtIndex:i]];
        
                 if ([checkStr isEqualToString:@"1"])
        {
            [_delegate.selectTagArray addObject:[NSString stringWithFormat:@"%@",[[arrTagData objectAtIndex:i] valueForKey:@"id"]]];
            [_delegate. selectTagNameArray addObject:[NSString stringWithFormat:@"%@",UDDecode([[arrTagData objectAtIndex:i] valueForKey:@"firstName"])]];
        }
        
    }
    
    if ([_txtNewtag.text length]>0)
    {
        [_delegate.selectTagArray addObject:_txtNewtag.text];
        [_delegate. selectTagNameArray addObject:_txtNewtag.text];
    }
    
   // SubmitAnEntryViewController *objSubmitAnEntryViewController=[SubmitAnEntryViewController new];
    
   [[NSNotificationCenter defaultCenter] postNotificationName:@"Message"  object:nil userInfo:nil];
    
    
    
     [self.view removeFromSuperview];
    
    
}
@end
