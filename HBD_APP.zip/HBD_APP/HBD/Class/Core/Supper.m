//
//  Supper.m
//  HBD
//
//  Created by HoanVu on 11/29/14.
//  Copyright (c) 2014 HungHT. All rights reserved.
//

#import "Supper.h"
#import "Constants.h"
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <MobileCoreServices/MobileCoreServices.h>
//#import <FacebookSDK/FacebookSDK.h>
//#import <FacebookSDK/FBDialogs.h>
#import "Commons.h"
#import "AFNetworking.h"
#import "Reachability.h"
//#import "MySingleton.h"

@interface Supper ()

@end

@implementation Supper

- (void)viewDidLoad {
    [super viewDidLoad];
    _aSingleton = [MySingleton getInstance];
    _aShareMethod = [[ShareDelegateController alloc] init];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Get all comment of Video
-(NSArray *) getAllCommentOfVideo:(NSString *)videoId :(int) limit :(int) offset
{
    
    NSMutableArray *aryVIewCOmment=[[NSMutableArray alloc]init];
    
    NSArray *commentArr = [[NSArray alloc] init];
    NSDictionary* jsonDict = [Commons getRequest:[NSString stringWithFormat:@"%@/videos/%@/comments?token=%@&limit=%i&offset=%i",SERVER,videoId,_aSingleton.myToken,100,0]];
    if ((![jsonDict isEqual:[NSNull null]]) && (jsonDict != nil)) {
        int status_code = [[jsonDict objectForKey:@"status_code"] intValue];
        if (status_code == 1) {
            commentArr = [jsonDict objectForKey:@"data"];
           [commentArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
               NSString *str=[[commentArr objectAtIndex:idx] valueForKey:@"message"];
            
               NSData *data = [str dataUsingEncoding:NSUTF8StringEncoding];
               NSString *goodValue = [[NSString alloc] initWithData:data encoding:NSNonLossyASCIIStringEncoding];
               
               [aryVIewCOmment addObject:goodValue];

           }];
            _aSingleton.aryAllComment=[aryVIewCOmment mutableCopy];
            NSLog(@"%@",_aSingleton.aryAllComment);
         

        }
    }
    return commentArr;
}

#pragma mark - Post Comment A Video
-(BOOL) postCommentAVideo:(int) idOfVideo :(NSString *) contentCmt tagedId:(NSString *)tagedId
{
    BOOL value = NO;
    NSString *idVideo = [NSString stringWithFormat:@"%i",idOfVideo];
    NSString *urlStr =  [NSString stringWithFormat:@"%@/videos/%@/comments?token=%@",SERVER,idVideo,_aSingleton.myToken];
    NSString *timeNowStr = [NSString stringWithFormat:@"%f",[[NSDate date] timeIntervalSince1970]];
    NSArray *paramsTitle = [[NSArray alloc] initWithObjects:@"userId",@"videoId",@"message",@"updatedAt",@"taggedfriends", nil];
    NSArray *paramsValue = [[NSArray alloc] initWithObjects:_aSingleton.myId,idVideo,contentCmt ,timeNowStr,tagedId,nil];
    NSDictionary* jsonDict =[NSDictionary dictionaryWithDictionary:[Commons postRequest:urlStr paramsTitle:paramsTitle paramsValue:paramsValue]];
 //   NSArray *dataArr =[NSArray arrayWithArray:[jsonDict valueForKey:@"data"]];
    if(![jsonDict isEqual:[NSNull null]]) {
       
        if ([[jsonDict valueForKey:@"status_code"] intValue] == 1) {
            value = YES;
        }
    }
    return value;
}

#pragma mark - Play Video With Url
-(void) playVideoWithUrl:(NSURL *) url
{
    _theMovie =[[MPMoviePlayerController alloc] initWithContentURL:url];
    _theMovie.controlStyle = MPMovieControlStyleDefault;
    _theMovie.shouldAutoplay = YES;
    [self.view addSubview:_theMovie.view];
    [_theMovie setFullscreen:YES animated:YES];
    [[NSNotificationCenter defaultCenter]
     addObserver: self
     selector: @selector(moviePlayBackDidFinish:)
     name: MPMoviePlayerPlaybackDidFinishNotification
     object: _theMovie];
}

- (void) moviePlayBackDidFinish:(NSNotification*)notification
{
    MPMoviePlayerController *videoplayer = [notification object];
    [[NSNotificationCenter defaultCenter]
     removeObserver:self
     name:MPMoviePlayerPlaybackDidFinishNotification
     object:videoplayer];
    if ([videoplayer respondsToSelector:@selector(setFullscreen:animated:)]) {
        [videoplayer.view removeFromSuperview];
    }
}

-(void) myMovieFinishedCallback: (NSNotification*) aNotification
{
    [self dismissMoviePlayerViewControllerAnimated];
    _theMovie = [aNotification object];
    [[NSNotificationCenter defaultCenter]
     removeObserver: self
     name: MPMoviePlayerPlaybackDidFinishNotification
     object: _theMovie];
}

#pragma mark - USER - FRIEND
-(NSArray *) getDataUser:(NSString *)idUser
{
    NSArray *dataArr = [[NSArray alloc] init];
    NSDictionary* jsonDict = [Commons getRequest:[NSString stringWithFormat:@"%@/users/%@?token=%@",SERVER,idUser,_aSingleton.myToken]];
    if (![jsonDict isEqual:[NSNull null]]) {
        if ([[jsonDict objectForKey:@"status_code"] intValue] == 1)
            dataArr = [jsonDict objectForKey:@"data"];
    }
    return dataArr;
}

- (NSDictionary *) getMyData
{
    NSDictionary *dataArr = [[NSDictionary alloc] init];
    NSDictionary* jsonDict = [Commons getRequest:[NSString stringWithFormat:@"%@/users/me?token=%@",SERVER,_aSingleton.myToken]];
    if (![jsonDict isEqual:[NSNull null]]) {
        if ([[jsonDict objectForKey:@"status_code"] intValue] == 1) {
            dataArr = [jsonDict objectForKey:@"data"];
        }
    }
    return dataArr;
}

#pragma mark - Response Request Friend
- (int) checkFriendStatus:(NSString *)idPartner
{
    int value = 0;
    NSDictionary* jsonDict = [Commons getRequest:[NSString stringWithFormat:@"%@/friend-request/%@/checkstatus?token=%@",SERVER,idPartner,_aSingleton.myToken]];
    value = [[[jsonDict objectForKey:@"data"] objectForKey:@"status"] intValue];
    return value;
}

#pragma mark - Response Request Friend
- (BOOL) acceptRequestFriend:(NSString *)idPartner
{
    BOOL value = NO;
    NSDictionary* jsonDict = [Commons getRequest:[NSString stringWithFormat:@"%@/friend-request/%@/accept?token=%@",SERVER,idPartner,_aSingleton.myToken]];
    if ([[jsonDict objectForKey:@"status_code"] intValue] == 1) {
        value = YES;
        _aSingleton.UpdateRight = YES;
    }
    return value;
}

#pragma mark - Send link video to friend's email
-(void) sendLinkVideoToFriendEmail: (NSString *)email : (NSString *)idVideo
{
    NSString *urlStr =  [NSString stringWithFormat:@"%@/videos/%@/send?token=%@",SERVER,idVideo,_aSingleton.myToken];
    NSArray *paramsTitle = [[NSArray alloc] initWithObjects:@"email",nil];
    NSArray *paramsValue = [[NSArray alloc] initWithObjects:email, nil];
    NSDictionary* jsonDict = [Commons postRequest:urlStr paramsTitle:paramsTitle paramsValue:paramsValue];
    NSLog(@"jsonDict sendLink: %@",jsonDict);
}

#pragma mark - giveColorfromStringColor
-(UIColor *)giveColorfromStringColor:(NSString *)colorname
{
    SEL labelColor = NSSelectorFromString(colorname);
    UIColor *color = nil;
    if ([UIColor respondsToSelector: labelColor])
        color  = [UIColor performSelector:labelColor];
    return color;
}

- (void) checkNewPass:(UITextField *)pass reNewPass:(UITextField *)reNewPass
{
    if ([pass.text length] == 0) {
        UIAlertView *aAlertView = [[UIAlertView alloc] initWithTitle:@"Please enter a new password" message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [aAlertView show];
    }else{
        NSString *pass1 =[Commons isNullOrEmpty:pass.text];
        NSString *pass2 = [Commons isNullOrEmpty:reNewPass.text];
        if ([pass1 isEqualToString:pass2]) {
            [self changePassWordWithAFNet:pass reNewPass:reNewPass];
        }else{
            UIAlertView *aAlertView = [[UIAlertView alloc] initWithTitle:@"Make sure your passwords match" message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
            [aAlertView show];
        }
    }
}

#pragma mark - Changer Password
- (void) changePassWordWithAFNet:(UITextField *)pass reNewPass:(UITextField *)reNewPass
{
    [Commons addViewLoading:self];
   
        NSString *urlStr =  [NSString stringWithFormat:@"%@/users/password?token=%@",SERVER,_aSingleton.myToken];
        NSURL *url = [NSURL URLWithString:urlStr];
        NSLog(@"url: %@",url);
        NSString *newPassWord = reNewPass.text;
        AFHTTPRequestOperationManager *manager = [Commons getManager];
        [manager PUT:urlStr parameters:@{@"password":newPassWord}
             success:^(AFHTTPRequestOperation *operation, id responseObject) {
                 NSLog(@"Complete");
                 NSLog(@"responseObject Change Password : %@",responseObject);
                 dispatch_async(dispatch_get_main_queue(), ^{
                     pass.text = nil;
                     reNewPass.text = nil;
                     [Commons removeAllViewLoading:self];
                     UIAlertView *aAlertView = [[UIAlertView alloc] initWithTitle:@"Password changed successfully!" message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
                     aAlertView.tag = 101 ;
                     [aAlertView show];
                 });
             } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                 NSLog(@"failure Error : %@",error);
                 dispatch_async(dispatch_get_main_queue(), ^{
                     pass.text = nil;
                     reNewPass.text = nil;
                     [Commons removeAllViewLoading:self];
                     UIAlertView *aAlertView = [[UIAlertView alloc] initWithTitle:@"Password change failed, please try again" message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
                     aAlertView.tag = 102 ;
                     [aAlertView show];
                 });
             }
         ];
}

#pragma mark - Parse A Notification
-(NSString *) parseANotification:(NSMutableArray *)notificationList
{
    NSString *aNotificationContent = [[NSString alloc] init];
    NSArray *aNofification = [notificationList objectAtIndex:notificationList.count - 1];
    if (aNofification.count > 0) {
        NSString *firstNameSender;
        NSString *lastNameSender;
        NSString *nameSender;
        if((![[aNofification valueForKey:@"user"] isEqual:[NSNull null]]) && ([aNofification valueForKey:@"user"] != nil))
        {
        firstNameSender  = [Commons isNullOrEmpty:UDDecode([[aNofification valueForKey:@"user"] valueForKey:@"firstName"])];
       lastNameSender = [Commons isNullOrEmpty:UDDecode([[aNofification valueForKey:@"user"] valueForKey:@"lastName"])];
       nameSender =[Commons isNullOrEmpty: [NSString stringWithFormat:@"%@ %@",firstNameSender, lastNameSender]];
        }else
        {
            nameSender=@"";
        }
        
 
    NSString *type = [Commons isNullOrEmpty:[aNofification valueForKey:@"type"]];
    if ([type isEqualToString:@"friend-acc"]) {
        aNotificationContent = [NSString stringWithFormat:@"%@<b>%@</b> accepted your friend request</span>",[Commons getFontStyle],nameSender];
    }
    if (([type isEqualToString:@"friend-req"])||([type isEqualToString:@"request"])) {
        aNotificationContent = [NSString stringWithFormat:@"%@<b>%@</b> sent you a friend request</span>",[Commons getFontStyle],nameSender];
    }
    if ([type isEqualToString:@"video"]) {
        aNotificationContent = [NSString stringWithFormat:@"%@<b>%@</b> sent you a hbd shout out</span>",[Commons getFontStyle],nameSender];
    }
    if ([type isEqualToString:@"purchase"]) {
        NSString *itemName =[Commons isNullOrEmpty:[[aNofification valueForKey:@"purchaseItem"] valueForKey:@"item"]];
        NSLog(@"itemName: %@",itemName);
        aNotificationContent = [NSString stringWithFormat:@"%@<b>%@</b> bought you a gift</span>",[Commons getFontStyle],nameSender];
        if (itemName != nil) {
            aNotificationContent = [NSString stringWithFormat:@"%@<b>%@</b> bought you <b>%@</b> gift</span>",[Commons getFontStyle],nameSender,itemName];
        }
    }
    if ([type isEqualToString:@"wishlist"]) {
        aNotificationContent = [NSString stringWithFormat:@"%@<b>%@</b> updated their wishlist</span>",[Commons getFontStyle],nameSender];
    }
    if ([type isEqualToString:@"like"]) {
        aNotificationContent = [NSString stringWithFormat:@"%@<b>%@</b> likes your video</span>",[Commons getFontStyle],nameSender];
    }
    if ([type isEqualToString:@"comment"]) {
        aNotificationContent = [NSString stringWithFormat:@"%@<b>%@</b> commented on your video</span>",[Commons getFontStyle],nameSender];
    }
    if ([type isEqualToString:@"commentTag"]) {
        aNotificationContent = [NSString stringWithFormat:@"%@<b>%@</b> tagged you in a comment of a video</span>",[Commons getFontStyle],nameSender];
    }
    if ([type isEqualToString:@"tag"]) {
        aNotificationContent = [NSString stringWithFormat:@"%@<b>%@</b> tagged you in a video</span>",[Commons getFontStyle],nameSender];
    }
    if ([type isEqualToString:@"reminder0"]) {

        NSString *str1=[NSString stringWithFormat:@"%@it's <b>%@</b> birthday today! \\ud83c\\udf89 Send a Shout Out \\ud83d\\udcf9,and check out their Wishlist! \\ud83c\\udf81</span>",[Commons getFontStyle],nameSender];
        
        aNotificationContent = UDDecode(str1);
    }
    if ([type isEqualToString:@"reminder1"]) {
        NSString *str1=[NSString stringWithFormat:@"%@BOOM!! <b>%@</b> bday is tomorrow.Get those thinking caps on for an epic shoutout!!\\ud83c\\udf89 \\ud83e\\udd14 #HBD</span>",[Commons getFontStyle],nameSender];
        aNotificationContent = UDDecode(str1);
    }
    if ([type isEqualToString:@"reminder7"]) {
        NSString *str1=[NSString stringWithFormat:@"%@BOOM!! <b>%@</b> bday is coming up.Get those thinking caps on for an epic shoutout!!\\ud83c\\udf89 \\ud83e\\udd14 #HBD</span>",[Commons getFontStyle],nameSender];
        aNotificationContent = UDDecode(str1);
    }
    if ([type isEqualToString:@"reminder14"]) {
        NSString *emoji1=UDDecode(@"\\u1f389");
        NSString *str1=[NSString stringWithFormat:@"%@BOOM!! <b>%@</b> bday is coming up.Get those thinking caps on for an epic shoutout!! %@ \\ud83c\\udf89 \\ud83e\\udd14 #HBD</span>",[Commons getFontStyle],nameSender,emoji1];
        aNotificationContent = UDDecode(str1);
    }
    }
    return aNotificationContent;
}

- (BOOL) checkConnection
{
    BOOL aValue;
    Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
    if (networkStatus == NotReachable) {
        NSLog(@"There IS NO internet connection");
        aValue = NO;
    } else {
        NSLog(@"There IS internet connection");
        aValue = YES;
    }
    return aValue;
}
@end
