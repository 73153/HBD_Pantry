

//
//  Commons.m
//  HBD
//
//  Created by Max Stein on 1/26/15.
//  Copyright (c) 2015 HungHT. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Commons.h"
#import "AppDelegate.h"
#import "MBProgressHUD.h"
#import "UIImageView+WebCache.h"
#import "ProfileViewController.h"
#import "Constants.h"
@implementation Commons

static UIView *connectingView;
static ShareDelegateController *shareMethod;
static NSArray *months;
static MySingleton *singleton;
static NSDictionary *userDict;
static AppDelegate *appDelegate;
static Supper *supper;

+ (void) initialize {
    shareMethod = [[ShareDelegateController alloc] init];
    months = [NSArray arrayWithObjects: @"January", @"January", @"February", @"March", @"April", @"May", @"June", @"July", @"August", @"September", @"October", @"November", @"December", nil];
    singleton = [MySingleton getInstance];
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
}

#pragma mark - Add - hide View Loading
+ (void) addViewLoading:(UIViewController*)controller
{
    [self showViewLoadingMBProgressHUB:controller contentStr:@"Connecting"];
}

+ (void) addViewLoadingWithContent:(UIViewController*)controller str:(NSString *)contentStr
{
    [self showViewLoadingMBProgressHUB:controller contentStr:contentStr];
}

+ (void) showViewLoadingMBProgressHUB:(UIViewController *) controller contentStr:(NSString *)contentStr
{
    connectingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, [[UIScreen mainScreen] bounds].size.width,[[UIScreen mainScreen] bounds].size.height)];
    [connectingView setBackgroundColor:[UIColor grayColor]];
    [connectingView setAlpha:0.8];
    MBProgressHUD * HUD;
    HUD = [[MBProgressHUD alloc] initWithFrame:CGRectMake(connectingView.frame.size.width/2 - 100, connectingView.frame.size.height / 2 - 100, 200, 200)];
    HUD.mode = MBProgressHUDAnimationFade;
    [HUD setAlpha:1.0];
    HUD.labelText = contentStr;
    [HUD show:YES];
    [connectingView addSubview:HUD];
    connectingView.tag = 17;
    
        [controller.view addSubview:connectingView];
    
}

+ (void) removeAllViewLoading:(UIViewController *) controller
{
    for (UIView *subView in controller.view.subviews) {
        if (subView.tag == 17) {
            [subView removeFromSuperview];
        }
    }
}

+ (UIColor *) colorWithHexString:(NSString*)hex
{
    NSString *cString = [[hex stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    if ([cString length] < 6) return [UIColor grayColor];
    if ([cString hasPrefix:@"0X"]) cString = [cString substringFromIndex:2];
    if ([cString length] != 6) return  [UIColor grayColor];
    NSRange range;
    range.location = 0;
    range.length = 2;
    NSString *rString = [cString substringWithRange:range];
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    return [UIColor colorWithRed:((float) r / 255.0f)
                           green:((float) g / 255.0f)
                            blue:((float) b / 255.0f)
                           alpha:1.0f];
}

#pragma mark - Get Short Month String
+ (NSString *) getShortMonthString :(NSInteger) month
{
    NSString *monthStr = months[month];
    monthStr = [monthStr substringToIndex:3];
    return monthStr;
}

#pragma mark - Get month-string by month intvalue
+ (NSString *) getMonthString :(NSInteger) month
{
    NSString *monthStr = months[month];
    return monthStr;
}

#pragma mark - Get Day Format from nsdate
+ (NSString *) GetDayFormatFromDate:(NSString *) aDate
{
    NSString *day1 = [aDate substringWithRange:NSMakeRange(8, 2)];
    NSString *month1 = [aDate substringWithRange:NSMakeRange(5, 2)];
    NSString *monthStr = months[[month1 intValue]];
    int day = [[aDate substringWithRange:NSMakeRange(8, 2)] intValue];
    NSString *birthdateDisplay = [NSString stringWithFormat:@"%@ %@",monthStr, [self formatDate:day]];
 //   NSLog(@"monthStr = %@ day = %@ ",monthStr, day1);
    if ([monthStr isEqual:[NSNull null]])
        birthdateDisplay = @"N/A";
    return birthdateDisplay;
}

+ (NSString *) formatDate:(int) day
{
    if (day == 1 || day == 21 || day == 31) {
        return [NSString stringWithFormat:@"%dst",day];
    } else if (day == 2 || day == 22) {
        return [NSString stringWithFormat:@"%dnd",day];
    } else if (day == 3 || day == 23) {
        return [NSString stringWithFormat:@"%drd",day];
    } else {
        return [NSString stringWithFormat:@"%dth",day];
    }
}

+ (int) getZodiacTag:(long)month day:(long)day
{
    if ((month == 1 && day >=20)|| (month == 2 && day <=18)) {
        return 0;
    } else if ((month == 2 && day >=19)|| (month == 3 && day <=20)) {
        return 1;
    } else if ((month == 3 && day >=21)|| (month == 4 && day <=19)) {
        return 2;
    } else if ((month == 4 && day >=20)|| (month == 5 && day <=20)) {
        return 3;
    } else if ((month == 5 && day >=21)|| (month == 6 && day <=21)) {
        return 4;
    } else if ((month == 6 && day >=22)|| (month == 7 && day <=22)) {
        return 5;
    } else if ((month == 7 && day >=23)|| (month == 8 && day <=22)) {
        return 6;
    } else if ((month == 8 && day >=23)|| (month == 9 && day <=22)) {
        return 7;
    } else if ((month == 9 && day >=23)|| (month == 10 && day <=22)) {
        return 8;
    } else if ((month == 10 && day >=23)|| (month == 11 && day <=21)) {
        return 9;
    } else if ((month == 11 && day >=22)|| (month == 12 && day <=21)) {
        return 10;
    } else if ((month == 12 && day >=22)|| (month == 1 && day <=19)) {
        return 11;
    } else {
        return 0;
    }
}

#pragma mark - Login MEthod
+ (BOOL) loginMethod:(UITextField *)emailTextField passWordTextField:(UITextField *)passwordTextField
{
    BOOL didLogin = false;
    NSArray *paramsTitle = @[@"email",@"password",@"deviceToken"];
    NSString *email = [emailTextField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSString *password = passwordTextField.text;
    NSArray *paramsValue = @[email,password,singleton.deviceToken];
    NSDictionary* jsonDict = [Commons postRequest:[NSString stringWithFormat:@"%@/login",SERVER] paramsTitle:paramsTitle paramsValue:paramsValue];
    if (![jsonDict isEqual:[NSNull null]]) {
        int status_code = [[jsonDict objectForKey:@"status_code"] intValue];
        if (status_code == 1) {
            userDict = [jsonDict objectForKey:@"data"];
    //        NSLog(@"userDict= %@",userDict);
            if ([userDict objectForKey:@"token"] == nil) {
                UIAlertView * aAlertView = [[UIAlertView alloc] initWithTitle:@"Can't login" message:@"Please try again later" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                [aAlertView show];
            } else {
                [self setSingletonOnLogin:0 withDict:userDict];
                didLogin = true;
            }
        }
        if (status_code == 0) {
            dispatch_async(dispatch_get_main_queue(), ^{
                UIAlertView * aAlertView = [[UIAlertView alloc] initWithTitle:@"Invalid email or password" message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                [aAlertView show];
            });
        }
    }
    return didLogin;
}


+ (void) setSingletonOnLogin:(int)isFacebook withDict:(NSDictionary *)loginDict
{
    singleton.myToken = [loginDict objectForKey:@"token"];
    [self updateSingleton:loginDict];
    [appDelegate saveToCoreData:singleton.myId :singleton.myEmail :singleton.firstName :singleton.lastName :singleton.myAvatar :isFacebook];
    [appDelegate GetListFriend];
}

+ (void) updateSingleton: (NSDictionary *) infoDict
{
    [self registerData:infoDict];
    singleton.ntfWishlistUpdate = [[infoDict objectForKey:@"ntfWishlistUpdate"] intValue];
    singleton.ntfShoutCmt = [[infoDict objectForKey:@"ntfShoutCmt"] intValue];
    singleton.ntfShoutLike = [[infoDict objectForKey:@"ntfShoutLike"] intValue];
    singleton.ntfShoutTag = [[infoDict objectForKey:@"ntfShoutTag"] intValue];
    singleton.sentToEmail = [[infoDict objectForKey:@"sentToEmail"] intValue];
    singleton.sentToFacebook = [[infoDict objectForKey:@"sentToFacebook"] intValue];
    singleton.sentToTwitter = [[infoDict objectForKey:@"sentToTwitter"] intValue];
    singleton.isPublic = [[infoDict objectForKey:@"isPublic"] intValue];
}

+ (void) registerData: (NSDictionary *) infoDict
{
    singleton.myId = [infoDict objectForKey:@"id"];
    singleton.myEmail = [infoDict objectForKey:@"email"];
    singleton.firstName = UDDecode([infoDict objectForKey:@"firstName"]);
    singleton.lastName = UDDecode([infoDict objectForKey:@"lastName"]);
    singleton.myUsername = [NSString stringWithFormat:@"%@ %@",singleton.firstName,singleton.lastName];
    singleton.myAvatar = [infoDict objectForKey:@"avatar"];
    NSString *timeComingStr = [infoDict objectForKey:@"timeUpcoming"];
    if(([timeComingStr isEqual:[NSNull null]]))
        timeComingStr = @"0";
    else
        timeComingStr = [infoDict objectForKey:@"timeUpcoming"];
    singleton.timeUpcoming = [timeComingStr intValue];
}

+ (void) roundCorners:(NSArray *)layers
{
    for(int i = 0; i < [layers count]; i++) {
        [(CALayer *)layers[i] setCornerRadius: 15];
    }
}

+ (void) setCheckBackgroundImage:(UIButton *)button type:(int)type
{
    if (type == 0) 
        [button setBackgroundImage:[UIImage imageNamed:[NSString stringWithFormat:@"checkbox-unselected"]] forState:UIControlStateNormal];
    else
        [button setBackgroundImage:[UIImage imageNamed:[NSString stringWithFormat:@"checkbox-selected"]] forState:UIControlStateNormal];
}

+ (int) switchValue:(int)value {
    value++;
    if (value %2 == 1) {
        value = 1;
    } else {
        value = 0;
    }
    return value;
}

+ (NSString *) getFontStyle
{
    return @"<span style=\"font-family: Open Sans; font-size: 11\">";
}

+ (NSString *) getFontWithSize:(NSString *)fontSize
{
    return [NSString stringWithFormat:@"<span style=\"font-family: HelveticaNeue; font-size: %@\">", fontSize];
}

+ (NSArray *) getUsersWishlist:(NSString *)userId
{
    NSString *urlStr =  [NSString stringWithFormat:@"%@/users/%@/wishlist?token=%@",SERVER,userId,singleton.myToken];
    NSURL *url = [NSURL URLWithString:urlStr];
    NSData *responseData;
    responseData = [shareMethod getDataFromUrl:url];
    if (responseData != nil) {
 //       NSLog(@"Get data complete");
        NSError *error;
        NSDictionary* jsonDict = [NSJSONSerialization JSONObjectWithData:responseData options:kNilOptions error:&error];
 //       NSLog(@"jsonDict: %@",jsonDict);
        if (![jsonDict isEqual:[NSNull null]]) {
            int status_code = [[jsonDict objectForKey:@"status_code"] intValue];
            if (status_code == 1) {
                return [jsonDict objectForKey:@"data"];
            }
        }
    }
    return nil;
}

+ (float)getMaxHeightOfText:(NSString *)string font:(UIFont *)aFont width:(float)width {
    CGSize  textSize = { width, CGFLOAT_MAX };
    CGRect rect = [string boundingRectWithSize:textSize options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName:aFont} context:nil];
    return rect.size.height;
}


+ (void) setUpButton:(UIButton *)buttonName tagValue:(NSInteger)tagValue withSelector:(SEL)selectorName withController:(UIViewController *)controller
{
    buttonName.tag = tagValue;
    [buttonName addTarget:controller action:selectorName forControlEvents:UIControlEventTouchUpInside];
}

+ (NSDictionary *) getRequest:(NSString *)urlString
{
    NSDictionary *jsonDict = nil;
    NSURL *url = [NSURL URLWithString:urlString];
    NSData *responseData = [shareMethod getDataFromUrl:url];
    
    if (responseData != nil)
        jsonDict = [NSJSONSerialization JSONObjectWithData:responseData options:kNilOptions error:nil];
    [self checkCantConnect:jsonDict];
    return jsonDict;
}

+ (NSDictionary *) deleteRequest:(NSString *)urlString
{
    NSDictionary *jsonDict = nil;
    NSURL *url = [NSURL URLWithString:urlString];
    NSData *responseData = [shareMethod deleteFromUrl:url];
    if (responseData != nil)
        jsonDict = [NSJSONSerialization JSONObjectWithData:responseData options:kNilOptions error:nil];
    [self checkCantConnect:jsonDict];
    return jsonDict;
}

+ (NSDictionary *) postRequest:(NSString *)urlString paramsTitle:(NSArray *)paramsTitle paramsValue:(NSArray *)paramsValue
{
    NSDictionary *jsonDict = nil;
    NSURL *url = [NSURL URLWithString:urlString];
    NSData *responseData = [shareMethod postDataTo:url :paramsTitle :paramsValue];
    if (responseData != nil)
        jsonDict = [NSJSONSerialization JSONObjectWithData:responseData options:kNilOptions error:nil];
    [self checkCantConnect:jsonDict];
    return jsonDict;
}

+ (void) checkCantConnect:(NSDictionary *)jsonDict
{
    if ([jsonDict isEqual:[NSNull null]]) {
        UIAlertView * aAlertView = [[UIAlertView alloc] initWithTitle:@"Can't connect to server" message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [aAlertView show];
    }
}

+ (AFHTTPRequestOperationManager *) getManager
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
    manager.securityPolicy.allowInvalidCertificates = YES;
    return manager;
}

+ (void) showAlert:(NSString *)alertText
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:alertText message:nil delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
    [alert show];
}

+ (Video *) setVideoData:(NSArray *)videoData
{
    Video *aVideo = [[Video alloc] init];
    aVideo.title = UDDecode([[videoData valueForKey:@"video"] valueForKey:@"title"]);
    aVideo.titleStyle = [[videoData valueForKey:@"video"] valueForKey:@"titleStyle"];
    aVideo.titleColor = [[videoData valueForKey:@"video"] valueForKey:@"titleColor"];
    aVideo.descriptions = UDDecode([[videoData valueForKey:@"video"] valueForKey:@"description"]);
    aVideo.descriptionStyle = [[videoData valueForKey:@"video"] valueForKey:@"descriptionStyle"];
    aVideo.descriptionColor = [[videoData valueForKey:@"video"] valueForKey:@"descriptionColor"];
    aVideo.frame = [NSString stringWithFormat:@"%@/%@",SERVER_PIC,[[videoData valueForKey:@"video"] valueForKey:@"frame"]];
    aVideo.filter = [NSString stringWithFormat:@"%@/%@",SERVER_PIC,[[videoData valueForKey:@"video"] valueForKey:@"filter"]];
    aVideo.url = [[videoData valueForKey:@"video"] valueForKey:@"path"];
    return aVideo;
}

+ (Video *) setNotifVideoData:(NSArray *)videoData
{
    Video *aVideo = [[Video alloc] init];
    aVideo.title = UDDecode([[videoData valueForKey:@"object"] valueForKey:@"title"]);
    aVideo.titleStyle = [[videoData valueForKey:@"object"] valueForKey:@"titleStyle"];
    aVideo.titleColor = [[videoData valueForKey:@"object"] valueForKey:@"titleColor"];
    aVideo.descriptions = UDDecode([[videoData valueForKey:@"object"] valueForKey:@"description"]);
    aVideo.descriptionStyle = [[videoData valueForKey:@"object"] valueForKey:@"descriptionStyle"];
    aVideo.descriptionColor = [[videoData valueForKey:@"object"] valueForKey:@"descriptionColor"];
    aVideo.frame = [NSString stringWithFormat:@"%@/%@",SERVER_PIC,[[videoData valueForKey:@"object"] valueForKey:@"frame"]];
    aVideo.filter = [NSString stringWithFormat:@"%@/%@",SERVER_PIC,[[videoData valueForKey:@"object"] valueForKey:@"filter"]];
    aVideo.url = [[videoData valueForKey:@"object"] valueForKey:@"url"];
    return aVideo;
}


+ (UITableViewCell *) getProfileVideos:(MyShoutedCell *) aShoutedCell tableView:(UITableView *)tableView indexPath:(NSIndexPath *)indexPath shoutArray:(NSMutableArray *)shoutArray lastRowShouted:(long)lastRowShouted fromTarget:(UIViewController *)fromTarget isDraft:(BOOL)isDraft
{

    SEL theSelector;
    if (isDraft)
        theSelector = @selector(previewMyDraft:);
    else
        theSelector = @selector(preViewVideoAtIndexFromMyShouted:);
    
    NSString *simpleTableIdentifier = [NSString stringWithFormat:@"%ld %ld",(long)indexPath.section,(long)indexPath.row];
    aShoutedCell = (MyShoutedCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (aShoutedCell == nil)
    {
        [tableView registerNib:[UINib nibWithNibName:@"MyShoutedCell" bundle:nil] forCellReuseIdentifier:simpleTableIdentifier];
        aShoutedCell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        
        aShoutedCell.imageView1.tag = indexPath.row *2 + 0;
        aShoutedCell.imageView2.tag = indexPath.row *2 + 1;
        if (shoutArray && shoutArray.count) {
            [Commons setUpButton:aShoutedCell.playBtn1 tagValue:indexPath.row *2 + 0 withSelector:theSelector withController:fromTarget];
            [Commons setUpButton:aShoutedCell.playBtn2 tagValue:indexPath.row *2 + 1 withSelector:theSelector withController:fromTarget];
            [aShoutedCell.playBtn1 setHidden:NO];
            [aShoutedCell.playBtn2 setHidden:NO];
            [aShoutedCell.imageView1 setHidden:NO];
            [aShoutedCell.imageView2 setHidden:NO];

    }
    }
    else {
        [aShoutedCell.playBtn1 setHidden:NO];
        [aShoutedCell.playBtn2 setHidden:NO];
        [aShoutedCell.imageView1 setHidden:NO];
        [aShoutedCell.imageView2 setHidden:NO];
    }
    
    if (indexPath.row == lastRowShouted) {
        long shoutArrayCount = shoutArray.count % 2;
        if (shoutArrayCount == 0) {
            [aShoutedCell.playBtn1 setHidden:NO];
            [aShoutedCell.playBtn2 setHidden:NO];
            [aShoutedCell.imageView1 setHidden:NO];
            [aShoutedCell.imageView2 setHidden:NO];

            [self setThumbnail:aShoutedCell.imageView1 withArray:shoutArray isDraft:isDraft];
            [self setThumbnail:aShoutedCell.imageView2 withArray:shoutArray isDraft:isDraft];

        } else if (shoutArrayCount == 1) {
            [aShoutedCell.playBtn1 setHidden:NO];
            [aShoutedCell.playBtn2 setHidden:YES];
            [aShoutedCell.imageView1 setHidden:NO];
            [aShoutedCell.imageView2 setHidden:YES];
            [self setThumbnail:aShoutedCell.imageView1 withArray:shoutArray isDraft:isDraft];

        }
    }
    else{
        [aShoutedCell.playBtn1 setHidden:NO];
        [aShoutedCell.playBtn2 setHidden:NO];
        [aShoutedCell.imageView1 setHidden:NO];
        [aShoutedCell.imageView2 setHidden:NO];

        [self setThumbnail:aShoutedCell.imageView1 withArray:shoutArray isDraft:isDraft];
        [self setThumbnail:aShoutedCell.imageView2 withArray:shoutArray isDraft:isDraft];
    }
    
    [aShoutedCell.playBtn1 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"play-icon"]] forState:UIControlStateNormal];
    [aShoutedCell.playBtn2 setImage:[UIImage imageNamed:[NSString stringWithFormat:@"play-icon"]] forState:UIControlStateNormal];
    [aShoutedCell bringSubviewToFront:aShoutedCell.playBtn1];
    [aShoutedCell.playBtn1 setHidden:NO];

    return (UITableViewCell *)aShoutedCell;
}

+ (void) setThumbnail:(UIImageView *)imageName withArray:(NSMutableArray *)shoutArray isDraft:(BOOL)isDraft
{
    if (imageName.tag  < shoutArray.count) {
        if (isDraft == NO) {
            
            NSArray *subArr = [shoutArray objectAtIndex:imageName.tag];
            NSString *str1=[subArr valueForKey:@"filter"];
            if (![str1 isKindOfClass:[NSNull class]]) {
                NSURL *url=[NSURL URLWithString:[subArr valueForKey:@"filter"]];
                
                NSString *str=[url absoluteString];
                [str stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
                
                NSURL *filterUrlVideo=[NSURL URLWithString:str];
                
                [imageName sd_setImageWithURL:filterUrlVideo placeholderImage:[UIImage imageNamed:@"placeholderimg"]];
            }
            
          
        } else {
            NSURL *urlVideo2 = [NSURL URLWithString:[NSString stringWithFormat:@"%@",[shoutArray objectAtIndex:imageName.tag]]];
            AVURLAsset *asset2 = [[AVURLAsset alloc] initWithURL:urlVideo2 options:nil];
            AVAssetImageGenerator *generate2 = [[AVAssetImageGenerator alloc] initWithAsset:asset2];
            generate2.appliesPreferredTrackTransform = YES;
            NSError *err2 = NULL;
            CMTime time2 = CMTimeMake(0, 1);
            CGImageRef oneRef2 = [generate2 copyCGImageAtTime:time2 actualTime:NULL error:&err2];
            UIImage *one2 = [[UIImage alloc] initWithCGImage:oneRef2];
            [imageName setImage:one2];
        }
    }
}

+ (NSString *) formatBirthdayString:(int)day month:(int)month year:(int)year
{
    NSString *dayStr = [NSString stringWithFormat:@"%i",day];
    if (day < 10) {
        dayStr = [NSString stringWithFormat:@"0%i",day];
    }
    NSString *monthStr = [NSString stringWithFormat:@"%i",month];
    if (month < 10) {
        monthStr = [NSString stringWithFormat:@"0%i",month];
    }
    NSString *yearStr = [NSString stringWithFormat:@"%i",year];
    if (year < 10) {
        yearStr = [NSString stringWithFormat:@"0%i",year];
    }
    return [NSString stringWithFormat:@"%@-%@-%@",yearStr,monthStr,dayStr];
}

+ (void) loadVideoPreview:(NSArray *)detailsVideoArr playVideoButton:(UIButton *)playVideoButton videoId:(long)videoId frameImageView:(UIImageView *)frameImageView filterImageView:(UIImageView *)filterImageView videoTitle:(UILabel *)videoTitle controller:(UIViewController *)controller videoPlayerView:(UIView *)videoPlayerView birthdayMessageView:(UITextView *)birthdayMessageView
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        playVideoButton.tag = videoId;
        NSString *titleStyle = [self isNullOrEmpty:[detailsVideoArr valueForKey:@"titleStyle"]];
        NSString *titleColor = [self isNullOrEmpty:[detailsVideoArr valueForKey:@"titleColor"]];
        NSString *strFrameUrl = [self isNullOrEmpty:[detailsVideoArr valueForKey:@"frame"]];
        
        NSString *strFilterUrl = [self isNullOrEmpty:[detailsVideoArr valueForKey:@"filter"]];

        NSURL *frameUrl = [NSURL URLWithString:[strFrameUrl stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]];
        NSURL *filterUrl = [NSURL URLWithString:[strFilterUrl stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]];

        //NSURL *filterUrl = [NSURL URLWithString:[[detailsVideoArr valueForKey:@"filter"] stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]];
        [frameImageView sd_setImageWithURL:frameUrl
                                    placeholderImage:[UIImage imageNamed:@"placeholderimg"]];
        [filterImageView sd_setImageWithURL:filterUrl
                                     placeholderImage:[UIImage imageNamed:@"placeholderimg"]];
        dispatch_async(dispatch_get_main_queue(), ^{
            videoTitle.text = [self isNullOrEmpty:[detailsVideoArr valueForKey:@"title"]];
            if (![titleColor isEqual:[NSNull null]]) {
                NSString *tempColor = [titleColor stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
                UIColor *titleColorValue = [supper giveColorfromStringColor:[NSString stringWithFormat:@"%@Color",[tempColor lowercaseString]]];
                [videoTitle setTextColor:titleColorValue];
            }
            if (![titleStyle isEqual:[NSNull null]])
                [videoTitle setFont:[UIFont fontWithName:titleStyle size:30]];
            birthdayMessageView.text = [detailsVideoArr valueForKey:@"description"];
            if (![[detailsVideoArr valueForKey:@"descriptionColor"] isEqual:[NSNull null]]) {
                NSString *tempColor = [titleColor stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
                UIColor *titleColorValue = [supper giveColorfromStringColor:[NSString stringWithFormat:@"%@Color",[tempColor lowercaseString]]];
                [birthdayMessageView setTextColor:titleColorValue];
            }
            if (![titleStyle isEqual:[NSNull null]])
                [birthdayMessageView setFont:[UIFont fontWithName:titleStyle size:17]];
            for (UIView *aView in videoPlayerView.subviews)
                [aView removeFromSuperview];
           // [Commons addViewLoading:controller];
        });
    });
}

+(NSString *)isNullOrEmpty:(NSString *)inString

{
    
    NSString *strText = @"";
    
    if ([inString isKindOfClass:[NSNull class]]) {
        
        return strText;
        
    }
    
    if (inString == nil || inString == (id)[NSNull null]||[inString isEqualToString:@""] || [inString isEqualToString:@"<null>"] || [inString isEqualToString:@"(null)"] || [inString isEqualToString:@"(null) (null)"]) {
        
        // nil branch
        
        return strText;
        
    } else {
        
        return inString;
        
    }
    
    return nil;
    
}


+ (NSString *) firstLastNameToString:(NSString *)firstName lastName:(NSString *)lastName
{
    return [NSString stringWithFormat:@"%@ %@", firstName, lastName];
}

@end
