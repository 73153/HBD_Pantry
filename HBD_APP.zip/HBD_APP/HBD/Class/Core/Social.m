//
//  Sharer.m
//  HBD
//
//  Created by Max Stein on 1/22/15.
//  Copyright (c) 2015 HungHT. All rights reserved.
//

#import "Social.h"
#import "Commons.h"
#import "UserProfileController.h"
#import "MySingleton.h"
#import "RightViewController.h"
#import "AppDelegate.h"
#import "ApplicationData.h"
#import "Constants.h"
#import "SDWebImageCompat.h"
#import "SDWebImageManager.h"
#import "SocialLogin.h"


@implementation Social
ShareDelegateController *shareMethod;
UIAlertView *request;
MySingleton *singleton;
AppDelegate *delegate;



+ (void) initialize {
    delegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    shareMethod = [[ShareDelegateController alloc] init];
    singleton = [MySingleton getInstance];
    
}

#pragma mark - Share Video To Facebook
+ (void) shareToFacebook:(NSString *)url title:(NSString *)title description:(NSString *)description controller:(UIViewController*)controller{
    
    NSData *videoData = [NSData dataWithContentsOfURL:[NSURL URLWithString:url]];
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   videoData, @"video.mp4",
                                   @"video/mp4", @"contentType",
                                   title, @"name",
                                   [NSString stringWithFormat:@"%@ Download the App Here: https://itunes.apple.com/us/app/hbd/id975172434?mt=8",description], @"description",
                                   url, @"link",
                                   @"http://66.175.213.80/images/hbd_icon_fb_500.png", @"image",
                                   @"Test Status message", @"message",
                                   url, @"source",
                                   @"video", @"type", nil];
    
    
    
    if (UDGetBool(ISFacebookLogin)) {
        if ([FBSDKAccessToken currentAccessToken]) {
            FBSDKGraphRequest *request = [[FBSDKGraphRequest alloc] initWithGraphPath:@"me/videos"
                                                                           parameters:params HTTPMethod:@"POST"];
            [request startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id result, NSError *error) {
                if(!error) {
                    NSLog(@"RESULT: %@", result);
                    [[NSNotificationCenter defaultCenter]
                     postNotificationName:@"TestNotification"
                     object:self];
                    [Commons showAlert:@"Video uploaded succesfully!"];
                } else
                {
                    NSLog(@"RESULT: %@", result);
                    [[NSNotificationCenter defaultCenter]
                     postNotificationName:@"StopLoading"
                     object:self];
                    [Commons showAlert:@"Video uploaded Failed!"];
                    NSLog(@"ERROR: %@", error.localizedDescription);
                }
                
            }];
            
        }else
        {
            NSArray *permissions = [[NSArray alloc] initWithObjects:
                                    @"publish_actions",
                                    nil];
            FBSDKLoginManager *loginManager = [[FBSDKLoginManager alloc] init];
            [loginManager logInWithPublishPermissions:permissions fromViewController:controller handler:
             ^(FBSDKLoginManagerLoginResult *result, NSError *error){
                 if (error) {
                     [[NSNotificationCenter defaultCenter]
                      postNotificationName:@"StopLoading"
                      object:self];
                     [Commons showAlert:@"Video uploaded Failed!"];
                     NSLog(@"Login fail :%@",error);
                 } else if ([FBSDKAccessToken currentAccessToken]) {
                     FBSDKGraphRequest *request = [[FBSDKGraphRequest alloc] initWithGraphPath:@"me/videos"
                                                                                    parameters:params HTTPMethod:@"POST"];
                     [request startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id result, NSError *error) {
                         if(!error) {
                             NSLog(@"RESULT: %@", result);
                             [[NSNotificationCenter defaultCenter]
                              postNotificationName:@"TestNotification"
                              object:self];
                             [Commons showAlert:@"Video uploaded succesfully!"];
                             
                         } else {
                             NSLog(@"RESULT: %@", result);
                             [[NSNotificationCenter defaultCenter]
                              postNotificationName:@"StopLoading"
                              object:self];
                             [Commons showAlert:@"Video uploaded Failed!"];
                             NSLog(@"ERROR: %@", error.localizedDescription);
                         }
                         
                     }];
                 }else {
                     [[NSNotificationCenter defaultCenter]
                      postNotificationName:@"StopLoading"
                      object:self];
                     [Commons showAlert:@"Video uploaded Failed!"];
                     NSLog(@"Login fail :%@",error);
                 }
             } ];
            
            
        }
    }else
    {
        
        delegate.social=[[SocialLogin alloc] initWithSocialType:socialTypeFaceBook];
        // if(self.app.social.socialType == socialTypeFaceBook)
        
        delegate.social.strFBAppId=[@"700346196711244" mutableCopy];
        delegate.social.strFBSecretKey=[@"7fb5f7ba6f2fbe65284cd901e6c9ef30" mutableCopy];
        [delegate.social logoutFacebook];
        
        
        
        
        //    if ([FBSDKAccessToken currentAccessToken]) {
        //        FBSDKGraphRequest *request = [[FBSDKGraphRequest alloc] initWithGraphPath:@"me/videos"
        //                                                                       parameters:params HTTPMethod:@"POST"];
        //        [request startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id result, NSError *error) {
        //            if(!error) {
        //                              NSLog(@"RESULT: %@", result);
        //                                [[NSNotificationCenter defaultCenter]
        //                                 postNotificationName:@"TestNotification"
        //                                 object:self];
        //
        //
        //                            } else
        //                            {
        //                                NSLog(@"RESULT: %@", result);
        //                                [[NSNotificationCenter defaultCenter]
        //                                 postNotificationName:@"StopLoading"
        //                                 object:self];
        //
        //                              NSLog(@"ERROR: %@", error.localizedDescription);
        //                            }
        //
        //        }];
        //
        //    }else
        //    {
        NSArray *permissions = [[NSArray alloc] initWithObjects:
                                @"publish_actions",
                                nil];
        FBSDKLoginManager *loginManager = [[FBSDKLoginManager alloc] init];
        [loginManager logInWithPublishPermissions:permissions fromViewController:controller handler:
         ^(FBSDKLoginManagerLoginResult *result, NSError *error){
             if (error){
                 [Commons showAlert:@"Video uploaded Failed!"];
                 [[NSNotificationCenter defaultCenter]
                  postNotificationName:@"StopLoading"
                  object:self];
                 NSLog(@"Login fail :%@",error);
             } else if ([FBSDKAccessToken currentAccessToken]) {
                 FBSDKGraphRequest *request = [[FBSDKGraphRequest alloc] initWithGraphPath:@"me/videos"
                                                                                parameters:params HTTPMethod:@"POST"];
                 [request startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id result, NSError *error) {
                     if(!error) {
                         NSLog(@"RESULT: %@", result);
                         [[NSNotificationCenter defaultCenter]
                          postNotificationName:@"TestNotification"
                          object:self];
                         [Commons showAlert:@"Video uploaded succesfully!"];
                         
                     } else {
                         NSLog(@"RESULT: %@", result);
                         [[NSNotificationCenter defaultCenter]
                          postNotificationName:@"StopLoading"
                          object:self];
                         [Commons showAlert:@"Video uploaded Failed!"];
                         NSLog(@"ERROR: %@", error.localizedDescription);
                     }
                     
                 }];
             }else {
                 [[NSNotificationCenter defaultCenter]
                  postNotificationName:@"StopLoading"
                  object:self];
                 [Commons showAlert:@"Video uploaded Failed!"];
                 NSLog(@"Login fail :%@",error);
             }
         } ];
    }
}



+ (SLComposeViewController *) shareToTwitter:(int)videoId title:(NSString *)title description:(NSString *)description
{
    title = [[title componentsSeparatedByCharactersInSet:[[NSCharacterSet letterCharacterSet] invertedSet]] componentsJoinedByString:@""];
    NSString *videoUrl = [NSString stringWithFormat:@"%@videos/%i/%@", ROOT, videoId, title];
    SLComposeViewController *mySLComposerSheet = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeTwitter];
    [mySLComposerSheet setTitle:title];
    [mySLComposerSheet addImage:[UIImage imageNamed:@"HBD-icon-1.png"]];
    [mySLComposerSheet addURL:[NSURL URLWithString:videoUrl]];
    [mySLComposerSheet setInitialText:[NSString stringWithFormat:@"%@ created with @thehbdapp Download the App Here: https://itunes.apple.com/us/app/hbd/id975172434?mt=8", description]];
    [mySLComposerSheet setCompletionHandler:^(SLComposeViewControllerResult result) {
        switch (result) {
            case SLComposeViewControllerResultCancelled:
            {
                NSLog(@"Post Canceled");
                [Commons showAlert:@"Post Canceled"];
            }
                break;
            case SLComposeViewControllerResultDone:
            {
                NSLog(@"Post Sucessful");
                [Commons showAlert:@"Post Sucessful"];
            }
                break;
            default:
                break;
        }
    }];
    return mySLComposerSheet;
}

+ (int) startFriendRequest:(NSString *)firstName lastName:(NSString *)lastName email:(NSString *)email birthday:(NSString *)birthday isSpecial:(NSString *)isSpecial
{
    int status_code = 0;
    NSString *urlStr =  [NSString stringWithFormat:@"%@/friends?token=%@",SERVER,singleton.myToken];
    NSArray *paramsTitle = [[NSArray alloc] initWithObjects:@"email",@"firstName",@"lastName",@"birthdate",@"bio",@"isSpecial", nil];
    firstName = [firstName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    lastName = [lastName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    email = [email stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSString *bio = @"N/A";
    NSArray *paramsValue = [[NSArray alloc] initWithObjects:email,UDEncode(firstName),UDEncode(lastName),birthday,bio,isSpecial, nil];
    NSDictionary *jsonDict = [Commons postRequest:urlStr paramsTitle:paramsTitle paramsValue:paramsValue];
    if (![jsonDict isEqual:[NSNull null]]) {
        //     NSString *email = [[jsonDict objectForKey:@"data"] objectForKey:@"email"];
        //       NSString *userId = [[jsonDict objectForKey:@"data"] objectForKey:@"referToUserId"];
        status_code = [[jsonDict objectForKey:@"status_code"] intValue];
        if (status_code == 1) {
            // [Social sendRequestFriend:userId email:email];
        }
    }
    return status_code;
}

+ (void) sendRequestFriend:(NSString*)idReceive email:(NSString*)email
{
    //  BOOL didWork = false;
    NSString *urlStr =  [NSString stringWithFormat:@"%@/friend-request?token=%@",SERVER,singleton.myToken];
    NSArray *paramsTitle = [[NSArray alloc] initWithObjects:@"requestTo",@"email", nil];
    NSArray *paramsValue = [[NSArray alloc] initWithObjects:idReceive,email, nil];
    NSDictionary* jsonDict = [Commons postRequest:urlStr paramsTitle:paramsTitle paramsValue:paramsValue];
    NSLog(@"jsonDict: %@",jsonDict);
    //    if(![jsonDict isEqual:(id)[NSNull null]]) {
    //        request = [[UIAlertView alloc] initWithTitle:@"Friend request successful!" message:nil delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
    //        [request show];
    //        didWork = true;
    //    }
    
    if(![jsonDict count]==0) {
        
        //        request = [[UIAlertView alloc] initWithTitle:@"Friend request successful!" message:nil delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        //        [request show];
        
        // didWork = true;
    }
    else
    {
        request = [[UIAlertView alloc] initWithTitle:@"Friend request failed!" message:nil delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [request show];
        
    }
    
    // return didWork;
}
+ (void) sendRequestFriendBtn:(addFriendButton *)rec
{
    addFriendButton *btn=(addFriendButton*)rec;
    NSString *idReceive, *email;
    idReceive =[btn.param valueForKey:@"id"];
    email =[btn.param valueForKey:@"email"];
    //   BOOL didWork = false;
    NSString *urlStr =  [NSString stringWithFormat:@"%@/friend-request?token=%@",SERVER,singleton.myToken];
    NSArray *paramsTitle = [[NSArray alloc] initWithObjects:@"requestTo",@"email", nil];
    
    NSArray *paramsValue = [[NSArray alloc] initWithObjects:idReceive,email, nil];
    NSDictionary* jsonDict = [Commons postRequest:urlStr paramsTitle:paramsTitle paramsValue:paramsValue];
    NSLog(@"jsonDict: %@",jsonDict);
    // [btn setTitle:@"Pending" forState:UIControlStateNormal];
    //    if(![jsonDict isEqual:(id)[NSNull null]]) {
    //        request = [[UIAlertView alloc] initWithTitle:@"Friend request successful!" message:nil delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
    //        [request show];
    //        didWork = true;
    //    }
    
    if(![jsonDict count]==0) {
        //        request = [[UIAlertView alloc] initWithTitle:@"Friend request successful!" message:nil delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        //        [request show];
        //   didWork = true;
        APPDATA.indexOfReqFriend = btn.tag;
        NSLog(@"tag%ld",(long)btn.tag);
        [[NSNotificationCenter defaultCenter]
         postNotificationName:@"FriendRequestSend"
         object:self];
        
    }
    else
    {
        request = [[UIAlertView alloc] initWithTitle:@"Friend request failed!" message:nil delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [request show];
        
    }
    
    //return didWork;
}

+ (void) viewProfileOf:(NSString *)userId controller:(UIViewController*)controller
{
    UserProfileController *userProfile = [[UserProfileController alloc] init];
    userProfile.referToUserId = userId;
    userProfile.idFriendWithMe = userId;
    [controller presentViewController:userProfile animated:YES completion:nil];
}

+ (void) viewProfileWithArray:(NSArray *)userInfo controller:(UIViewController*)controller withDelegate:(BOOL)hasDelegate
{
    UserProfileController *userProfile = [[UserProfileController alloc] init];
    userProfile.referToUserId = [userInfo valueForKey:@"referToUserId"];
    if (userProfile.referToUserId == nil)
        userProfile.referToUserId = [userInfo valueForKey:@"id"];
    userProfile.idFriendWithMe = [userInfo valueForKey:@"id"];
    if (hasDelegate)
        userProfile.delegate = (RightViewController *)controller;
    userProfile.userName = [NSString stringWithFormat:@"%@ %@",UDDecode([userInfo valueForKey:@"firstName"]), UDDecode([userInfo valueForKey:@"lastName"])];
    userProfile.bio = [userInfo valueForKey:@"bio"];
    userProfile.email = [userInfo valueForKey:@"email"];
    //   userProfile.special = [[userInfo valueForKey:@"isSpecial"] intValue];
    userProfile.birthDay = [userInfo valueForKey:@"birthdate"];
    [Commons removeAllViewLoading:controller];
    [controller presentViewController:userProfile animated:YES completion:nil];
}

+ (void) viewProfileWithArrayNotify:(NSDictionary *)userInfo controller:(UIViewController*)controller withDelegate:(BOOL)hasDelegate
{
    UserProfileController *userProfile = [[UserProfileController alloc] init];
    userProfile.referToUserId = [userInfo valueForKey:@"id"];
    if (userProfile.referToUserId == nil)
        userProfile.referToUserId = [userInfo valueForKey:@"id"];
    userProfile.idFriendWithMe = [userInfo valueForKey:@"id"];
    if (hasDelegate)
        userProfile.delegate = (RightViewController *)controller;
    
    userProfile.userName = [NSString stringWithFormat:@"%@ %@",UDDecode([userInfo  valueForKey:@"firstName"]), UDDecode([userInfo valueForKey:@"lastName"])];
    userProfile.bio = [userInfo valueForKey:@"bio"];
    userProfile.email = [[userInfo valueForKey:@"user"] valueForKey:@"email"];
    //   userProfile.special = [[userInfo valueForKey:@"isSpecial"] intValue];
    userProfile.birthDay = [userInfo valueForKey:@"birthdate"];
    [Commons removeAllViewLoading:controller];
    [controller presentViewController:userProfile animated:YES completion:nil];
}




+ (NSMutableArray *) getUserShouted:(NSString *)idUser limit:(int)limit offset:(int)offset
{
    NSMutableArray *subArr = nil;
    
    
    NSString *urlStr =  [NSString stringWithFormat:@"%@/users/%@/videos/shout?limit=%i&offset=%i&token=%@",SERVER,idUser,limit,offset,singleton.myToken];
    //  @"%@/users/%@/videos/shoutstome?limit=%i&offset=%i&token=%@"
    
    NSURL *url = [NSURL URLWithString:urlStr];
    NSData *responseData;
    responseData = [shareMethod getDataFromUrl:url];
    if (responseData != nil) {
        NSError *error;
        subArr = [NSJSONSerialization JSONObjectWithData:responseData options:kNilOptions error:&error];
    }
    return subArr;
}


+(NSMutableArray *) getUserShoutedToYou:(NSString *)idUser limit:(int)limit offset:(int)offset
{
    NSMutableArray *subArr = nil;
    
    
    NSString *urlStr =  [NSString stringWithFormat:@"%@/users/%@/videos/shoutstome?limit=%i&offset=%i&token=%@",SERVER,idUser,limit,offset,singleton.myToken];
    
    
    NSURL *url = [NSURL URLWithString:urlStr];
    NSData *responseData;
    responseData = [shareMethod getDataFromUrl:url];
    if (responseData != nil) {
        NSError *error;
        subArr = [NSJSONSerialization JSONObjectWithData:responseData options:kNilOptions error:&error];
    }
    
    [[NSNotificationCenter defaultCenter]
     postNotificationName:@"TestNotification"
     object:self];
    
    return subArr;
    
}
+ (NSMutableArray *) getFriendList:(long)limit withOffset:(long)offset byName:(BOOL)byName
{
    NSMutableArray *list = [[NSMutableArray alloc] init];
    NSString *url = [NSString stringWithFormat:@"%@/users/me/friends?limit=%ld&offset=%ld&token=%@",SERVER,limit,offset,singleton.myToken];
    
    if (!byName) {
        url = [NSString stringWithFormat:@"%@/users/me/friends-bday?limit=%ld&offset=%ld&token=%@",SERVER,limit, offset,singleton.myToken];
    }
    NSDictionary* jsonDict = [[NSDictionary alloc]init];
    
    jsonDict = [Commons getRequest:url];
    // jsonDict =  [Commons getRequest:[NSString stringWithFormat:@"%@/users?limit=%i&offset=%i&token=%@",SERVER,500 ,0,singleton.myToken]];//10000
    if (![jsonDict isEqual:[NSNull null]]) {
        if ([[jsonDict valueForKey:@"status_code"] intValue] == 1) {
            NSArray *dataArr = [jsonDict valueForKey:@"data"];
            // for (int i = 0; i < dataArr.count; i++) {
            //      [list addObject:[dataArr objectAtIndex:i]];
            // }
            [dataArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                if ([[obj valueForKey:@"isSystemFriend"] boolValue]  == NO) {
                }
                else {
                    [list addObject:obj];
                }
            }];
        }
    }
    return list;
}

+ (NSDictionary *) findFriendFromEmail:(NSString *)email
{
    email = [email stringByReplacingOccurrencesOfString:@"@" withString:@"_"];
    email = [email stringByReplacingOccurrencesOfString:@"." withString:@"ZZ"];
    return [Commons getRequest:[NSString stringWithFormat:@"%@/users/%@/friends?token=%@",SERVER,email,singleton.myToken]];
}

+ (NSDictionary *) findFriendFromId:(NSString *)idUser
{
    return [Commons getRequest:[NSString stringWithFormat:@"%@/users/%@/friendsId?token=%@",SERVER,idUser,singleton.myToken]];
}

+ (NSDictionary *) updateSpecialValue:(NSString *)email withValue:(int)special
{
    NSDictionary *jsonDict = nil;
    NSString *urlStr =  [NSString stringWithFormat:@"%@/friends/special?token=%@",SERVER,singleton.myToken];
    NSArray *paramsTitle = [[NSArray alloc] initWithObjects:@"email",@"isSpecial", nil];
    NSArray *paramsValue = [[NSArray alloc] initWithObjects:email,[NSString stringWithFormat:@"%i", special], nil];
    jsonDict = [Commons postRequest:urlStr paramsTitle:paramsTitle paramsValue:paramsValue];
    return jsonDict;
}
+ (AddFriendsCell *) getAddFriendCell:(NSMutableArray *)friendInfo atRow:(NSInteger)atRow tableView:(UITableView *)tableView
{
    AddFriendsCell *bFriendCell = [tableView dequeueReusableCellWithIdentifier:@"AddFriendsCell"];
    if (!bFriendCell)
    {
        [tableView registerNib:[UINib nibWithNibName:@"AddFriendsCell" bundle:nil] forCellReuseIdentifier:@"AddFriendsCell"];
        bFriendCell = [tableView dequeueReusableCellWithIdentifier:@"AddFriendsCell"];
    }
    
    
    //      if ([[aFriendArray valueForKey:@"isSpecial"] intValue] == 1)
    //     [bFriendCell.isSpecialImage setImage:[UIImage imageNamed:@"icon-start-yellow.png"]];
    //     else
    //     [bFriendCell.isSpecialImage setImage:[UIImage imageNamed:@"icon-start.png"]];*/
    //         [bFriendCell.ConnectButton addTarget:self action:@selector(checkButtonTapped:event:)
    //          forControlEvents:UIControlEventTouchUpInside];
    
    if (friendInfo.count > 0) {
        NSDictionary *dict = [friendInfo objectAtIndex:atRow];
        
        bFriendCell.Name.text = [NSString stringWithFormat:@"%@ %@",UDDecode([dict valueForKey:@"firstName"]),UDDecode([dict valueForKey:@"lastName"])];
        
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"yyyy-MM-dd"];
        NSDate *date = [formatter dateFromString:[dict valueForKey:@"birthdate"]];
        [formatter setDateFormat:@"MMMM ddT"];
        NSString *newDate = [formatter stringFromDate:date];
        bFriendCell.dob.text = newDate;
        NSString *idReceive = [dict valueForKey:@"id"];
        NSString *email = [dict valueForKey:@"email"];
        NSDictionary *dic=[[NSDictionary alloc] initWithObjects:@[email, idReceive] forKeys:@[@"email",@"id"]];
        bFriendCell.btnConnect.tag = (int)atRow;
        bFriendCell.btnConnect.param=dic;
        if ([[dict valueForKey:@"sentedRequest"] boolValue] == YES) {
            [bFriendCell.btnConnect setImage:[UIImage imageNamed:@"pending-btn"] forState:UIControlStateNormal];
            [bFriendCell.btnConnect setEnabled:NO];
        }
        else if ([[dict valueForKey:@"isSystemFriend"] boolValue] == YES) {
            [bFriendCell.btnConnect setImage:[UIImage imageNamed:@"connected-active-btn"] forState:UIControlStateNormal];
            [bFriendCell.btnConnect setEnabled:NO];
        }
        else {
            [bFriendCell.btnConnect setImage:[UIImage imageNamed:@"connect-btn"] forState:UIControlStateNormal];
            [bFriendCell.btnConnect setEnabled:YES];
            
        }
        [bFriendCell.btnConnect addTarget:self action:@selector(sendRequestFriendBtn:) forControlEvents:UIControlEventTouchUpInside];
        //    if (![Commons isNullOrEmpty:[[friendInfo objectAtIndex:atRow] valueForKey:@"avatar"]]) {
        //        [bFriendCell.ProfieImg setImage:[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[[friendInfo objectAtIndex:atRow] valueForKey:@"avatar"]]]] forState:UIControlStateNormal];
        //    }
        if (![[[friendInfo objectAtIndex:atRow] valueForKey:@"avatar"] isEqual:[NSNull null]]) {
            //        bFriendCell.isSpecialImage.layer.cornerRadius = bFriendCell.isSpecialImage.frame.size.height/2;
            //        bFriendCell.isSpecialImage.clipsToBounds = YES;
            //        [bFriendCell.isSpecialImage sd_setImageWithURL:[NSURL URLWithString:[aFriendArray valueForKey:@"avatar"]] placeholderImage:[UIImage imageNamed:@"admin-icon"]];
            
            //        [bFriendCell.ProfieImg setImage:[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[[friendInfo objectAtIndex:atRow] valueForKey:@"avatar"]]]] forState:UIControlStateNormal];
            //  [bFriendCell.ProfieImg ]
            [bFriendCell.imgProfile sd_setImageWithURL:[NSURL URLWithString:[[friendInfo objectAtIndex:atRow] valueForKey:@"avatar"]] placeholderImage:[UIImage imageNamed:@"admin-icon"]];
        }else
        {
            [bFriendCell.imgProfile setImage:[UIImage imageNamed:@"admin-icon"]];
        }
        NSString *strGender = [Commons isNullOrEmpty:[[friendInfo objectAtIndex:atRow] valueForKey:@"gender"]];
        
        //    if ([strGender isEqualToString:@"Female"]) {
        //        bFriendCell.viewGender.backgroundColor =[UIColor colorWithRed:202.0/255.0 green:74.0/255.0 blue:194.0/255.0 alpha:1];
        //    }
        //   if ([strGender isEqualToString:@"Male"]) {
        //        bFriendCell.viewGender.backgroundColor =[UIColor colorWithRed:49.0/255.0 green:166.0/255.0 blue:148.0/255.0 alpha:1];
        if ([strGender isEqualToString:@"Female"])
        {
            bFriendCell.viewGender.backgroundColor =[UIColor colorWithRed:202.0/255.0 green:74.0/255.0 blue:194.0/255.0 alpha:1];
        }else
        {
            bFriendCell.viewGender.backgroundColor =[UIColor colorWithRed:202.0/255.0 green:74.0/255.0 blue:194.0/255.0 alpha:1];
        }
    }
    return bFriendCell;
}
+ (FriendCell *) getFriendCell:(NSMutableArray *)friendInfo atRow:(NSInteger)atRow tableView:(UITableView *)tableView
{
    FriendCell *aFriendCell = [tableView dequeueReusableCellWithIdentifier:@"FriendCell"];
    if (!aFriendCell)
    {
        [tableView registerNib:[UINib nibWithNibName:@"FriendCell" bundle:nil] forCellReuseIdentifier:@"FriendCell"];
        aFriendCell = [tableView dequeueReusableCellWithIdentifier:@"FriendCell"];
    }
    //   [aFriendCell.btnWishList addTarget:self action:@selector(showFriendWishList:) forControlEvents:UIControlEventTouchUpInside];
    NSDictionary *aFriendArray;
    if (friendInfo.count>0) {
        aFriendArray = [friendInfo objectAtIndex:atRow];
    }
    NSString *userName = [Commons firstLastNameToString:UDDecode([aFriendArray valueForKey:@"firstName"]) lastName:UDDecode([aFriendArray valueForKey:@"lastName"])];
    aFriendCell.nameFriendLbl.text = userName;
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd"];
    NSDate *date = [formatter dateFromString:[NSString stringWithFormat:@"%@",[aFriendArray valueForKey:@"birthdate"]]];
    [formatter setDateFormat:@"MMMM ddT"];
    NSString *newDate = [formatter stringFromDate:date];
    aFriendCell.lblDOB.text = newDate;
    aFriendCell.btnWishList.tag =[[aFriendArray valueForKey:@"referToUserId"] intValue];
    
    if (![aFriendArray valueForKey:@"referToUserId"]) {
        aFriendCell.btnWishList.tag = [[aFriendArray valueForKey:@"id"] intValue] ;
    }
    
    NSString *gender=[Commons isNullOrEmpty:[aFriendArray valueForKey:@"gender"]] ;
    
    //    if ([gender isEqualToString:@"Male"])
    //    {
    //         aFriendCell.viewGender.backgroundColor =[UIColor colorWithRed:49.0/255.0 green:166.0/255.0 blue:148.0/255.0 alpha:1];
    if ([gender isEqualToString:@"Female"])
    {
        aFriendCell.viewGender.backgroundColor =[UIColor colorWithRed:202.0/255.0 green:74.0/255.0 blue:194.0/255.0 alpha:1];
    }else
    {
        aFriendCell.viewGender.backgroundColor =[UIColor colorWithRed:202.0/255.0 green:74.0/255.0 blue:194.0/255.0 alpha:1];
    }
    //  [aFriendCell.btnWishList addTarget:self action:@selector(onbtnWishListAction:) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    /*  if ([[aFriendArray valueForKey:@"isSpecial"] intValue] == 1)
     [aFriendCell.isSpecialImage setImage:[UIImage imageNamed:@"icon-start-yellow.png"]];
     else
     [aFriendCell.isSpecialImage setImage:[UIImage imageNamed:@"icon-start.png"]];*/
    if ([[aFriendArray valueForKey:@"facebookId"] isEqual:[NSNull null]] || [aFriendArray valueForKey:@"facebookId"] == nil)
        [aFriendCell.facebookBtn setHidden:YES];
    else
        [aFriendCell.facebookBtn setHidden:NO];
    if ([[aFriendArray valueForKey:@"referToUserId"] isEqual:[NSNull null]])
        [aFriendCell.hbdBtn setHidden:YES];
    else
        [aFriendCell.hbdBtn setHidden:NO];
    
    if (![[aFriendArray valueForKey:@"avatar"] isEqual:[NSNull null]]) {
        aFriendCell.isSpecialImage.layer.cornerRadius = aFriendCell.isSpecialImage.frame.size.height/2;
        aFriendCell.isSpecialImage.clipsToBounds = YES;
        [aFriendCell.isSpecialImage sd_setImageWithURL:[NSURL URLWithString:[aFriendArray valueForKey:@"avatar"]] placeholderImage:[UIImage imageNamed:@"admin-icon"]];
    }else
    {
        [aFriendCell.isSpecialImage setImage:[UIImage imageNamed:@"admin-icon"]];
    }
    
    NSString *birthday = [aFriendArray valueForKey:@"birthdate"];
    
    long month = 0 ;
    long day = 0 ;
    if (![birthday isKindOfClass:[NSNull class]]) {
        month = [[birthday substringWithRange:NSMakeRange(5, 2)] intValue];
        day= [[birthday substringWithRange:NSMakeRange(8, 2)] intValue];
    }
    
    
    int tagZodiac = [Commons getZodiacTag:month day:day];
    //    if([[Commons isNullOrEmpty:[aFriendArray valueForKey:@"gender"] ] isEqualToString:@"Male"])
    //    {
    //        NSString *nameImageZodiac = singleton.zodiacImageM[tagZodiac];
    //        aFriendCell.imgZodiac.image = [UIImage imageNamed:nameImageZodiac];
    if([[Commons isNullOrEmpty:[aFriendArray valueForKey:@"gender"] ] isEqualToString:@"Female"])
    {
        NSString *nameImageZodiac = singleton.zodiacImageF[tagZodiac];
        aFriendCell.imgZodiac.image = [UIImage imageNamed:nameImageZodiac];
    }else
    {
        NSString *nameImageZodiac = singleton.zodiacImageF[tagZodiac];
        aFriendCell.imgZodiac.image = [UIImage imageNamed:nameImageZodiac];
    }
    
    return aFriendCell;
}
- (void)checkButtonTapped:(id)sender event:(id)event
{
    UIButton *btn=sender;
    btn.selected=!btn.selected;
}


-(void)onbtnWishListAction:(UIButton *) btn
{
    _delegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    [_delegate goLeft];
    delegate.tabbarController.selectedIndex = 4;
    singleton.selectShouted = 0;
    singleton.selectDrafts = 0;
    singleton.selectWishList = 1;
    singleton.tagRecordVideo = 0;
    singleton.tagSetting = 0;
    //  delegate.tabbarController.selectedIndex = 4;
}

- (void)showFriendWishList:(UIButton *) btn {
    //[self goCenter];
    //    delegate.tabbarController.selectedIndex = 3;
    //    singleton.selectShouted = 0;
    //    singleton.selectDrafts = 0;
    //    singleton.selectWishList = 1;
    //    singleton.tagRecordVideo = 0;
    //    singleton.tagSetting = 0;
    //    delegate.tabbarController.selectedIndex = 4;
}
- (void) goCenter
{
    //  [self.drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
    //   [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}
@end
